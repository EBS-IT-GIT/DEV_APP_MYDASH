==============================================================================
CUSEAM004_006 : Comunicado de Anomalia Preditiva
==============================================================================

Atualiza��o - CUSEAM004_006
Produto     - XX Customizaciones
Data        - 04/05/2020 11:34:57
HotPatch    - N�o
Fornecedor  - DBS Digital

Tarefas preparat�rias
==============================================================================
As tarefas abaixo podem ser feitas sem deixar a aplica��o offline.

N�o h� tarefas nesta se��o.

Tarefas pr�-instala��o
==============================================================================
N�o � necess�rio baixar a aplica��o para realizar as tarefas abaixo.

N�o h� tarefas nesta se��o.

Aplica��o do Patch
==============================================================================

1. Aplique o patch
Este patch cont�m o seguinte driver que deve ser aplicado com o AutoPatch:
u121CUSEAM004_006

Tarefas p�s-instala��o
==============================================================================
� necess�rio completar essas tarefas.

Ap�s a aplica��o do Patch � necess�rio realizar um Bounce no AOCORE

Tarefas finais
==============================================================================
As tarefas abaixo podem ser feitas com a aplica��o dispon�vel para uso.

N�o h� tarefas nesta se��o.

Pr�-requisitos
==============================================================================

� Necess�rio que o patch anterior : u121CUSEAM004_005 esteja aplicado no Oracle
EBS.

Informa��es Adicionais
==============================================================================

Este patch contem os arquivos: jSAECUSEAM004.zip
                               SAE_EAM_WIP_REQUESTS_PKS.pls
                               SAE_EAM_WIP_REQUESTS_PKB.pls
                               SAE_CSI_ITEM_INSTANCES_TRG.trg
                               SAE_WIP_EAM_WORK_REQ_NOTES_TRG.trg
                               SAE_WIP_EAM_WORK_REQUESTS_TRG.trg
                               CUSEAM004_006.sql
                               JustificativaCALovRN.xml
                               SintomaCALovRN.xml
                               SAE_EAM_SINTOMA_CA_VST.ldt
                               SAE_EAM_TEC_PREDITIVA_MNU.ldt
                               SAE_EBS_EAM_TOM_PREDITIVA_RSP.ldt
