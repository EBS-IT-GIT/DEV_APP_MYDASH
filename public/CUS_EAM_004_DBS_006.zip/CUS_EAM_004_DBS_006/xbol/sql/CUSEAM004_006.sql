WHENEVER SQLERROR EXIT FAILURE ROLLBACK
CONNECT &1/&2
WHENEVER SQLERROR CONTINUE

-- $Header: CUSEAM004_006.sql 121.2 16/06/2020 12:00:00 appldev ship $
-- +==================================================================+
-- |                      SANTO ANTONIO ENERGIA                       |
-- |                       All rights reserved.                       |
-- +==================================================================+
-- | FILENAME                                                         |
-- |   CUSEAM004_006.sql                                              |
-- |                                                                  |
-- | PURPOSE                                                          |
-- |   CUS004                                                         |
-- |                                                                  |
-- | DESCRIPTION                                                      |
-- |   Script para Ajustar os lookups com os novos campos do          |
-- |    Comunicado de Anomalia Preditiva.                             |
-- |                                                                  |
-- | PARAMETERS                                                       |
-- |                                                                  |
-- | CREATED BY                                                       |
-- |  Giovan de Castro Gomes      06/05/2020                          |
-- |                                                                  |
-- | UPDATED BY                                                       |
-- |                                                                  |
-- +==================================================================+
--

DECLARE
BEGIN
  -- Lookup : SAE_EAM_EMAIL_PRIORIDADE_CA
  BEGIN 
    UPDATE apps.fnd_lookup_values
       SET ATTRIBUTE6 = 'Y'
         , ATTRIBUTE7 = 'N'
     WHERE lookup_type = 'SAE_EAM_EMAIL_PRIORIDADE_CA';
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;   
  COMMIT;

  -- Lookup : SAE_EAM_EMAIL_CONCLUIR_CA
  BEGIN 
    UPDATE apps.fnd_lookup_values
       SET ATTRIBUTE1 = 'Y'
         , ATTRIBUTE2 = 'N'
     WHERE lookup_type = 'SAE_EAM_EMAIL_CONCLUIR_CA';
  EXCEPTION 
    WHEN OTHERS THEN 
      NULL;
  END;   
  COMMIT;
 
END;
/

WHENEVER SQLERROR CONTINUE
COMMIT;
EXIT;
