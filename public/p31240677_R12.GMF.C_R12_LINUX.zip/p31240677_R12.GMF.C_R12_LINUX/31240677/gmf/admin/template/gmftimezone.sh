#!/bin/sh
# $Header: gmftimezone.sh 120.0.12020000.5 2015/04/29 20:18:02 rpatangy noship $
# $AutoConfig$
#   
#   FILENAME
#     gmftimezone.sh
#   DESCRIPTION
#     Autoconfig unzip GMF Timezone file 
#   HISTORY
#     06/13/2008 XZHANG  created
#   ===========================================================
# dbdrv: none

PLATFORM="%s_platform%"
