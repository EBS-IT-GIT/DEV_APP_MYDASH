REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv:   none none none sqlplus &phase=ccet \
REM dbdrv:   checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv:   none none none sqlplus &phase=acet \
REM dbdrv:   checkfile:~PROD:~PATH:~FILE:fcet GMF_TRANSACTION_VALUATION_F1
REM +======================================================================+ 
REM |    Copyright (c) 2005, 2017 Oracle and/or its affiliates.            | 
REM |                         All rights reserved.                         | 
REM |                           Version 12.0.0                             | 
REM +======================================================================+ 
REM $Header: GMF_TRANSACTION_VALUATION_X1.sql 120.0.12020000.1 2017/02/07 09:39:31 maychen noship $

REM | FILENAME                                                              |
REM |     GMF_TRANSACTION_VALUATION_X1.sql                                          |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for GMF_TRANSACTION_VALUATION.LINE_ID#1                |
REM | Update columns LINE_ID from number(15) to number                 |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 07-FEB-2017 May Chen                                                  |
REM |             Generated for new column LINE_ID#1                       |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER GMF_TRANSACTION_VALUATION_F1
  BEFORE INSERT OR UPDATE ON &1..GMF_TRANSACTION_VALUATION
  for each row forward crossedition  
  disable
BEGIN
      :new.LINE_ID#1 := :new.LINE_ID;
     
END;
/
COMMIT;
EXIT;
