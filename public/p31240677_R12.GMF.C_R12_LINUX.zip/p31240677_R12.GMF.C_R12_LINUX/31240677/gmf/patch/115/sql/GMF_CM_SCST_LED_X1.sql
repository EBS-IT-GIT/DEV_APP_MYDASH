REM $Header: GMF_CM_SCST_LED_X1.sql 120.0.12020000.1 2014/11/07 09:31:49 penpan noship $
REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=ccet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv: none none none sqlplus &phase=acet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE CM_SCST_LED_F1
REM +=======================================================================+
REM |    Copyright (c) 1998, 2014 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     GMF_CM_SCST_LED_X1.sql                                            |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for CM_SCST_LED.CMPNTCOST_ID#1                  |
REM | and CM_SCST_LED.RUDTL_ID#1                                            |
REM | Update CM_SCST_LED CMPNTCOST_ID,RUDTL_ID from number(10) to number    |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 07-NOV-2014 Peng Pan                                                  |
REM |             Generated for new column CMPNTCOST_ID#1,RUDTL_ID#1        |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER CM_SCST_LED_F1
  BEFORE INSERT OR UPDATE ON &1..CM_SCST_LED
  for each row forward crossedition  
  disable
BEGIN
      :new.CMPNTCOST_ID#1 := :new.CMPNTCOST_ID;
      :new.RUDTL_ID#1     := :new.RUDTL_ID;
END;
/
COMMIT;
EXIT;
