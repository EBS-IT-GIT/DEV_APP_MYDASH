REM $Header: GMF_BURDEN_ASSOCIATION_X1.sql 120.0.12020000.1 2013/03/20 12:01:12 spabolu noship $
REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=ccet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv: none none none sqlplus &phase=acet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE GMF_BURDEN_ASSOCIATION_F1
REM +=======================================================================+
REM |    Copyright (c) 1998 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     GMF_BURDEN_ASSOCIATION_X1.sql                                     |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for                                             |
REM | GMF_BURDEN_ASSOCIATION.SOURCE_ANALYSIS_CODE#1  and                    |
REM | GMF_BURDEN_ASSOCIATION.TARGET_ANALYSIS_CODE#1                         |
REM | Update GMF_BURDEN_ASSOCIATION SOURCE_ANALYSIS_CODE size               |
REM | from 4 chars to 32 Chars                                              |
REM | Update GMF_BURDEN_ASSOCIATION TARGET_ANALYSIS_CODE size               |
REM | from 4 chars to 32 Chars                                              |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 18-MAR-2013 Saptagirish Pabolu                                        |
REM |             Generated for new column SOURCE_ANALYSIS_CODE#1 and       |
REM |             TARGET_ANALYSIS_CODE#1                                    |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER GMF_BURDEN_ASSOCIATION_F1
  BEFORE INSERT OR UPDATE ON &1..GMF_BURDEN_ASSOCIATION
  for each row forward crossedition  
  disable
BEGIN
      :new.SOURCE_ANALYSIS_CODE#1 := :new.SOURCE_ANALYSIS_CODE;
      :new.TARGET_ANALYSIS_CODE#1 := :new.TARGET_ANALYSIS_CODE;
END;
/
COMMIT;
EXIT;
