REM +======================================================================+ 
REM |    Copyright (c) 2005, 2015 Oracle and/or its affiliates.           | 
REM |                         All rights reserved.                         | 
REM |                           Version 12.0.0                             | 
REM +======================================================================+ 
REM $Header: gmflcrdt2_cleanup.sql 120.0.12020000.2 2015/04/10 07:19:24 smukalla noship $
REM dbdrv: none 
SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

COMMIT;
EXIT;
