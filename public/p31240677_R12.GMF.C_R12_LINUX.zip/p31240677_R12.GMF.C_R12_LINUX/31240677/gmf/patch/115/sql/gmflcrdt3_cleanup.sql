REM +======================================================================+ 
REM |    Copyright (c) 2005, 2015 Oracle and/or its affiliates.           | 
REM |                         All rights reserved.                         | 
REM |                           Version 12.0.0                             | 
REM +======================================================================+ 
REM $Header: gmflcrdt3_cleanup.sql 120.0.12020000.4 2015/06/24 05:32:17 smukalla noship $
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=last \
REM dbdrv: checkfile:~PROD:~PATH:~FILE SYSTEM &systempwd
REM        
REM History : 24-Mar-2015 : Sreerama Mukalla : Created script for Bug20542606
REM Usage
SET VERIFY OFF
WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

BEGIN 

ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_STEP_TAB FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_MATL_TAB FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_RSRC_TAB FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_DEPENDENCY_TAB FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_COST_TAB FORCE' );

ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_STEP_TYPE FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_MATL_TYPE FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_RSRC_TYPE FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_DEPENDENCY_TYPE FORCE' );
ad_zd.load_ddl('CLEANUP', 'drop type &&1..GMF_COST_TYPE FORCE' );

END;
/
COMMIT;
EXIT;
