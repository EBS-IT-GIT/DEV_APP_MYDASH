REM $Header: GMF_CM_CMPT_MST_TL_X1.sql 120.0.12020000.1 2013/03/20 12:06:43 spabolu noship $
REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=ccet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv: none none none sqlplus &phase=acet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE CM_CMPT_MST_TL_F1
REM +=======================================================================+
REM |    Copyright (c) 1998 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     GMF_CM_CMPT_MST_TL_X1.sql                                         |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for CM_CMPT_MST_TL.COST_CMPNTCLS_DESC#1         |
REM | Update CM_CMPT_MST_TL COST_CMPNTCLS_DESC size                         |
REM | from 40 chars to 240 Chars                                            |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 18-MAR-2013 Saptagirish Pabolu                                        |
REM |             Generated for new column COST_CMPNTCLS_DESC#1             |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER CM_CMPT_MST_TL_F1
  BEFORE INSERT OR UPDATE ON &1..CM_CMPT_MST_TL
  for each row forward crossedition  
  disable
BEGIN
      :new.COST_CMPNTCLS_DESC#1 := :new.COST_CMPNTCLS_DESC;
END;
/
COMMIT;
EXIT;
