REM $Header: gmfdvreqt.sql 120.1.12020000.5 2013/02/05 18:54:54 pvkanetk ship $
REM dbdrv: sql ~PROD ~PATH ~FILE none none none sql &phase=con \    
REM dbdrv: checkfile(120.0.12010000.6=120.1.12020000.5):~PROD:~PATH:~FILE

REM +=======================================================================+
REM |    Copyright (c) 2003 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | DESCRIPTION                                                           |
REM |     SQL script to delte incorrect APPS.GMF_BATCH_REQUIREMENTS_GTMP    |
REM | NOTES                                                                 |
REM |     TYPE=AUTOMATIC                                                    |
REM | HISTORY                                                               |
REM |     May 2011 -- created By Rajesh Patangya                            |
REM +=======================================================================+

REM AD_ERROR_HANDLING: add 942
REM AD_ERROR_HANDLING: add 2443
REM AD_ERROR_HANDLING: add 1418

SET VERIFY OFF;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;

DROP TABLE GMF_BATCH_REQUIREMENTS_GTMP;
DROP INDEX GMF_LOT_COST_DETAILS_N2;

COMMIT;
EXIT;
