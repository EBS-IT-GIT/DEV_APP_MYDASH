REM $Header: GMF_CM_CMPT_GRP_X1.sql 120.0.12020000.1 2013/03/20 12:29:22 spabolu noship $
REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=ccet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv: none none none sqlplus &phase=acet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE CM_CMPT_GRP_F1
REM +=======================================================================+
REM |    Copyright (c) 1998 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     GMF_CM_CMPT_GRP_X1.sql                                            |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for CM_CMPT_GRP.CMPNT_GROUP#1  and              |
REM | CM_CMPT_GRP.CMPNT_GROUP_DESC#1                                        |
REM | Update CM_CMPT_GRP CMPNT_GROUP size from 8 chars to 32 Chars          |
REM | Update CM_CMPT_GRP CMPNT_GROUP_DESC size from 40 chars to 240 Chars   |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 18-MAR-2013 Saptagirish Pabolu                                        |
REM |             Generated for new column CMPNT_GROUP#1 and                |
REM |             CMPNT_GROUP_DESC#1                                        |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER CM_CMPT_GRP_F1
  BEFORE INSERT OR UPDATE ON &1..CM_CMPT_GRP
  for each row forward crossedition  
  disable
BEGIN
      :new.CMPNT_GROUP#1      := :new.CMPNT_GROUP;
      :new.CMPNT_GROUP_DESC#1 := :new.CMPNT_GROUP_DESC;
END;
/
COMMIT;
EXIT;
