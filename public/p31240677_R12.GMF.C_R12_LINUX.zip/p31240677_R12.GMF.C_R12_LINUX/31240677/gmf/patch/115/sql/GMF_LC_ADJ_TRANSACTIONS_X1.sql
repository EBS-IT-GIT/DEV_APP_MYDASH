REM $Header: GMF_LC_ADJ_TRANSACTIONS_X1.sql 120.0.12020000.1 2013/03/20 12:25:31 spabolu noship $
REM ---- Create FCET ----
REM dbdrv: sql ~PROD ~PATH ~FILE \
REM dbdrv: none none none sqlplus &phase=ccet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_gmf
REM ---- Apply FCET ----
REM dbdrv: sql ad patch/115/sql AD_ZD_TABLE_APPLY.sql \
REM dbdrv: none none none sqlplus &phase=acet \
REM dbdrv: checkfile:~PROD:~PATH:~FILE GMF_LC_ADJ_TRANSACTIONS_F1
REM +=======================================================================+
REM |    Copyright (c) 1998 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     GMF_LC_ADJ_TRANSACTIONS_X1.sql                                    |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM | Cross Edition Trigger for                                             |
REM | GMF_LC_ADJ_TRANSACTIONS.COST_ANALYSIS_CODE#1                          |
REM | Update GMF_LC_ADJ_TRANSACTIONS COST_ANALYSIS_CODE size                |
REM | from 4 chars to 32 Chars                                              |
REM | NOTES                                                                 |
REM | HISTORY                                                               |
REM | 18-MAR-2013 Saptagirish Pabolu                                        |
REM |             Generated for new column COST_ANALYSIS_CODE#1             |
REM +=======================================================================+

SET VERIFY OFF;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

CREATE OR REPLACE TRIGGER GMF_LC_ADJ_TRANSACTIONS_F1
  BEFORE INSERT OR UPDATE ON &1..GMF_LC_ADJ_TRANSACTIONS
  for each row forward crossedition  
  disable
BEGIN
      :new.COST_ANALYSIS_CODE#1 := :new.COST_ANALYSIS_CODE;
END;
/
COMMIT;
EXIT;
