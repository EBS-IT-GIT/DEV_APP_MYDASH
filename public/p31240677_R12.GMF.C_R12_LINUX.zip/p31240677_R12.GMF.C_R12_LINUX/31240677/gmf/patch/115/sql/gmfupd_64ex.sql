REM dbdrv: sql ~PROD ~PATH ~FILE none none none sqlplus &phase=last \
REM dbdrv: checkfile:~PROD:~PATH:~FILE
REM dbdrv: sql ~PROD ~PATH ~FILE none none none sqlplus &phase=last \
REM dbdrv: checkfile:gmf:patch/115/import/US:gmfprg.ldt
REM $Header: gmfupd_64ex.sql 120.0.12020000.5 2019/11/07 22:54:54 rpatangy noship $
REM
REM /*========================================================================+
REM |   Copyright (c) 2001, 2019 Oracle Corporation Redwood Shores, California, USA |
REM |                             All rights reserved.                        |
REM +=========================================================================+
REM |  FILENAME                                                               |
REM |    gmfupd_64ex.sql                                                      |
REM |                                                                         |
REM |  DESCRIPTION                                                            |
REM |   This file updates fnd_executable to have exe extension for 64 bit exes|
REM |   Cost rollup process executable for 64 bit Linux                       |
REM |   Actual cost process executable for 64 bit Linux                       |
REM |   Cost Update executable for 64 bit linux                               |
REM |   Pre-processor executable for 64 bit linux                             |
REM |                                                                         |
REM |  HISTORY                                                                |
REM |    04-APR-13 Rajesh Patangya - 64 bit Executables                       |
REM *=========================================================================*/
REM
REM AD_ERROR_HANDLING: add 1403

SET VERIFY OFF 
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;

BEGIN

ad_zd_seed.prepare('FND_EXECUTABLES');

update fnd_executables
set execution_file_name = 'GMFROLLLNX64.exe'
where executable_name = 'GMFROLLLNX64'
and execution_file_name = 'GMFROLLLNX64'
and application_id = 555;
        
update fnd_executables
set execution_file_name = 'GMFACOSTLNX64.exe'
where executable_name = 'GMFACOSTLNX64'
and execution_file_name = 'GMFACOSTLNX64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFCUPDLNX64.exe'
where executable_name = 'GMFCUPDLNX64'
and execution_file_name = 'GMFCUPDLNX64'
and application_id = 555;
        
update fnd_executables
set execution_file_name = 'GMFXUPDLNX64.exe'
where executable_name = 'GMFXUPDLNX64'
and execution_file_name = 'GMFXUPDLNX64'
and application_id = 555;

/* rnie bug17212613 start */
update fnd_executables
set execution_file_name = 'GMFROLLHPIA64.exe'
where executable_name = 'GMFROLLHPIA64'
and execution_file_name = 'GMFROLLHPIA64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFACOSTHPIA64.exe'
where executable_name = 'GMFACOSTHPIA64'
and execution_file_name = 'GMFACOSTHPIA64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFCUPDHPIA64.exe'
where executable_name = 'GMFCUPDHPIA64'
and execution_file_name = 'GMFCUPDHPIA64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFXUPDHPIA64.exe'
where executable_name = 'GMFXUPDHPIA64'
and execution_file_name = 'GMFXUPDHPIA64'
and application_id = 555;
/* rnie bug17212613 end */

/* rnie bug23001174 generate 64bit exe for solaris */
update fnd_executables
set execution_file_name = 'GMFROLLSRS64.exe'
where executable_name = 'GMFROLLSRS64'
and execution_file_name = 'GMFROLLSRS64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFACOSTSRS64.exe'
where executable_name = 'GMFACOSTSRS64'
and execution_file_name = 'GMFACOSTSRS64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFCUPDSRS64.exe'
where executable_name = 'GMFCUPDSRS64'
and execution_file_name = 'GMFCUPDSRS64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFXUPDSRS64.exe'
where executable_name = 'GMFXUPDSRS64'
and execution_file_name = 'GMFXUPDSRS64'
and application_id = 555;
/* rnie bug23001174 generate 64bit exe for solaris */

/* Enh 29880157 Geenerate 64bit exe for AIX  */
update fnd_executables
set execution_file_name = 'GMFROLLAIX64.exe'
where executable_name = 'GMFROLLAIX64'
and execution_file_name = 'GMFROLLAIX64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFACOSTAIX64.exe'
where executable_name = 'GMFACOSTAIX64'
and execution_file_name = 'GMFACOSTAIX64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFCUPDAIX64.exe'
where executable_name = 'GMFCUPDAIX64'
and execution_file_name = 'GMFCUPDAIX64'
and application_id = 555;

update fnd_executables
set execution_file_name = 'GMFXUPDAIX64.exe'
where executable_name = 'GMFXUPDAIX64'
and execution_file_name = 'GMFXUPDAIX64'
and application_id = 555;
END;

/
COMMIT;
EXIT;
