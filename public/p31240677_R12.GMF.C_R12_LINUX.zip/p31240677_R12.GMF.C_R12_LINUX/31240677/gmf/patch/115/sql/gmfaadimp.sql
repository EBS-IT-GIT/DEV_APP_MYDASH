REM $Header: gmfaadimp.sql 120.1.12020000.1 2012/06/26 06:36:34 appldev ship $
REM +======================================================================+
REM |   Copyright (c) 2002 Oracle Corporation Belmont, California, USA     |
REM |                       All rights reserved.                           |
REM +======================================================================+
REM FILENAME
REM       gmfaadimp.sql
REM
REM DESCRIPTION
REM       This installation script prepares the environment for import
REM       application accounting definitions.
REM
REM HISTORY
REM       28-JUN-2006  WYCHAN   Created (from xlaimportaad.sql)
REM
REM +======================================================================+
REM dbdrv: sql ~PROD ~PATH ~FILE none none none sqlplus &phase=dat \
REM dbdrv: checkfile:nocheck
REM

SET VERIFY OFF
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK

DECLARE

x_staging_context_code VARCHAR2(30);
x_return_status        VARCHAR2(30);

BEGIN

xla_aad_install_pvt.pre_import
(p_application_id        => 555
,p_amb_context_code      => 'DEFAULT'
,x_return_status         => x_return_status);

END;
/

COMMIT;
EXIT;
