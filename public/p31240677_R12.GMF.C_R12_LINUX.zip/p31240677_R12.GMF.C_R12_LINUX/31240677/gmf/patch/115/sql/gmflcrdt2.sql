REM $Header: gmflcrdt2.sql 120.0.12020000.6 2015/03/25 09:17:15 smukalla noship $

REM dbdrv: sql ~PROD ~PATH ~FILE none none none sql_single &phase=tab+1 \
REM dbdrv: checkfile:~PROD:~PATH:~FILE &un_apps_ne &pw_apps_ne &un_apps &pw_apps


REM +=======================================================================+
REM |    Copyright (c) 2003, 2015 Oracle Corporation, Redwood Shores, CA, USA     |
REM +=======================================================================+
REM | DESCRIPTION                                                           |
REM |     SQL script to define lot cost rollup database types               |
REM | NOTES                                                                 |
REM |     TYPE=AUTOMATIC                                                    |
REM | HISTORY                                                               |
REM |                                                                       |
REM | 06-Mar-2015 Sreerama Mukalla                                          |
REM |                                                                       |
REM +=======================================================================+

REM AD_ERROR_HANDLING: add 1432
REM AD_ERROR_HANDLING: add 1434

SET VERIFY OFF;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;

CONNECT &&1/&&2

REM CREATING TYPES.......

CREATE OR REPLACE TYPE gmf_cost_type FORCE AS OBJECT
( cost_cmpntcls_id   NUMBER
, cost_analysis_code VARCHAR2(32)
, cost_level         NUMBER(1)
, component_cost     NUMBER
, burden_ind         NUMBER(1)
);
/

CREATE OR REPLACE TYPE gmf_cost_tab FORCE AS TABLE OF gmf_cost_type;
/


CREATE OR REPLACE TYPE gmf_dependency_type FORCE AS OBJECT
( batchstep_id       NUMBER
, step_qty           NUMBER
, step_qty_uom       VARCHAR2(4)
, step_index         NUMBER
);
/

CREATE OR REPLACE TYPE gmf_dependency_tab FORCE AS TABLE OF gmf_dependency_type;
/

CREATE OR REPLACE TYPE gmf_rsrc_type FORCE AS OBJECT
( trans_id          NUMBER 
, organization_id   NUMBER 
, resources         VARCHAR2(16) 
, resource_usage    NUMBER 
, trans_um          VARCHAR2(4) 
, trans_date        DATE 
, trans_cost        NUMBER 
, cost_details      gmf_cost_tab 
, cost_source       number
, actual_resource_rate number
, currency_conversion_rate number
, currency_code varchar2(15)
, currency_conversion_date date
, currency_conversion_type varchar2(30)
);
/

CREATE OR REPLACE TYPE gmf_rsrc_tab FORCE AS TABLE OF gmf_rsrc_type;
/

CREATE OR REPLACE TYPE gmf_matl_type FORCE AS OBJECT
( trans_id          NUMBER 
, legal_entity_id   NUMBER 
, organization_id   NUMBER 
, item_id           NUMBER 
, lot_number        VARCHAR2(80) 
, line_type         NUMBER 
, trans_qty         NUMBER 
, trans_um          VARCHAR2(3) 
, trans_date        DATE 
, lot_costed_flag   NUMBER 
, step_contribution VARCHAR2(1) 
, trans_cost        NUMBER 
, planned_line_qty  NUMBER 
, actual_line_qty   NUMBER 
, line_um           VARCHAR2(4) 
, cost_details      gmf_cost_tab 
, cost_alloc        NUMBER 
);
/

CREATE OR REPLACE TYPE gmf_matl_tab FORCE AS TABLE OF gmf_matl_type;
/

CREATE OR REPLACE TYPE gmf_step_type FORCE AS OBJECT
( current_step_id      NUMBER
, step_qty             NUMBER
, step_qty_uom         VARCHAR2(4)
, output_qty           NUMBER
, current_costs        gmf_cost_tab
, inherited_costs      gmf_cost_tab
, step_costs           gmf_cost_tab
, materials            gmf_matl_tab
, resources            gmf_rsrc_tab
, dependencies         gmf_dependency_tab     
);
/

CREATE OR REPLACE TYPE gmf_step_tab FORCE AS TABLE OF gmf_step_type;
/

GRANT ALL ON &&1..GMF_STEP_TAB TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_STEP_TYPE TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_MATL_TAB TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_RSRC_TAB TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_MATL_TYPE TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_RSRC_TYPE TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_DEPENDENCY_TAB TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_DEPENDENCY_TYPE TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_COST_TAB TO &&3 WITH GRANT OPTION;
GRANT ALL ON &&1..GMF_COST_TYPE TO &&3 WITH GRANT OPTION;

CONNECT &&3/&&4;

CREATE OR REPLACE PUBLIC SYNONYM GMF_STEP_TAB FOR &&1..GMF_STEP_TAB;
CREATE OR REPLACE PUBLIC SYNONYM GMF_STEP_TYPE FOR &&1..GMF_STEP_TYPE;
CREATE OR REPLACE PUBLIC SYNONYM GMF_MATL_TAB FOR &&1..GMF_MATL_TAB;
CREATE OR REPLACE PUBLIC SYNONYM GMF_RSRC_TAB FOR &&1..GMF_RSRC_TAB;
CREATE OR REPLACE PUBLIC SYNONYM GMF_MATL_TYPE FOR &&1..GMF_MATL_TYPE;
CREATE OR REPLACE PUBLIC SYNONYM GMF_RSRC_TYPE FOR &&1..GMF_RSRC_TYPE;
CREATE OR REPLACE PUBLIC SYNONYM GMF_DEPENDENCY_TAB FOR &&1..GMF_DEPENDENCY_TAB;
CREATE OR REPLACE PUBLIC SYNONYM GMF_DEPENDENCY_TYPE FOR &&1..GMF_DEPENDENCY_TYPE;
CREATE OR REPLACE PUBLIC SYNONYM GMF_COST_TAB FOR &&1..GMF_COST_TAB;
CREATE OR REPLACE PUBLIC SYNONYM GMF_COST_TYPE FOR &&1..GMF_COST_TYPE;


COMMIT;
EXIT;



