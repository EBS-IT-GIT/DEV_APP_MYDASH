#!/bin/sh
# $Header: shttimezone.sh 120.0.12020000.1 2014/10/08 07:09:14 jjgao noship $
# $AutoConfig$
#   
#   FILENAME
#     shttimezone.sh
#   DESCRIPTION
#     Autoconfig unzip 10.1 Timezone file 
#   HISTORY
#     06/13/2008 XZHANG  created
#   ===========================================================
# dbdrv: none

program=`basename $0`
printf "\n$program started at `date`\n\n"
SHT_ZIP_DIR=%s_shttop%/timezone
SHT_UNZIP_DIR=%s_shttop%/timezone
SHT_ZIP_FILE=timezlrg.zip
UNZIP_UTIL=unzip
PLATFORM="%s_platform%"

printf "\n10.1 Timezone file, Please Wait ...\n"

if test -f "$SHT_ZIP_DIR/$SHT_ZIP_FILE"; then

	if test "$PLATFORM" = "LINUX_X86-64"; then
	  $UNZIP_UTIL -qq $SHT_ZIP_DIR/$SHT_ZIP_FILE -d $SHT_UNZIP_DIR
	fi
	exit_code=$?

	printf "\n10.1 Timezone file is copied to $SHT_UNZIP_DIR \n\n"

else
	printf "\n10.1 Timezone file is not exist...\n"
	exit_code=1;
fi
printf "\n$program: exiting with status $exit_code\n\n"
echo "ERRORCODE = $exit_code ERRORCODE_END"
