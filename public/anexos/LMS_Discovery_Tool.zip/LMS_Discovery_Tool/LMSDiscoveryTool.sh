#! /bin/ksh
if [ -z "$LMSDT_JAVA_HOME" ]
then
        echo "Warning : LMSDT_JAVA_HOME is unset! Use default JAVA_HOME"
else
        JAVA_HOME=$LMSDT_JAVA_HOME
        export JAVA_HOME
        PATH=$JAVA_HOME/bin:$PATH
        export PATH
fi
echo $JAVA_HOME
echo $PATH
java -jar ./lib/lmsdt.jar -Xms512m -Xmx1024m oracle.sam.SamMain
