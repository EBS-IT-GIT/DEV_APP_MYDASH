--------------------------------------------------------------------------------------------------------------------------------------
Prompt In�cio Redmine #54820 - 	Validar Item de XML recebido
--------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE CSF_OWN.DE_PARA_ITEM_FORNEC (
   id                  NUMBER          NOT NULL
 , empresa_id          NUMBER          NOT NULL
 , pessoa_id           NUMBER          NOT NULL
 , cod_item            VARCHAR2(60)    NOT NULL
 , item_id             NUMBER          NOT NULL
 , CONSTRAINT DEPARAITEMFORNEC_PK PRIMARY KEY (id) USING INDEX TABLESPACE CSF_INDEX
) TABLESPACE CSF_DATA
/
-- Comments --
COMMENT ON TABLE CSF_OWN.DE_PARA_ITEM_FORNEC                  IS 'CADASTRO DO DE-PARA DE ITENS DO FORNECEDOR COM ITENS COMPLIANCE'
/

COMMENT ON COLUMN CSF_OWN.DE_PARA_ITEM_FORNEC.ID              IS 'SEQUENCIAL DO REGISTRO - DEPARAITEMFORNEC_SEQ'
/

COMMENT ON COLUMN CSF_OWN.DE_PARA_ITEM_FORNEC.EMPRESA_ID      IS 'IDENTIFICADOR DA EMPRESA - ID DA TABELA EMPRESA'
/

COMMENT ON COLUMN CSF_OWN.DE_PARA_ITEM_FORNEC.PESSOA_ID       IS 'IDENTIFICADOR DO FORNECEDOR - ID DA TABELA PESSOA'
/

COMMENT ON COLUMN CSF_OWN.DE_PARA_ITEM_FORNEC.COD_ITEM        IS 'CODIGO DO ITEM DO FORNECEDOR ENVIADO NA NOTA FISCAL'
/

COMMENT ON COLUMN CSF_OWN.DE_PARA_ITEM_FORNEC.ITEM_ID         IS 'IDENTIFICADOR DO ITEM (PRODUTO) - ID DA TABELA ITEM'
/
-- Constraints --
ALTER TABLE CSF_OWN.DE_PARA_ITEM_FORNEC ADD CONSTRAINT DEPARAITEMFORNEC_EMPRESA_FK  FOREIGN KEY (EMPRESA_ID)   REFERENCES EMPRESA (ID)
/

ALTER TABLE CSF_OWN.DE_PARA_ITEM_FORNEC ADD CONSTRAINT DEPARAITEMFORNEC_PESSOA_FK   FOREIGN KEY (PESSOA_ID)    REFERENCES PESSOA (ID)
/

ALTER TABLE CSF_OWN.DE_PARA_ITEM_FORNEC ADD CONSTRAINT DEPARAITEMFORNEC_ITEM_FK     FOREIGN KEY (ITEM_ID)      REFERENCES ITEM (ID)
/

ALTER TABLE CSF_OWN.DE_PARA_ITEM_FORNEC ADD CONSTRAINT DEPARAITEMFORNEC_UK1         UNIQUE (EMPRESA_ID, PESSOA_ID, COD_ITEM) USING INDEX TABLESPACE CSF_INDEX
/
  
-- Indexes --
CREATE INDEX DEPARAITEMFORNEC_EMPRESA_IX  ON CSF_OWN.DE_PARA_ITEM_FORNEC (EMPRESA_ID)   TABLESPACE CSF_INDEX
/

CREATE INDEX DEPARAITEMFORNEC_PESSOA_IX   ON CSF_OWN.DE_PARA_ITEM_FORNEC (PESSOA_ID)    TABLESPACE CSF_INDEX
/

CREATE INDEX DEPARAITEMFORNEC_ITEM_IX     ON CSF_OWN.DE_PARA_ITEM_FORNEC (ITEM_ID)      TABLESPACE CSF_INDEX
/

GRANT SELECT, INSERT, UPDATE, DELETE ON CSF_OWN.DE_PARA_ITEM_FORNEC TO CSF_WORK
/

-- Sequence --
CREATE SEQUENCE CSF_OWN.DEPARAITEMFORNEC_SEQ
INCREMENT BY 1
START WITH   1
NOMINVALUE
NOMAXVALUE
NOCYCLE
NOCACHE
/

GRANT SELECT ON CSF_OWN.DEPARAITEMFORNEC_SEQ TO CSF_WORK
/

INSERT INTO CSF_OWN.SEQ_TAB ( id
                            , sequence_name
                            , table_name
                            )
                     values ( csf_own.seqtab_seq.nextval
                            , 'DEPARAITEMFORNEC_SEQ'
                            , 'DE_PARA_ITEM_FORNEC'
                            )
/

COMMIT
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt T�rmino Redmine #54820 - 	Validar Item de XML recebido
--------------------------------------------------------------------------------------------------------------------------------------
