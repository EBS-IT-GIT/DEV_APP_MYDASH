-- ======================================================================================================================= --
Prompt INI - Redmine 55188 - Criar tabela de Parametro de Recebimento - CRIACAO DA PARAM_RECEB
-- ======================================================================================================================= --
-- 01 - Cria��o da tabela
create table csf_own.PARAM_RECEB
(
  ID             NUMBER        not null,
  MULTORG_ID     NUMBER        not null,
  COD_OP_RECEB   VARCHAR2(60)  not null,
  DESCR_OP_RECEB VARCHAR2(255) not null
)
/

-- 02 - Cria��o dos campos para n�o ter problema com tabela j� criada
-- Tabela nova

-- 03 - Coment�rio da tabela 
comment on table csf_own.PARAM_RECEB is 'Tabela de parametriza��o de recebimento de notas que dever�o ser devolvidas ao ERP.'
/

-- 04 - Coment�rios dos campos 
comment on column csf_own.PARAM_RECEB.ID             is 'ID da tabela param_receb'
/

comment on column csf_own.PARAM_RECEB.MULTORG_ID     is 'ID da tabela mult_org'
/

comment on column csf_own.PARAM_RECEB.COD_OP_RECEB   is 'C�digo do recebimento'
/

comment on column csf_own.PARAM_RECEB.DESCR_OP_RECEB is 'Descri��o do recebimento'
/

-- 05 - Cria��o da PK/UK/FK 
alter table csf_own.PARAM_RECEB  add constraint PARAMRECEB_PK primary key (ID)
/

alter table csf_own.PARAM_RECEB  add constraint PARAMRECEB_CODOPRECEB_UK unique (COD_OP_RECEB)
/

alter table csf_own.PARAM_RECEB  add constraint PARAMRECEB_MULT_ORG_FK foreign key (MULTORG_ID)  references MULT_ORG (ID)
/

-- 06 - Cria��o da CK
-- Sem CK

-- 07 - Cria��o dos �ndices 
create index PARAMRECEB_MULT_ORG_FK_I on csf_own.PARAM_RECEB (MULTORG_ID)
/

-- 08 - Cria��o dos Grants 
grant select, insert, update, delete on csf_own.PARAM_RECEB to CSF_WORK
/

-- 09 - Cria��o do Sin�nimo
create or replace synonym csf_work.PARAM_RECEB for csf_own.PARAM_RECEB
/

-- 10 - Cria��o da Sequence 
create sequence CSF_OWN.PARAMRECEB_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'PARAMRECEB_SEQ', 'PARAM_RECEB')
/

grant select on CSF_OWN.PARAMRECEB_SEQ TO CSF_WORK
/

commit
/

-- ======================================================================================================================= --
Prompt FIM - Redmine 55188 - Criar tabela de Parametro de Recebimento - CRIACAO DA PARAM_RECEB
-- ======================================================================================================================= --


