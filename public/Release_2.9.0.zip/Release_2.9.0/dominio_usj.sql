-- =========================================================================================
PROMPT INI - DOMINIOS - PROJETO PEDIDOS
-- =========================================================================================
begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '0', 'Por conta do emitente', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '1', 'Por conta do destinat�riocommit; exception when others then null; end; /remetente', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '2', 'Por conta de terceiros', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '3', 'Transporte Pr�prio por conta do Remetente', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '4', 'Transporte Pr�prio por conta do Destinat�rio', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_MOD_FRETE', '9', 'Sem cobran�a de frete', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '0', 'N�o validado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '1', 'Validado e aberto', csf_own.dominio_seq.nextval);
commit; exception when others then null; end;
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '2', 'Erro de valida��o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '3', 'Cancelado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '4', 'Validado e parcialmente recebido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('PEDIDO.DM_ST_PROC', '5', 'Validado e totalmente recebido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_IND_MOV', '0', 'Sim', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_IND_MOV', '1', 'N�o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '0', 'N�o validado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '1', 'Validado e aberto', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '2', 'Erro de valida��o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '3', 'Cancelado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '4', 'Validado e parcialmente recebido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_PEDIDO.DM_ST_PROC', '5', 'Validado e totalmente recebido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('IMP_ITEMPED.DM_IND_CRED', '0', 'N�o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('IMP_ITEMPED.DM_IND_CRED', '1', 'Sim', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('LOG_GENERICO_PEDIDO.DM_ENV_EMAIL', '0', 'N�o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('LOG_GENERICO_PEDIDO.DM_ENV_EMAIL', '1', 'Sim', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('LOG_GENERICO_PEDIDO.DM_IMPRESSA', '0', 'N�o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('LOG_GENERICO_PEDIDO.DM_IMPRESSA', '1', 'Sim', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_EDICAO', '0', 'N�o houve Edi��o pela tela', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_EDICAO', '1', 'Houve Edi��o pela tela', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_IND_EMIT', '0', 'Emiss�o pr�pria', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_IND_EMIT', '1', 'Terceiros', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_IND_OPER', '0', 'Entrada', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_IND_OPER', '1', 'Terceiros', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '0', 'N�o validada e sem pedido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '1', 'N�o validada e com pedido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '2', 'Erro de valida��o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '3', 'Cancelada', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '4', 'Liberado Manualmente', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '5', 'Validada', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '6', 'Validada e Lida', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_PROC', '7', 'Pedido n�o encontrado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_RET', '0', 'Processado com Sucesso', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_RET', '1', 'Processado com Advert�ncia', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('NOTA_FISCAL_PED.DM_ST_RET', '2', 'Erro no Processamento', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '0', 'N�o validado e com pedido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '1', 'N�o validado e sem pedido', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '2', 'Erro de valida��o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '3', 'Cancelado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '4', 'Liberado Manualmente', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '5', 'Validada', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('ITEM_NF_PED.DM_ST_PROC', '7', 'Pedido n�o encontrado', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('IMP_ITEMNF_PED.DM_TIPO', '0', 'Imposto', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

begin insert into csf_own.dominio (DOMINIO, VL, DESCR, ID) values ('IMP_ITEMNF_PED.DM_TIPO', '1', 'Reten��o', csf_own.dominio_seq.nextval);
commit; exception when others then null; end; 
/

-- =========================================================================================
PROMPT FIM - DOMINIOS - PROJETO PEDIDOS
-- =========================================================================================
