-------------------------------------------------------------------
Prompt Processo para catalogar as rotinas program�veis - Gen�ricas
-------------------------------------------------------------------

prompt 01_pb_cria_unidade
@@01_pb_cria_unidade.prc
show err

prompt 02_pb_acerta_ie_inval
@@02_pb_acerta_ie_inval.prc
show err

prompt 03_pb_acerta_data_dup
@@03_pb_acerta_data_dup.prc
show err

prompt 04_pb_cria_item
@@04_pb_cria_item.prc
show err

prompt 05_pb_acerta_item_nf
@@05_pb_acerta_item_nf.prc
show err

prompt 06_pb_insere_pessoa
@@06_pb_insere_pessoa.prc
show err

prompt 07_pb_acerta_pessoa_nf
@@07_pb_acerta_pessoa_nf.prc
show err

prompt 08_pb_acerta_cst_imp_pc_nf
@@08_pb_acerta_cst_imp_pc_nf.prc
show err

prompt 09_pb_acerta_chave_nf_dados_csf
@@09_pb_acerta_chave_nf_dados_csf.prc
show err

prompt 10_pb_acerta_chave_nf_terceiro1
@@10_pb_acerta_chave_nf_terceiro1.prc
show err

prompt 11_pb_acerta_chave_nf_terceiro2
@@11_pb_acerta_chave_nf_terceiro2.prc
show err

prompt 12_pb_acerta_chave_nf_terceiro3
@@12_pb_acerta_chave_nf_terceiro3.prc
show err

prompt 13_pb_acerta_chave_nf_terceiro4
@@13_pb_acerta_chave_nf_terceiro4.prc
show err

prompt 14_pb_acerta_reg_c190_totais
@@14_pb_acerta_reg_c190_totais.prc
show err

prompt 15_pb_int_lanc_tab_din_m300
@@15_pb_int_lanc_tab_din_m300.prc
show err

-------------------------------------------------------------------
