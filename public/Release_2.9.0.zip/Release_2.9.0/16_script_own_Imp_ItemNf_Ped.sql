-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - IMP_ITEMNF_PED
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.IMP_ITEMNF_PED
(
  ID            NUMBER not null,
  ITEMNFPED_ID  NUMBER not null,
  IMPITEMNF_ID  NUMBER not null,
  TIPOIMP_ID    NUMBER not null,
  DM_TIPO       NUMBER(1) not null,
  VL_BASE_CALC  NUMBER(15,2),
  ALIQ_APLI     NUMBER(8,4),
  IMPITEMPED_ID NUMBER,
  VL_IMP_TRIB   NUMBER(15,2)
)
/

-- Add comments to the table
comment on table CSF_OWN.IMP_ITEMNF_PED  is 'Tabela de Impostos/Reten��o do Item da Nota Fiscal'
/

-- Add comments to the columns
comment on column CSF_OWN.IMP_ITEMNF_PED.ITEMNFPED_ID  is 'ID que relaciona a Tabela Item_NF_Ped'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.IMPITEMNF_ID  is 'Identificador do imposto do item da nota fiscal - imp_itemnf.'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.TIPOIMP_ID    is 'ID que relaciona a Tabela Tipo_Imposto'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.DM_TIPO       is 'Tipo: 0-Imposto / 1-Reten��o'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.VL_BASE_CALC  is 'Valor da Base de Calculo'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.ALIQ_APLI     is 'Aliquota do imposto'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.IMPITEMPED_ID  is 'ID relacionado a tabela IMP_ITEMPED'
/

comment on column CSF_OWN.IMP_ITEMNF_PED.VL_IMP_TRIB    is 'Valor do Imposto Tributado'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.IMP_ITEMNF_PED  add constraint IMPITEMNFPED_PK primary key (ID)
/

alter table CSF_OWN.IMP_ITEMNF_PED  add constraint IMPITEMNFPED_UK unique (ITEMNFPED_ID, TIPOIMP_ID, DM_TIPO)
/

alter table CSF_OWN.IMP_ITEMNF_PED  add constraint IMPITEMNFPED_IMPITEMPED_FK foreign key (IMPITEMPED_ID)  references CSF_OWN.IMP_ITEMPED (ID)
/

alter table CSF_OWN.IMP_ITEMNF_PED  add constraint IMPITEMNFPED_ITEMNFPED_FK foreign key (ITEMNFPED_ID)  references CSF_OWN.ITEM_NF_PED (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.IMP_ITEMNF_PED  add constraint IMPITEMNFPED_DMTIPO_CK  check (DM_TIPO IN (0, 1))
/

-- Create/Recreate indexes
create index CSF_OWN.IMPITEMNFPED_IMPITEMPED_FK_I on CSF_OWN.IMP_ITEMNF_PED (IMPITEMPED_ID)
/

create index CSF_OWN.IMPITEMNFPED_ITEMNFPED_FK_I on CSF_OWN.IMP_ITEMNF_PED (ITEMNFPED_ID)
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - csf_own.IMP_ITEMNF_PED_PED
-------------------------------------------------------------------------------------------------------------------------------
