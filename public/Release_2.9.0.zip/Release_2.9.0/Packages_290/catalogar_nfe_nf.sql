prompt -----------------------------------------------------------------------------------

prompt Catalogar Packages de integra��o NFE_NF

prompt -----------------------------------------------------------------------------------

Set define Off

prompt 32a_CSF_OWN_pk_integr_nfe.pks
@@32a_CSF_OWN_pk_integr_nfe.pks
show err
prompt 32b_CSF_OWN_pk_integr_nfe.pkb
@@32b_CSF_OWN_pk_integr_nfe.pkb
show err
