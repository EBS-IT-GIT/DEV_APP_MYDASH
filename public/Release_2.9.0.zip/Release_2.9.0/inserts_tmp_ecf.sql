prompt ************************************************************
prompt Inicio Insercao de registros na tabela TMP_ECF;            *
prompt ************************************************************

set feedback off
set define off

prompt Truncating TMP_ECF...
truncate table CSF_OWN.TMP_ECF;
prompt Loading CSF_OWN.TMP_ECF...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('195', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('196', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.03', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.20', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.25', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.30', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199.01', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5.05', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.01', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.11', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.12', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.13', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.14', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.16', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.18', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.25', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.30', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.35', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.40', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.45', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.50', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.55', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.60', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.65', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.70', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.75', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.80', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.85', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.90', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.95', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.97', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('7', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.05', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.10', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.15', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.20', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.25', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.30', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.35', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.40', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.45', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.50', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.55', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.60', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.35', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.40', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.45', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.50', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.55', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.60', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.75', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.85', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.90', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17951', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17952', 'M300', 'C', 2);
commit;
prompt 100 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17953', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17954', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17956', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17957', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17958', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17959', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17964', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17968', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17969', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('18', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('22', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('26', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('33', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('34', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('34.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.25', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.25', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('45', 'M300', 'C', 2);
commit;
prompt 200 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('46', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.25', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.30', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.35', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.35', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.40', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.45', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.50', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.55', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.60', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.30', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.35', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.40', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('67', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('68', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('68.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('73', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('75', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('76', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.01', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.02', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.03', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.30', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.35', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78.01', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.30', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.30', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.35', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.35', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.40', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.40', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.45', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.50', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.50', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.55', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.55', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.60', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.65', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.70', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.70', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.75', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.80', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.80', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.85', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.85', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.90', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.95', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86951', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86952', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86953', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86954', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86955', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86956', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86957', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86957', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86958', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86958', 'M300', 'C', 3);
commit;
prompt 300 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86959', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86959', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86960', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86961', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86962', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86962', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86963', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86963', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86964', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86964', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86965', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86966', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86966', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86967', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86968', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('87', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('87', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.25', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.30', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92.05', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('93', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('93', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('96', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('97', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('98', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('98.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.05', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('7', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.11', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.12', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.13', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.14', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.16', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.18', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.25', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.30', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.55', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.65', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.70', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.75', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.80', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.85', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.90', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.95', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.97', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.05', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.10', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.15', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.20', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.25', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.30', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.35', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.40', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.45', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.50', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.55', 'M300', 'A', 1);
commit;
prompt 400 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.45', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.60', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.65', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.65', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.70', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.70', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.75', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.80', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.80', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.85', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.90', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.95', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.95', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19951', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19952', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19953', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19954', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19955', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19955', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19956', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19957', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19958', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19959', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19960', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19960', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19961', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19961', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19962', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19962', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19963', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19963', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19964', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19965', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19965', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19966', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19966', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19967', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19967', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19968', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19969', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19970', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19970', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19971', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19971', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19972', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19972', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('24', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('33', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('34', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M300', 'A', 1);
commit;
prompt 500 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('50', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('59', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.55', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('69', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('70', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('71', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('80', 'M300', 'A', 3);
commit;
prompt 600 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.01', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.02', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92.01', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('96', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.35', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.40', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.50', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.50', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.55', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.60', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.65', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.70', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.70', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.75', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.80', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.80', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.85', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.80', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.90', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.95', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100951', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100952', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100953', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100954', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100955', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100956', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100957', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100957', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100958', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100958', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100959', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100959', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100960', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100961', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100962', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100962', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100963', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100963', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100964', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100964', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100965', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100966', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100966', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100967', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100968', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106.05', 'M300', 'A', 4);
commit;
prompt 700 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('109', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('110', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118.10', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('119', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('120', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('133', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M300', 'A', 3);
commit;
prompt 800 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.03', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.30', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167.01', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.11', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.12', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.13', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.14', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.16', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.18', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.25', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.30', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.55', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.65', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.70', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.75', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.80', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.85', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.90', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.95', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.97', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('184', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.05', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.10', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.15', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.20', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.25', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.30', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.35', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.40', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.45', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.50', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('188', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('189', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('190', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('190', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.45', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.60', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.65', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.65', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.70', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.70', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.75', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.80', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.80', 'M300', 'A', 3);
commit;
prompt 900 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.85', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.90', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.95', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.95', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194951', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194952', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194953', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194954', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194955', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194955', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194956', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194957', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194958', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194959', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194960', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194960', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194961', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194961', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194962', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194962', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194963', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194963', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194964', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194965', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194965', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194966', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194966', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194967', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194967', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194968', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194969', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194970', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194970', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194971', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194971', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194972', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194972', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('195', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('196', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('200', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('200', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('203', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('205', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('206', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('207', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('208', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('209', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('210', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('210.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('214', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('217', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('217.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('217.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('217.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('217.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('218', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('218.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('222', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('224', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('225', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('226', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('231.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('232', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('232.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('233', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('234', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.15', 'M300', 'A', 1);
commit;
prompt 1000 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.35', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.50', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.55', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.60', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('245', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('253', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('253', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('254', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('255', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('255.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('260', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('262', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('263', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.01', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.02', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266.01', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('269', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('269', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('270', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.35', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.35', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.40', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.40', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.45', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.50', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.50', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.55', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.55', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.60', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.65', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.70', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.70', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.75', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.80', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.80', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.85', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.85', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.90', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.95', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274951', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274952', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274953', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274954', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274955', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274956', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274957', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274957', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274958', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274958', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274959', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274959', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274960', 'M300', 'A', 2);
commit;
prompt 1100 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274961', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274962', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274962', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274963', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274963', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274964', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274964', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274965', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274966', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274966', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274967', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274968', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('275', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('275', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.20', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.25', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('277', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('279', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('279.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('280', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('280.05', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('281', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('281', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('282', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('283', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('284', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('285', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('291', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('291.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('292', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('292.10', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('293', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('295.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('296', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('296', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('300', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('300', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('302', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('302', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('303', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('303', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('304', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('304', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.01', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.01', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.25', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.30', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.30', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.35', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.40', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('309', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('315', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('315.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.15', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.05', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.10', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.15', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.20', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('320', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('320.01', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('321', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('328', 'M300', 'A', 1);
commit;
prompt 1200 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('328', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('329', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('329.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('330', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.05', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.10', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('335', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('337', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('338', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.03', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.04', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.05', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.10', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.15', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.20', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.25', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.30', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M300', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M300', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M300', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341.01', 'M300', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5.05', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.11', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.12', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.13', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.14', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.16', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.18', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.25', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.30', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.35', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.40', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.45', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.50', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.55', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.60', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.65', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.70', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.75', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.80', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.85', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.90', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.95', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.97', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('7', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.05', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.10', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.15', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.20', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.25', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.30', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.35', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.40', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.45', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.50', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.55', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.60', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.35', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.40', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.45', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.50', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.55', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.60', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M300', 'B', 3);
commit;
prompt 1300 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.75', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.85', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.90', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17951', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17952', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17953', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17954', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17956', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17957', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17958', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17959', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17964', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17968', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17969', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('18', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('22', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('26', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('46', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.35', 'M300', 'B', 1);
commit;
prompt 1400 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('49.55', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.20', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.25', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.20', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('59', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.20', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.30', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.40', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.45', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.50', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.55', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.60', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.20', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.30', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.35', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.40', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('69', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('70', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('71', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('80', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.02', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.03', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.15', 'M300', 'B', 1);
commit;
prompt 1500 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.20', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.30', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.35', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.40', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.01', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.30', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.30', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.35', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.35', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.40', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.40', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.45', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.50', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.50', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.55', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.55', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.60', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.65', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.70', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.70', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.75', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.80', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.80', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.85', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.85', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.90', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.95', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99951', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99952', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99953', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99954', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99955', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99956', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99957', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99957', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99958', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99958', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99959', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99959', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99960', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99961', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99962', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99962', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99963', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99963', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99964', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99964', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99965', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99966', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99966', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99967', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99968', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.20', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.25', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.30', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('109', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('110', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('110.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.01', 'M300', 'B', 3);
commit;
prompt 1600 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('119', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('119.05', 'M300', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('120', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('121', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.20', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.15', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('133', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('133', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('139', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('139', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('140', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('140', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('144', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('144', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('148', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('148', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('149', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('149', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('150', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('150', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('151', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('151', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('152', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('152', 'M300', 'B', 3);
commit;
prompt 1700 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('153', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('153', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('158', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('158', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('160', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('160', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('162', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('162', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('165', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.30', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.35', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('168.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('168.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.10', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.10', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('173', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('173.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.05', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.15', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.05', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.10', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.15', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.20', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('177', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('178', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('178.01', 'M300', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('179', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186', 'M300', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187.05', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('188', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('193', 'M300', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.20', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.30', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.40', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.45', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.50', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.55', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.60', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.20', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.25', 'M350', 'B', 1);
commit;
prompt 1800 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.30', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.35', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.40', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('69', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('70', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('71', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('80', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.01', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.02', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.03', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.20', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.30', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.35', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('90.40', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.01', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.30', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.30', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.35', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.35', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.40', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.40', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.45', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.50', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.50', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.55', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.55', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.60', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.65', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.70', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.70', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.75', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.80', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.80', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.85', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.85', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.90', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.95', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99951', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99952', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99953', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99954', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99955', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99956', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99957', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99957', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99958', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99958', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99959', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99959', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99960', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99961', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99962', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99962', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99963', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99963', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99964', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99964', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99965', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99966', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99966', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99967', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99968', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.20', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.25', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101.30', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.5', 'M350', 'B', 4);
commit;
prompt 1900 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('109', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('110', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('110.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('123.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('124.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('129', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('130', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('133', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('133', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('139', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('139', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('140', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('140', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('144', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('144', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('148', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('148', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('149', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('149', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('150', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('150', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('151', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('151', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('152', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('152', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('153', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('153', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M350', 'B', 1);
commit;
prompt 2000 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('158', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('158', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('160', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('160', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('162', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('162', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('165', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.30', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.35', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('168.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('168.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('169.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('173', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('173.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('174.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('175.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('177', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('178', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('178.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('179', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('188', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('193', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('195', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('196', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.03', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.20', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.25', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198.30', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199.01', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('18', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('22', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('26', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32.01', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M350', 'C', 1);
commit;
prompt 2100 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.20', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39.25', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.20', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42.25', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('45', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('46', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.20', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.25', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.30', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.35', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.35', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.40', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.45', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.50', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.55', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('47.60', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('51.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.20', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5.05', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.01', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.11', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.12', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.13', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.14', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.16', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.18', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.25', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.30', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.35', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.40', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.45', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.50', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.55', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.60', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.65', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.70', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.75', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.80', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.85', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.90', 'M350', 'C', 2);
commit;
prompt 2200 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.95', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.97', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.05', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.10', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.15', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.20', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.25', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.30', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.35', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.40', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.45', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.50', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.55', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.60', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.35', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.40', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.45', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.50', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.55', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.60', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.75', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.85', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.90', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17951', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17952', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17953', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17954', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17956', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17957', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17958', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17959', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17964', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17968', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17969', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.30', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.35', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.40', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('67', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('68', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('68.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('73', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('75', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('76', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.01', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.02', 'M350', 'C', 3);
commit;
prompt 2300 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.03', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.20', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.30', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('77.35', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('78.01', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.30', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.30', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.35', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.35', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.40', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.40', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.45', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.50', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.50', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.55', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.55', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.60', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.65', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.70', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.70', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.75', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.80', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.80', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.85', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.85', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.90', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86.95', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86951', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86952', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86953', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86954', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86955', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86956', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86957', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86957', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86958', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86958', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86959', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86959', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86960', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86961', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86962', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86962', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86963', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86963', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86964', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86964', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86965', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86966', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86966', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86967', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86968', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('87', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('87', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.20', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.25', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88.30', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92.05', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('93', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('93', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('94', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95.01', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('97', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('99.05', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M350', 'C', 2);
commit;
prompt 2400 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.20', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.25', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.30', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.30', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.35', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.40', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.10', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.15', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.05', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.10', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.15', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.20', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.01', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126.05', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.01', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.03', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.05', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.15', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.20', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.25', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.30', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.50', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M350', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M350', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M350', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138.01', 'M350', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('104.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.01', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.25', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.30', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.30', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.35', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.40', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.10', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113.15', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.05', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.10', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.15', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114.20', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.01', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('125', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126', 'M300', 'C', 1);
commit;
prompt 2500 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('126.05', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('127', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('132', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.01', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.03', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.05', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.15', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.20', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.25', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.30', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.50', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M300', 'C', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M300', 'C', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138', 'M300', 'C', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('138.01', 'M300', 'C', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('7', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.02', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.11', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.12', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.13', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.14', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.16', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.18', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.30', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.55', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.65', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.70', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.75', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.80', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.90', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('8.95', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.05', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.10', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.15', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.20', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.25', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.30', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.35', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.40', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.45', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.50', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('16.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.45', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.60', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.65', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.65', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.70', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.70', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.75', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.80', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.80', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.85', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.90', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.95', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19.95', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19951', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19952', 'M350', 'A', 2);
commit;
prompt 2600 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19953', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19954', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19955', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19955', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19956', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19957', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19958', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19959', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19960', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19960', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19961', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19961', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19962', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19962', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19963', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19963', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19964', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19965', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19965', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19966', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19966', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19967', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19967', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19968', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19969', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19970', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19970', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19971', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19971', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19972', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19972', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('24', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('33', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('34', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('59', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60', 'M350', 'A', 2);
commit;
prompt 2700 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.35', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.55', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('64.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('65.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('66.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('69', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('70', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('71', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('79', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('80', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('81.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('82.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('84.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('86', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('88', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('89', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.01', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.02', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('91.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('92.01', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('95', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('96', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.35', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.40', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.50', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.50', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.55', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.60', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.65', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.70', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.70', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.75', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.80', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.80', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.85', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.85', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.90', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100.95', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100951', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100952', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100953', 'M350', 'A', 2);
commit;
prompt 2800 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100954', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100955', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100956', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100957', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100957', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100958', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100958', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100959', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100959', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100960', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100961', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100962', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100962', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100963', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100963', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100964', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100964', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100965', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100966', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100966', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100967', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('100968', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('101', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('102.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('103', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('105.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('106.05', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('107', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('108', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('109', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('111', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('112.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('113', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('114', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('115', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('116', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('117.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('118.10', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('119', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('122.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('128', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('131.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.01', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.35', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('134.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('135', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('136.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('137.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('141.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('142.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('143.20', 'M350', 'A', 1);
commit;
prompt 2900 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('145', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('146.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('147', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('154', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('155.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('156', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('157.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('159.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('161', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('163', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('164', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.03', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('166.25', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('167.01', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('181.02', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('182.01', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.02', 'M350', 'A', 0);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.11', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.12', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.13', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.14', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.16', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.18', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.30', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.55', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.65', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.70', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.75', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.80', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.90', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('183.95', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.05', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.10', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.15', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.20', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.25', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.30', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.35', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.40', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.45', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.50', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('186.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('187', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('188', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('189', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('190', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('190', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('191.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.45', 'M350', 'A', 1);
commit;
prompt 3000 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.60', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.65', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.65', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.70', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.70', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.75', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.80', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.80', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.85', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.90', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.95', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194.95', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194951', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194952', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194953', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194954', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194955', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194955', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194956', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194957', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194958', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194959', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194960', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194960', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194961', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194961', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194962', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194962', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194963', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194963', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194964', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194965', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194965', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194966', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194966', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194967', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194967', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194968', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194969', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194970', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194970', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194971', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194971', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194972', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('194972', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('195', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('196', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('198', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('199', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('200', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('200', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('203', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('204.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('205', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('206', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('207', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('208', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('209', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('210', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('210.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('214', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('216.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('224', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('228.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('230.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('231.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('232', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('232.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('233', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('234', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.25', 'M350', 'A', 3);
commit;
prompt 3100 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.35', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.50', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.55', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('235.60', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('239.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('240.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('241.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('245', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('253', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('253', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('254', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('255', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('255.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('257.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('260', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('262', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('263', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.01', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.02', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('265.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('266.01', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('269', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('269', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('270', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.35', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.35', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.40', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.40', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.45', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.50', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.50', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.55', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.55', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.60', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.65', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.70', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.70', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.75', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.80', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.80', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.85', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.85', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.90', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274.95', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274951', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274952', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274953', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274954', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274955', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274956', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274957', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274957', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274958', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274958', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274959', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274959', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274960', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274961', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274962', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274962', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274963', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274963', 'M350', 'A', 3);
commit;
prompt 3200 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274964', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274964', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274965', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274966', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274966', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274967', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('274968', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('275', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('275', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.20', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.25', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('276.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('277', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('227.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('279', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('279.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('280', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('280.05', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('281', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('281', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('282', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('283', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('285', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('291', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('291.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('292', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('292.10', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('293', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('294.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('305.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.01', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.01', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.25', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.30', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.30', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.35', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('308.40', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('309', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('311.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('315', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('315.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('316.15', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.05', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.10', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.15', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('317.20', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('320', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('320.01', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('321', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('328', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('328', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('329', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('329.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('330', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.05', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.10', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('332.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('335', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('337', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('338', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.03', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.04', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.05', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.10', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.15', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.20', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('340.25', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M350', 'A', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M350', 'A', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341', 'M350', 'A', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('341.01', 'M350', 'A', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'B', 1);
commit;
prompt 3300 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('5.05', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.11', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.12', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.13', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.14', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.16', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.18', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.25', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.30', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.35', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.40', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.45', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.50', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.55', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.60', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.65', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.70', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.75', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.80', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.85', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.90', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.95', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('6.97', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.05', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.10', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.15', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.20', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.25', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.30', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.35', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.40', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.45', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.50', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.55', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('9.60', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('10', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('11', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('12', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('13', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('14.20', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.20', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.25', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.30', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.35', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.40', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.45', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.50', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.55', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.60', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.65', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.70', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.75', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.80', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.85', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.90', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17.95', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17951', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17952', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17953', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17954', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17955', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17956', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17957', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17958', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17959', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17960', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17961', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17962', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17963', 'M350', 'B', 3);
commit;
prompt 3400 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17964', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17965', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17966', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17967', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17968', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17969', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17970', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17971', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('17972', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('18', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('19', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('21', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('22', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('23', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('26', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('27.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('28', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('29', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('30', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('31', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('32', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35', 'M350', 'B', 4);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.01', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('35.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('36', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('37', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('38', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('39', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('40', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('41', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('42', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('43', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('44', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('46', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.20', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.20', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.25', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('52.25', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('53.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('54.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.10', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.15', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('55.20', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('56.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('57.05', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('58', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('59', 'M350', 'B', 2);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60', 'M350', 'B', 2);
commit;
prompt 3500 records committed...
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M350', 'B', 1);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.05', 'M350', 'B', 3);
insert into csf_own.TMP_ECF (COD, MODELO, ENTIDADE, RELACAO)
values ('60.10', 'M350', 'B', 1);
commit;
prompt 3503 records loaded

set feedback on
set define on
prompt ************************************************************
prompt Finalizado Insercao de registros na tabela TMP_ECF;        *
prompt ************************************************************
