--------------------------------------------------------------------------------------------
Prompt INICIO Release 2.9.0 - Alteracoes no CSF_INT
--------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 01 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO Release 2.9.0 - Semana de Desenvolvimento 02 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INICIO Redmine #53015 - Remover campo  dt_lcto_ext da tabela VW_CSF_INT_LCTO_CONTABIL
--------------------------------------------------------------------------------------------------------------------------------------

alter table csf_int.VW_CSF_INT_LCTO_CONTABIL drop column dt_lcto_ext
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #53015 - Remover campo  dt_lcto_ext da tabela VW_CSF_INT_LCTO_CONTABIL
--------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt FIM Release 2.9.0 - Semana de Desenvolvimento 02 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 03 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 04 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 05 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO Release 2.9.0 - Semana de Desenvolvimento 06 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------
Prompt INICIO Redmine Melhoria #53499: Altera��o registro X353
--------------------------------------------------------------------------------------------------------------------------------------
create table csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF
(
  CPF_CNPJ    VARCHAR2(14) not null,
  ANO_REF     NUMBER(4) not null,
  COD_PART    VARCHAR2(60) not null,
  NIF         VARCHAR2(255) not null,
  ATRIBUTO    VARCHAR2(30) not null,
  VALOR       VARCHAR2(255) not null
 )
/

comment on table csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF is 'Tabela de integrac�o de campos flex field referente aos registro do Bloco de Demonstrativo de Consolida��o X353'
/

-- Add comments to the columns
comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.CPF_CNPJ is 'CPF/CNPJ da empresa que o produto pertence'
/

comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.ANO_REF  is 'Ano de refer�ncia'
/

comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.COD_PART is 'C�digo do Participante'
/

comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.NIF is 'N�mero de identifica��o fiscal de cada investida '
/

comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.ATRIBUTO is 'C�digo do atributo - nome do atributo. Valores v�lidos: COD_MULT_ORG / HASH_MULT_ORG'
/

comment on column csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF.VALOR is 'Valor referente ao c�digo do atributo'
/


grant select, insert, update, delete on csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF to CSF_OWN
/

grant select, insert, update, delete on csf_int.VW_CSF_DEMCONS_EXT_CONTR_IE_FF to CSF_WORK
/

commit
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INICIO Redmine Melhoria #53499: Altera��o registro X353
--------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------
Prompt INICIO Redmine #53500: Altera��o registro X357
--------------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_INT.VW_CSF_INVEST_DIRETAS_IE
(
  CPF_CNPJ     VARCHAR2(14) not null,
  ANO_REF      NUMBER(4) not null,
  COD_PART     VARCHAR2(60) not null,
  NIF          VARCHAR2(255) not null,
  SIGLA_PAIS   VARCHAR2(3) not null,
  RAZAO_SOCIAL VARCHAR2(60) not null,
  PERCENTUAL   NUMBER(8,4) not null
)
/

-- Add comments to the table
comment on table CSF_INT.VW_CSF_INVEST_DIRETAS_IE is 'Table/View de Integra��o do Bloco Investidoras Diretas X357'
/

-- Add comments to the columns
comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.CPF_CNPJ is 'CPF/CNPJ da empresa que o produto pertence'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.ANO_REF is 'Ano de refer�ncia'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.COD_PART is 'C�digo do Participante'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.NIF is 'N�mero de identifica��o fiscal de cada investida'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.SIGLA_PAIS is 'Sigla do Pa�s de cada investidora direta.'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.RAZAO_SOCIAL is 'Raz�o social de cada controlada, direta ou indireta, equiparada ou coligada em regime de compet�ncia.'
/

comment on column CSF_INT.VW_CSF_INVEST_DIRETAS_IE.PERCENTUAL is 'Valor do percentual de participa��o da investidora direta na investida informada no registro X340'
/

-- Create/Recreate indexes
create index CSF_INT.VWCSFINVESTDIRETASIE_IDX1 on CSF_INT.VW_CSF_INVEST_DIRETAS_IE (CPF_CNPJ, ANO_REF, COD_PART, NIF)
/

-- Grant/Revoke object privileges
grant select, insert, update, delete on CSF_INT.VW_CSF_INVEST_DIRETAS_IE to CSF_OWN
/

grant select, insert, update, delete on CSF_INT.VW_CSF_INVEST_DIRETAS_IE to CSF_WORK
/

commit
/

--------------------------------------------------------------------------------------------------------------------------------------
Prompt FIM Redmine #53500: Altera��o registro X357
--------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt FIM Release 2.9.0 - Semana de Desenvolvimento 06 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 07 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 08 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 09 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 10 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 11 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 12 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 13 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt INICIO e FIM Release 2.9.0 - Semana de Desenvolvimento 14 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Prompt FIM Release 2.9.0 - Semana de Desenvolvimento 14 - Alteracoes no CSF_INT
-------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------
Prompt FIM Release 2.9.0 - Alteracoes no CSF_INT
--------------------------------------------------------------------------------------------
