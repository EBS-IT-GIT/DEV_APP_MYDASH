Prompt Catalogar Triggers no CSF_OWN

Prompt T_A_I_U_Nota_Fiscal_01
@@T_A_I_U_Nota_Fiscal_01.trg

Prompt T_B_I_U_Nota_Fiscal_02
@@T_B_I_U_Nota_Fiscal_02.trg

Prompt Catalogar Objetos Invalidos
@@rec_obj_invalid.sql

