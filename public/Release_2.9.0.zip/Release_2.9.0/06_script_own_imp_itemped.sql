-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine IMP_ITEMPED
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.IMP_ITEMPED
(
  ID            NUMBER not null,
  ITEMPEDIDO_ID NUMBER not null,
  TIPOIMP_ID    NUMBER not null,
  VLR_BASE_CALC NUMBER(15,2),
  ALIQ_APLI     NUMBER(8,4),
  VLR_IMP_TRIB  NUMBER(15,2),
  DM_IND_CRED   NUMBER(2)
)
/

-- Add comments to the table
comment on table CSF_OWN.IMP_ITEMPED  is 'Tabela de impostos do item do pedido'
/

-- Add comments to the columns
comment on column CSF_OWN.IMP_ITEMPED.ID  is 'PK da tabela'
/

comment on column CSF_OWN.IMP_ITEMPED.ITEMPEDIDO_ID  is 'ID que relaciona a Tabela Item do Pedido'
/

comment on column CSF_OWN.IMP_ITEMPED.TIPOIMP_ID     is 'ID que relaciona a Tabela Tipo_Imposto'
/

comment on column CSF_OWN.IMP_ITEMPED.VLR_BASE_CALC  is 'Valor da Base de C�lculo'
/

comment on column CSF_OWN.IMP_ITEMPED.ALIQ_APLI      is 'Aliquota do imposto'
/

comment on column CSF_OWN.IMP_ITEMPED.VLR_IMP_TRIB   is 'Valor do Imposto Tributado'
/

comment on column CSF_OWN.IMP_ITEMPED.DM_IND_CRED    is 'Indicador se credita o imposto (0-N�o / 1-Sim)'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.IMP_ITEMPED  add constraint IMP_ITEMPED_PK primary key (ID)
/

alter table CSF_OWN.IMP_ITEMPED  add constraint IMP_ITEMPED_UK1 unique (ITEMPEDIDO_ID, TIPOIMP_ID)
/

alter table CSF_OWN.IMP_ITEMPED  add constraint ITEMPEDIDO_FK foreign key (ITEMPEDIDO_ID)  references CSF_OWN.ITEM_PEDIDO (ID)
/

alter table CSF_OWN.IMP_ITEMPED  add constraint TIPOIMP_FK foreign key (TIPOIMP_ID)  references CSF_OWN.TIPO_IMPOSTO (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.IMP_ITEMPED  add constraint IMP_ITEMPED_DMINDCRED_CK  check (DM_IND_CRED IN (0, 1))
/

-- Create/Recreate indexes
create index CSF_OWN.IMP_ITEMPED_ITEMPEDIDO_FK_I on CSF_OWN.IMP_ITEMPED (ITEMPEDIDO_ID)
/

create index CSF_OWN.IMP_ITEMPED_TIPOIMP_FK_I on CSF_OWN.IMP_ITEMPED (TIPOIMP_ID)
/

-- 08 - Cria��o dos Grants
grant select, insert, update, delete on csf_own.IMP_ITEMPED to CSF_WORK
/

-- 09 - Cria��o do Sin�nimo
--create or replace synonym csf_work.IMP_ITEMPED for csf_own.IMP_ITEMPED
--/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.IMPITEMPED_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'IMPITEMPED_SEQ', 'IMP_ITEMPED')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine IMP_ITEMPED
-------------------------------------------------------------------------------------------------------------------------------
