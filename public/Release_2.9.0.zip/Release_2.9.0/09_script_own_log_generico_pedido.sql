-- ======================================================================================================================= --
Prompt INI - Redmine 52621  Desenvolvimento - Novo processo de valida��o dos dados de integra��o
-- ======================================================================================================================= --
-- Create table
create table CSF_OWN.LOG_GENERICO_PEDIDO
(
  ID             NUMBER not null,
  PROCESSO_ID    NUMBER not null,
  DT_HR_LOG      DATE not null,
  REFERENCIA_ID  NUMBER,
  OBJ_REFERENCIA VARCHAR2(30),
  RESUMO         VARCHAR2(4000),
  MENSAGEM       VARCHAR2(4000) not null,
  DM_IMPRESSA    NUMBER(1) not null,
  DM_ENV_EMAIL   NUMBER(1) not null,
  CSFTIPOLOG_ID  NUMBER not null,
  EMPRESA_ID     NUMBER
)
/

-- Add comments to the table
comment on table CSF_OWN.LOG_GENERICO_PEDIDO  is 'Tabela de Log Gen�rico do PEDIDO'
/

-- Add comments to the columns
comment on column CSF_OWN.LOG_GENERICO_PEDIDO.ID  is 'Identificador do registro'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.PROCESSO_ID  is 'Id do processo'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.DT_HR_LOG    is 'Data de gera��o do log'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.REFERENCIA_ID  is 'ID de referencia do registro'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.OBJ_REFERENCIA  is 'Nome do objeto de referencia'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.RESUMO          is 'Resumo do log'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.MENSAGEM        is 'Mensagem detalhada'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.DM_IMPRESSA     is 'Valores v�lidos: 0-N�o; 1-Sim'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.DM_ENV_EMAIL    is 'Valores v�lidos: 0-N�o; 1-Sim'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.CSFTIPOLOG_ID   is 'ID relacionado a tabela CSF_TIPO_LOG'
/

comment on column CSF_OWN.LOG_GENERICO_PEDIDO.EMPRESA_ID      is 'ID relacionado a tabela EMPRESA'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.LOG_GENERICO_PEDIDO  add constraint LOGGENERICOPEDIDO_PK primary key (ID)
/

alter table CSF_OWN.LOG_GENERICO_PEDIDO  add constraint LOGGENERICOPED_CSFTIPOLOG_FK foreign key (CSFTIPOLOG_ID)  references CSF_OWN.CSF_TIPO_LOG (ID)
/

alter table CSF_OWN.LOG_GENERICO_PEDIDO  add constraint LOGGENERICOPED_EMPRESA_FK foreign key (EMPRESA_ID)  references CSF_OWN.EMPRESA (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.LOG_GENERICO_PEDIDO  add constraint LOGGENERICOPED_DMENVEMAIL_CK  check (DM_ENV_EMAIL IN (0, 1))
/

alter table CSF_OWN.LOG_GENERICO_PEDIDO  add constraint LOGGENERICOPED_DMIMPRESSA_CK  check (dm_impressa in(0,1))
/

-- Create/Recreate indexes
create index CSF_OWN.LOGGENERICOPED_CSFTIPOLOG_FK_I on CSF_OWN.LOG_GENERICO_PEDIDO (CSFTIPOLOG_ID)
/

create index CSF_OWN.LOGGENERICOPED_EMPRESA_FK_I on CSF_OWN.LOG_GENERICO_PEDIDO (EMPRESA_ID)
/

create index CSF_OWN.LOGGENERICOPEDIDO_IX_I on CSF_OWN.LOG_GENERICO_PEDIDO (OBJ_REFERENCIA, REFERENCIA_ID, DT_HR_LOG)
/

-- 08 - Cria��o dos Grants
grant select, insert, update, delete on csf_own.LOG_GENERICO_PEDIDO to CSF_WORK
/

-- 09 - Cria��o do Sin�nimo
--create or replace synonym csf_work.LOG_GENERICO_PEDIDO for csf_own.LOG_GENERICO_PEDIDO
--/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.LOGGENERICOPED_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'LOGGENERICOPED_SEQ', 'LOG_GENERICO_PEDIDO')
/

commit
/

-- ======================================================================================================================= --
Prompt FIM - Redmine 52621  Desenvolvimento - Novo processo de valida��o dos dados de integra��o 
-- ======================================================================================================================= --
