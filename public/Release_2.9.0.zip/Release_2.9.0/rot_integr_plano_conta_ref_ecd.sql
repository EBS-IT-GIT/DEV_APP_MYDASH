set serveroutput on;
declare
   --
   vn_fase                number;
   vt_plano_conta_ref_ecd plano_conta_ref_ecd%rowtype;
   vn_count_ant           number := 0;
   vn_count_up            number := 0;
   vn_count_ins           number := 0;
   vn_count_encerram      number := 0;
   vv_cod_ent_ref         cod_ent_ref.cod_ent_ref%type;
   --
   cursor c_tmp is
   select *
     from CSF_OWN.TMP_PCR
    where descr is not null
    order by cod_ent_ref
        , cod
        , nivel;
   --
begin
   --
   vn_fase := 1;
   --
   begin
      --
      select count(1)
        into vn_count_ant
        from CSF_OWN.plano_conta_ref_ecd;
      --
   end;
   --
   vn_count_up  := null;
   vn_count_ins := null;
   --
   for rec in c_tmp loop
    exit when c_tmp%notfound or (c_tmp%notfound) is null;
      --
      vn_fase := 2;
      vt_plano_conta_ref_ecd := null;
      --
      vn_fase := 3;
      --
      if trim(rec.cod) is null
       or trim(rec.cod) = '0' then
         dbms_output.put_line('C�digo do Plano de Conta Ref. ECD tem que ser informado:'|| trim(rec.cod));
      else
         vt_plano_conta_ref_ecd.cod_cta_ref := trim(rec.cod);
      end if;
      --
      vn_fase := 3.1;
      --
      vv_cod_ent_ref := rec.cod_ent_ref;
      --
      begin
         --
         select id
           into vt_plano_conta_ref_ecd.codentref_id
           from CSF_OWN.cod_ent_ref
          where cod_ent_ref = rec.cod_ent_ref;
         --
      exception
       when no_data_found then
          vt_plano_conta_ref_ecd.codentref_id := null;
      end;
      --
      vn_fase := 3.2;
      --
      vt_plano_conta_ref_ecd.descr           := trim(rec.descr);
      vt_plano_conta_ref_ecd.dt_ini          := to_date(rec.dt_ini,'dd/mm/yyyy');
      vt_plano_conta_ref_ecd.codnatpc_id     := null;
      --
      if trim(rec.natur) is not null then
         --
         begin
            --
            select id
              into vt_plano_conta_ref_ecd.codnatpc_id 
              from CSF_OWN.cod_nat_pc
             where cod_nat = lpad(rec.natur,2,0);
            --
         exception
           when no_data_found then
              vt_plano_conta_ref_ecd.codnatpc_id := null;
         end;
         --
      end if;
      --
      if trim(rec.dt_fin) <> '0' then
         vt_plano_conta_ref_ecd.dt_fin        := case when rec.dt_fin is null then null else to_date(rec.dt_fin,'dd/mm/yyyy') end;
      end if;
      --
      if trim(rec.cod_sup) <> '0' then
         vt_plano_conta_ref_ecd.pcrefecd_id_sup := pk_csf_ecd.fkg_plano_conta_ref_ecd_id ( ev_cod_cta_ref  => rec.cod_sup
                                                                                         , en_codentref_id => vt_plano_conta_ref_ecd.codentref_id
                                                                                         );
      end if;
      --
      if trim(rec.nivel) <> '0' then
      vt_plano_conta_ref_ecd.nivel    := trim(rec.nivel);
      end if;
      --
      if trim(rec.tipo) <> '0' then
         vt_plano_conta_ref_ecd.dm_ind_cta  := trim(rec.tipo);
      end if;
      --
      vn_fase := 3.3;
      --
      vt_plano_conta_ref_ecd.id := pk_csf_ecd.fkg_plano_conta_ref_ecd_id ( ev_cod_cta_ref  => rec.cod
                                                                         , en_codentref_id => vt_plano_conta_ref_ecd.codentref_id
                                                                         );
      --
      if nvl(vt_plano_conta_ref_ecd.id,0) > 0 then
         --
         vn_fase := 4;
         --
         update CSF_OWN.plano_conta_ref_ecd
            set cod_cta_ref     = vt_plano_conta_ref_ecd.cod_cta_ref
              , descr           = vt_plano_conta_ref_ecd.descr
              , codentref_id    = vt_plano_conta_ref_ecd.codentref_id
              , dm_ind_cta      = vt_plano_conta_ref_ecd.dm_ind_cta
              , dt_fin          = vt_plano_conta_ref_ecd.dt_fin
              , pcrefecd_id_sup = vt_plano_conta_ref_ecd.pcrefecd_id_sup
              , nivel           = vt_plano_conta_ref_ecd.nivel          
              , codnatpc_id     = vt_plano_conta_ref_ecd.codnatpc_id 
          where id              = vt_plano_conta_ref_ecd.id;
         --
         vn_count_up := nvl(vn_count_up,0) + 1;
         --
      else
         --
         vn_fase := 5;
         --
         select CSF_OWN.planocontarefecd_seq.nextval
           into vt_plano_conta_ref_ecd.id
           from dual;
         --
         insert into CSF_OWN.plano_conta_ref_ecd ( id
                                                 , cod_cta_ref
                                                 , descr
                                                 , codentref_id
                                                 , dm_ind_cta
                                                 , dt_ini
                                                 , dt_fin
                                                 , pcrefecd_id_sup
                                                 , nivel
                                                 , codnatpc_id )
                                           values( vt_plano_conta_ref_ecd.id
                                                 , vt_plano_conta_ref_ecd.cod_cta_ref
                                                 , vt_plano_conta_ref_ecd.descr
                                                 , vt_plano_conta_ref_ecd.codentref_id
                                                 , vt_plano_conta_ref_ecd.dm_ind_cta
                                                 , vt_plano_conta_ref_ecd.dt_ini
                                                 , vt_plano_conta_ref_ecd.dt_fin
                                                 , vt_plano_conta_ref_ecd.pcrefecd_id_sup
                                                 , vt_plano_conta_ref_ecd.nivel
                                                 , vt_plano_conta_ref_ecd.codnatpc_id );
         --
         vn_count_ins := nvl(vn_count_ins,0) + 1;
         --
      end if;
      --
   end loop;
   --
   -- Inativa os registros que n�o est�o no pacote
/*   update plano_conta_ref_ecd pcr set
     pcr.dt_fin = to_date('31/12/2016','dd/mm/yyyy')
   where pcr.dt_fin is null
     and not exists(select 1 
                      from TMP_PCR      tp
                         , cod_ent_ref cer
                    where cer.cod_ent_ref  = tp.cod_ent_ref 
                      and pcr.cod_cta_ref  = trim(tp.cod) 
                      and pcr.codentref_id = cer.id
                      and pcr.dt_ini       = to_date(tp.dt_ini,'ddmmyyyy'));
   --
   vn_count_encerram := sql%rowcount;
*/   --
   dbms_output.put_line('Quantidade que ja existia anteriormente: '|| vn_count_ant ||chr(10)||
                        'Quantidade alterado: '                    || vn_count_up  ||chr(10)||
                        'Quantidade inserido: '                    || vn_count_ins ||chr(10)||
                        'Quantidade encerrados: '                  || vn_count_encerram);
   --
   commit;
   --
   dbms_output.put_line('>>>>> rot_integr_plano_conta_ref_ecd.sql executada sem erros');
   --
exception
 when others then
    --
    rollback;
    --
    raise_application_error(-20101,'Problema na Rotina de Integra��o de Plano de Conta Referencial do ECD('||vn_fase||') COD_ENT_REF: '||
                            vt_plano_conta_ref_ecd.codentref_id ||' C�d. CTA.: '|| pk_csf_secf.fkg_cod_registroecf_id ( vt_plano_conta_ref_ecd.cod_cta_ref)|| ' Erro:'|| sqlerrm);
end;
/
