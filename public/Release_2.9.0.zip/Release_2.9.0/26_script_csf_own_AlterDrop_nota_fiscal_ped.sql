-- ======================================================================================================================= --
Prompt INI - Redmine 55188 - Criar tabela de Parametro de Recebimento - ALTERACAO E DROP NA NOTA_FISCAL_PED
-- ======================================================================================================================= --
Prompt Cria as novas colunas na tabela NOTA_FISCAL_PED
alter table csf_own.NOTA_FISCAL_PED add VL_IMP_TRIB_PIS NUMBER(15,2)
/

alter table csf_own.NOTA_FISCAL_PED add VL_IMP_TRIB_COFINS NUMBER(15,2) 
/

alter table csf_own.NOTA_FISCAL_PED add VL_IMP_TRIB_ISS NUMBER(15,2)  
/

alter table csf_own.NOTA_FISCAL_PED add VL_TOTAL_SERV NUMBER(15,2) 
/

alter table csf_own.NOTA_FISCAL_PED add VL_IMP_TRIB_IPI NUMBER(15,2)
/

alter table csf_own.NOTA_FISCAL_PED add VL_IMP_TRIB_ICMS NUMBER(15,2)
/


comment on column csf_own.NOTA_FISCAL_PED.VL_IMP_TRIB_PIS  is 'Valor do PIS'
/

comment on column csf_own.NOTA_FISCAL_PED.VL_IMP_TRIB_COFINS  is 'Valor do COFINS'
/

comment on column csf_own.NOTA_FISCAL_PED.VL_IMP_TRIB_ISS  is 'Valor Total do ISS'
/

comment on column csf_own.NOTA_FISCAL_PED.VL_TOTAL_SERV  is 'Valor total dos servicos'
/

comment on column csf_own.NOTA_FISCAL_PED.VL_IMP_TRIB_ICMS   is 'Valor Total do ICMS'
/

comment on column csf_own.NOTA_FISCAL_PED.VL_IMP_TRIB_IPI  is 'Valor Total do IPI'
/


Prompt Insere dados nos novos campos
declare
   cursor cur_nfs is 
      select nfp.id
           , nfp.VL_RET_IRRF      -- n�o ter� mais esse valor 
           , nfp.VL_RET_PREV      -- n�o ter� mais esse valor
           , nfp.VL_RET_PIS       -- VL_IMP_TRIB_PIS
           , nfp.VL_RET_COFINS    -- VL_IMP_TRIB_COFINS
           , nfp.VL_RET_ISS       -- VL_IMP_TRIB_ISS
        from csf_own.nota_fiscal_ped nfp; 
begin
   for rec_nfs in cur_nfs loop
      exit when cur_nfs%notfound or (cur_nfs%notfound) is null;
      --
      update csf_own.nota_fiscal_ped
         set VL_IMP_TRIB_PIS    = rec_nfs.VL_RET_PIS
           , VL_IMP_TRIB_COFINS = rec_nfs.VL_RET_COFINS
           , VL_IMP_TRIB_ISS    = rec_nfs.VL_RET_ISS
           , VL_RET_IRRF        = null -- n�o ter� mais esse valor 
           , VL_RET_PREV        = null -- n�o ter� mais esse valor
           , VL_RET_PIS         = null -- VL_IMP_TRIB_PIS
           , VL_RET_COFINS      = null -- VL_IMP_TRIB_COFINS
           , VL_RET_ISS         = null -- VL_IMP_TRIB_ISS
       where id = rec_nfs.id;    
      --
   end loop;      
   --
   commit;
   -- 
end;
/

-- Drop columns 
alter table csf_own.NOTA_FISCAL_PED drop column VL_RET_IRRF
/

alter table csf_own.NOTA_FISCAL_PED drop column VL_RET_PREV
/

alter table csf_own.NOTA_FISCAL_PED drop column VL_RET_PIS
/

alter table csf_own.NOTA_FISCAL_PED drop column VL_RET_COFINS
/

alter table csf_own.NOTA_FISCAL_PED drop column VL_RET_ISS
/

alter table csf_own.NOTA_FISCAL_PED drop column VL_OUTRAS_RET
/

commit
/

-- ======================================================================================================================= --
Prompt FIM - Redmine 55188 - Criar tabela de Parametro de Recebimento - ALTERACAO E DROP NA NOTA_FISCAL_PED
-- ======================================================================================================================= --


