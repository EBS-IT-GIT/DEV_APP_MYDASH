-----------------------------------------------------------------------------
Prompt Inicio Redmine #47050 - Geracao DCIP
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
Prompt *** TABLE REGISTRO_DCIP ***
-----------------------------------------------------------------------------
-- Drop table and sequence
declare

  -- Check constraints table
  cursor c_del_table is
    select owner,
           constraint_name,
           constraint_type,
           table_name,
           r_owner,
           r_constraint_name
      from all_constraints
     where constraint_type = 'R' -- "Referential integrity"
       and r_constraint_name in (select constraint_name
                                   from all_constraints
                                  where constraint_type in ('P', 'U') -- "Unique" or "Primary key" 
                                    and table_name = 'REGISTRO_DCIP');
  v_exist varchar2(1);
                                    
begin

  for rec in c_del_table loop
    exit when c_del_table%notfound or(c_del_table%notfound) is null;
    
      execute immediate 'alter table '||rec.table_name||' drop constraint '||rec.constraint_name||'';
    
  end loop;
  
  -- Check if the table and sequence exist already
  begin
    select 'S'
      into v_exist
      from all_tables a
     where a.table_name = 'REGISTRO_DCIP';
  exception
    when others then
      v_exist := 'N';
  end;

  if v_exist = 'S' then
   execute immediate 'drop table registro_dcip';
   execute immediate 'drop sequence registrodcip_seq';  
 end if;

end;
/

-- Create table
create table csf_own.registro_dcip(id        number not null,
                                   codigo    varchar2(10) not null,
                                   descricao varchar2(100) not null,
   constraint registrodcip_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.registro_dcip is 'Tabela de cadastro de registros utilizados na gera��o da DCIP'
/

-- Add comments to the columns
comment on column csf_own.registro_dcip.codigo is 'C�digo de identifica��o do registro'
/

comment on column csf_own.registro_dcip.descricao is 'Descri��o do registro'
/

-- Create constraint unique
alter table csf_own.registro_dcip
 add constraint registrodcip_uk unique (codigo)
/

-- Create sequence
create sequence csf_own.registrodcip_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.registro_dcip to csf_work
/   

grant select on csf_own.registrodcip_seq to csf_work
/

-- Insert records registros 
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '040', 'Discrimina��o de outros cr�ditos');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '050', 'Totalizador do registro "040" para simples confer�ncia');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '060', 'Discrimina��o de cr�ditos presumidos');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '070', 'Totalizador do registro "060" para simples confer�ncia');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '080', 'Discrimina��o de estorno de d�bitos');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '090', 'Totalizador do registro "080" para simples confer�ncia');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '100', 'Discrimina��o de cr�dito de contribui��o ou aplica��o em fundos');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '110', 'Totalizador do registro "100" para simples confer�ncia');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '140', 'Discrimina��o de cr�dito imposto retido substitui��o tribut�ria');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '150', 'Totalizador do registro "140" para simples confer�ncia');
insert into csf_own.registro_dcip (id, codigo, descricao) values (csf_own.registrodcip_seq.nextval, '900', 'Registro totalizador do Arquivo');

commit
/

-----------------------------------------------------------------------------
Prompt *** TABLE GENERICA_DCIP ***
-----------------------------------------------------------------------------
declare

  -- Check constraints table
  cursor c_del_table is
    select owner,
           constraint_name,
           constraint_type,
           table_name,
           r_owner,
           r_constraint_name
      from all_constraints
     where constraint_type = 'R' -- "Referential integrity"
       and r_constraint_name in (select constraint_name
                                   from all_constraints
                                  where constraint_type in ('P', 'U') -- "Unique" or "Primary key" 
                                    and table_name = 'GENERICA_DCIP');
 v_exist varchar2(1);
                                    
begin

  for rec in c_del_table loop
    exit when c_del_table%notfound or(c_del_table%notfound) is null;
    
      execute immediate 'alter table '||rec.table_name||' drop constraint '||rec.constraint_name||'';

  end loop;
  
  -- Check if the table and sequence exist already
  begin
    select 'S'
      into v_exist
      from all_tables a
     where a.table_name = 'GENERICA_DCIP';
  exception
    when others then
      v_exist := 'N';
  end;

  if v_exist = 'S' then
   execute immediate 'drop table generica_dcip';
   execute immediate 'drop sequence genericadcip_seq'; 
 end if;
   

end;
/

-- Create table
create table csf_own.generica_dcip(id              number not null,
                                   registrodcip_id number not null,
                                   codigo          varchar2(10) not null,
                                   descricao       varchar2(500) not null,
                                   dt_ini          date not null,
                                   dt_fim          date,
                                   permite_dup     number,
                                   util_sat        number,
                                   num_benef       varchar2(100),
   constraint genericadcip_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.generica_dcip is 'Tabela gen�rica de cadastro de c�digos dos registros'   
/

-- Add comments to the columns
comment on column csf_own.generica_dcip.codigo is 'C�digo de identifica��o'
/

comment on column csf_own.generica_dcip.registrodcip_id is 'ID do registro (REGISTRO_DCIP)'
/

comment on column csf_own.generica_dcip.descricao is 'Descri��o do c�digo'
/

comment on column csf_own.generica_dcip.dt_ini is 'Data inicial (In�cio da vig�ncia)'
/

comment on column csf_own.generica_dcip.dt_fim is 'Data final (Fim da vig�ncia)'
/

comment on column csf_own.generica_dcip.permite_dup is 'Permite Duplicar: 0 - N�o / 1 - Sim'
/

comment on column csf_own.generica_dcip.util_sat is 'N� S@T Utilizado Tabela 9032'
/

comment on column csf_own.generica_dcip.num_benef is 'N� do Benef�cio TTD/RE'
/

-- Create constraint foreign
alter table csf_own.generica_dcip
  add constraint genericadcip_registrodcip_fk1 foreign key (registrodcip_id)
  references csf_own.registro_dcip(id)
/

-- Create constraint unique
alter table csf_own.generica_dcip
 add constraint genericadcip_uk unique (registrodcip_id, codigo)
/

-- Create sequence
create sequence csf_own.genericadcip_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.generica_dcip to csf_work
/   

grant select on csf_own.genericadcip_seq to csf_work
/


commit
/

-----------------------------------------------------------------------------
Prompt *** TABLE APURA_DCIP ***
-----------------------------------------------------------------------------
-- Drop table and sequence
declare

  v_exist varchar2(1);

begin
 
  -- Check if the table and sequence exist already
  begin
    select 'S'
      into v_exist
      from all_tables a
     where a.table_name = 'APURA_DCIP';
  exception
    when others then
      v_exist := 'N';
  end;

  if v_exist = 'S' then
    execute immediate 'drop table apura_dcip';
    execute immediate 'drop sequence apuradcip_seq';
  end if;

end;
/

-- Create table
create table csf_own.apura_dcip(id               number not null,
                                abertdcip_id     number not null,
                                sequencia        number(3) not null,
                                ident_regime     varchar2(15),
                                valor            number(15,2) not null,
                                dm_orig          number(2),
                                dm_num_sat       number(2),
                                registrodcip_id  number,
                                genericadcip_id  number,
                                dm_situacao      number(2) not null,
   constraint apuradcip_pk primary key(id) using index tablespace csf_index) 
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.apura_dcip is 'Tabela referente a apura��o dos registros de abertura da DCIP'
/

-- Add comments to the columns
comment on column csf_own.apura_dcip.abertdcip_id is 'ID da abertura da DCIP (ABERTURA_DCIP)'
/

comment on column csf_own.apura_dcip.sequencia is 'Seq��ncia come�ando em 1 para o primeiro registro'
/

comment on column csf_own.apura_dcip.ident_regime is 'Identifica��o do Regime ou da Autoriza��o Especial'
/

comment on column csf_own.apura_dcip.valor is 'Valor do cr�dito utilizado na apura��o'
/

comment on column csf_own.apura_dcip.dm_orig is 'Origem do cr�dito'
/

comment on column csf_own.apura_dcip.dm_num_sat is 'C�digo do n�mero SAT (DOMINIO)'
/

comment on column csf_own.apura_dcip.registrodcip_id is 'ID do registro (REGISTROS_DCIP)'
/

comment on column csf_own.apura_dcip.genericadcip_id is 'ID do c�digo (GENERICA_DCIP)'
/

comment on column csf_own.apura_dcip.dm_situacao is 'Situa��o: 0-Aberto / 1-Calculada / 2-Erro no c�lculo / 3-Validado / 4-Erro de valida��o'
/

-- Create constraint foreign
alter table csf_own.apura_dcip
  add constraint apuradcip_aberturadcip_fk foreign key (abertdcip_id)
  references csf_own.abertura_dcip(id)
/ 

alter table csf_own.apura_dcip
  add constraint apuradcip_registrodcip_fk foreign key (registrodcip_id)
  references csf_own.registro_dcip(id)
/

alter table csf_own.apura_dcip
  add constraint apuradcip_genericadcip_fk foreign key (genericadcip_id)
  references csf_own.generica_dcip(id)
/

-- Create sequence
create sequence csf_own.apuradcip_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

grant select, insert, update, delete on csf_own.apura_dcip to csf_work
/

grant select on csf_own.apuradcip_seq to csf_work
/

commit
/

-----------------------------------------------------------------------------
Prompt *** TABLE REGISTRO_TOTAL_DCIP ***
-----------------------------------------------------------------------------
-- Create table
create table csf_own.registro_total_dcip(id              number not null,
                                         aberturadcip_id number not null,
                                         referencia      varchar2(15),
                                         registrodcip_id number not null,
                                         valor           number(15,2),
                                         dm_situacao     number(2) not null,
   constraint registrototaldcip_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.registro_total_dcip is 'Tabela de totais dos registros.'
/

-- Add comments to the columns
comment on column csf_own.registro_total_dcip.aberturadcip_id is 'ID da abertura DCIP (ABERTURA_DCIP)'
/

comment on column csf_own.registro_total_dcip.referencia is 'Refer�ncia do arquivo'
/

comment on column csf_own.registro_total_dcip.registrodcip_id is 'ID do registro (REGISTRO_DCIP)'
/

comment on column csf_own.registro_total_dcip.valor is 'Valor total dos registros'
/

comment on column csf_own.apura_dcip.dm_situacao is 'Situa��o: 0-Aberto / 1-Calculada / 2-Erro no c�lculo'
/

-- Create constraint foreign
alter table csf_own.registro_total_dcip
  add constraint regtotdcip_aberturadcip_fk1 foreign key (aberturadcip_id)
  references csf_own.abertura_dcip(id)
/

-- Create constraint unique
alter table csf_own.registro_total_dcip
 add constraint registrototaldcip_uk unique (aberturadcip_id, registrodcip_id)
/

-- Create sequence
create sequence csf_own.registrototaldcip_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.registro_total_dcip to csf_work
/   

grant select on csf_own.registrototaldcip_seq to csf_work
/


commit
/

-----------------------------------------------------------------------------
Prompt *** INSERT ESTR_ARQ_DCIP ***
-----------------------------------------------------------------------------
-- Create table
create table csf_own.estr_arq_dcip(id              number not null,
                                   aberturadcip_id number not null,
                                   registrodcip_id number not null,
                                   sequencia       number not null,
                                   conteudo        long not null,
   constraint estrarqdcip_pk primary key(id) using index tablespace csf_index)
tablespace csf_data
/

-- Add comments to the table
comment on table csf_own.estr_arq_dcip is  'Tabela de abertura da gera��o do arquivo da DCIP'
/

-- Add comments to the columns
comment on column csf_own.estr_arq_dcip.aberturadcip_id is 'ID relacionado a tabela ABERTURA_DCIP'
/

comment on column csf_own.estr_arq_dcip.registrodcip_id is 'ID relacionado a tabela REGISTRO_DCIP'
/

comment on column csf_own.estr_arq_dcip.sequencia is 'Sequencia de gera��o do arquivo'
/

comment on column csf_own.estr_arq_dcip.conteudo is 'Conte�do da linha do arquivo'
/


-- Create sequence
create sequence csf_own.estrarqdcip_seq
increment by 1
start with   1
nominvalue
nomaxvalue
nocycle
nocache
/

-- grants table and sequence 
grant select, insert, update, delete on csf_own.estr_arq_dcip to csf_work
/   

grant select on csf_own.estrarqdcip_seq to csf_work
/

commit
/

-----------------------------------------------------------------------------
Prompt *** INSERT GENERICA_DCIP ***
-----------------------------------------------------------------------------
begin

  -- Insert table - Registro 40 - Table Gen�rica - DCIP 2
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 1, 'AQUISI��O DE ENERGIA EL�TRICA POR PRESTADOR DE SERVI�O DE TELECOMUNICA��ES', '01/04/2008', '01/05/2014', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'AQUISI��O DE ENERGIA EL�TRICA POR PRESTADOR DE SERVI�O DE TELECOMUNICA��ES'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 1;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 2, 'IMPOSTO PAGO INDEVIDAMENTE POR ERRO DE FATO NA ESCRITURA��O DOS LIVROS OU PREENCHIMENTO DO DARE', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'IMPOSTO PAGO INDEVIDAMENTE POR ERRO DE FATO NA ESCRITURA��O DOS LIVROS OU PREENCHIMENTO DO DARE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 2;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 3, 'CR�DITO EXTEMPOR�NEO DECORRENTE DO N�O REGISTRO OU DE ERRO NA ESCRITA FISCAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO EXTEMPOR�NEO DECORRENTE DO N�O REGISTRO OU DE ERRO NA ESCRITA FISCAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 3;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 4, 'NA TRANSFER�NCIA DE PROPRIEDADE DE ESTABELECIMENTO, PREVISTA NO ART. 6� VI DO RICMS', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'NA TRANSFER�NCIA DE PROPRIEDADE DE ESTABELECIMENTO, PREVISTA NO ART. 6� VI DO RICMS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 4;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 5, 'NAS OPERA��ES COM PRODUTOS AGROPECU�RIOS A QUE SE REFERE O ART. 41 DO RICMS', '01/04/2008', '01/04/2008', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'NAS OPERA��ES COM PRODUTOS AGROPECU�RIOS A QUE SE REFERE O ART. 41 DO RICMS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 5;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 6, 'TRANSFER�NCIA DE BENS DO ATIVO PERMANENTE PARA OUTRO ESTABELECIMENTO DO MESMO TITULAR', '01/04/2008', '01/04/2008', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'TRANSFER�NCIA DE BENS DO ATIVO PERMANENTE PARA OUTRO ESTABELECIMENTO DO MESMO TITULAR'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 6;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 7, 'SA�DA DO REGIME DE ESTIMATIVA FISCAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DO REGIME DE ESTIMATIVA FISCAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 7;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 8, 'VENDA DE MERCADORIA SUJEITA A SUBSTITUI��O TRIBUT�RIA PARA �RG�O P�BLICO COM ISEN��O', '01/04/2008', '01/07/2015', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'VENDA DE MERCADORIA SUJEITA A SUBSTITUI��O TRIBUT�RIA PARA �RG�O P�BLICO COM ISEN��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 8;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 9, 'VENDA � DEFICIENTE F�SICO, COM ISEN��O, DE VE�CULO COM ICMS RETIDO POR SUBST TRIB', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'VENDA � DEFICIENTE F�SICO, COM ISEN��O, DE VE�CULO COM ICMS RETIDO POR SUBST TRIB'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 9;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 10, 'CR�DITO DO ESTOQUE PELO SUBSTITU�DO NA EXCLUS�O DE MERCADORIA DO REGIME DE SUBSTITUI��O TRIBUT�RIA', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO ESTOQUE PELO SUBSTITU�DO NA EXCLUS�O DE MERCADORIA DO REGIME DE SUBSTITUI��O TRIBUT�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 10;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 11, 'CR�DITO DO ESTOQUE NO DESENQUADRAMENTO DO SIMPLES NACIONAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO ESTOQUE NO DESENQUADRAMENTO DO SIMPLES NACIONAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 11;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 12, 'RECUPERA��O DE CR�DITO POR DECIS�O JUDICIAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RECUPERA��O DE CR�DITO POR DECIS�O JUDICIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 12;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 13, 'UTILIZA��O DE SALDO DE AUC DE INTEGRALIZA��O DE CAPITAL', '01/04/2008', '', 0, 2, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'UTILIZA��O DE SALDO DE AUC DE INTEGRALIZA��O DE CAPITAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 13;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 14, 'NA SA�DA POSTERIOR � IMPORTA��O, PARA QUE A AL�QUOTA RESULTE EM 3% -EXIGIDO REG. ESPECIAL - PR�-EMPREGO', '01/04/2008', '', 0, 1, 207);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'NA SA�DA POSTERIOR � IMPORTA��O, PARA QUE A AL�QUOTA RESULTE EM 3% -EXIGIDO REG. ESPECIAL - PR�-EMPREGO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 14;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 15, 'SA�DA DE MERCADORIA TRIBUTADA RECEBIDA PARA USO OU CONSUMO', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE MERCADORIA TRIBUTADA RECEBIDA PARA USO OU CONSUMO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 15;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 16, 'CR�DITO AUTORIZADO EM DECIS�O DO CONSELHO ESTADUAL DE CONTRIBUINTES', '01/04/2008', '', 0, 8, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO AUTORIZADO EM DECIS�O DO CONSELHO ESTADUAL DE CONTRIBUINTES'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 16;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 17, 'CR�DITO PROPORCIONAL DE ICMS PR�PRIO OU RETIDO DA ENERGIA EL�TRICA COM BASE EM LAUDO T�CNI', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL DE ICMS PR�PRIO OU RETIDO DA ENERGIA EL�TRICA COM BASE EM LAUDO T�CNI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 17;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 18, 'CR�DITO DO SERVI�O DE COMUNICA��O PROPORCIONAL � EXPORTA��O', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO SERVI�O DE COMUNICA��O PROPORCIONAL � EXPORTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 18;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 19, 'CR�DITO DECORRENTE DE COMPEX', '01/04/2008', '', 0, 1, 129);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DECORRENTE DE COMPEX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 19;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 20, 'SA�DA TRIBUTADA DE MERCADORIA RECEBIDA PARA ATIVO PERMANENTE', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA TRIBUTADA DE MERCADORIA RECEBIDA PARA ATIVO PERMANENTE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 20;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 21, 'CR�DITO PROPORCIONAL � SA�DA TRIBUTADA CUJA ENTRADA SE DESTINAVA � ATIVIDADES SUJEITAS AO ISS', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL � SA�DA TRIBUTADA CUJA ENTRADA SE DESTINAVA � ATIVIDADES SUJEITAS AO ISS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 21;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 22, 'CR�DITO REFERENTE DESCONTOS INCONDICIONAIS CONFORME REG. ESPECIAL OBRIG. ACESS�RIA', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO REFERENTE DESCONTOS INCONDICIONAIS CONFORME REG. ESPECIAL OBRIG. ACESS�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 22;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 23, 'CR�DITO N�O APROPRIADO NA ENTRADA CONFORME REG. ESPECIAL OBRIG. ACESS�RIA', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO N�O APROPRIADO NA ENTRADA CONFORME REG. ESPECIAL OBRIG. ACESS�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 23;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 24, 'UTILIZA��O DE SALDO DE AUC CONFORME DECRETO N� 4.994/06, ART. 2�', '01/04/2008', '', 1, 2, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'UTILIZA��O DE SALDO DE AUC CONFORME DECRETO N� 4.994/06, ART. 2�'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 24;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 25, 'CR�DITO DA MERCADORIA RECEBIDA COM SUBST. TRIB, QUANDO EFETUADA NOVA RETEN��O', '01/04/2008', '01/08/2013', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DA MERCADORIA RECEBIDA COM SUBST. TRIB, QUANDO EFETUADA NOVA RETEN��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 25;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 26, 'CR�DITO AUTORIZADO EM PROCESSO ADMINISTRATIVO REGULAR DA SEF, EXCETO DE RESTITUI��O DE ICMS E DE REGIME ESPECIAL (TTD)', '01/04/2008', '', 1, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO AUTORIZADO EM PROCESSO ADMINISTRATIVO REGULAR DA SEF, EXCETO DE RESTITUI��O DE ICMS E DE REGIME ESPECIAL (TTD)'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 26;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 27, 'CR�DITO PROPORCIONAL � SA�DA TRIBUTADA DE MERCADORIA INICIALMENTE PREVISTA PARA OCORRER SEM D�BITO, INCLUSIVE REDU��O BASE C�LCULO', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL � SA�DA TRIBUTADA DE MERCADORIA INICIALMENTE PREVISTA PARA OCORRER SEM D�BITO, INCLUSIVE REDU��O BASE C�LCULO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 27;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 28, 'CR�DITO PROPORCIONAL � MERCADORIA DEVOLVIDA, CUJO IMPOSTO SUBST. TRIB, FOI RECOLHIDO NO INGRESSO DA MESMA NO REGIME', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL � MERCADORIA DEVOLVIDA, CUJO IMPOSTO SUBST. TRIB, FOI RECOLHIDO NO INGRESSO DA MESMA NO REGIME'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 28;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 29, 'CR�DITO CENTRALIZA��O DA APURA��O ST CONFORME REGIME. ESPECIAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO CENTRALIZA��O DA APURA��O ST CONFORME REGIME. ESPECIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 29;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 30, 'CR�DITO PELO PAGAMENTO DE DEFESA PR�VIA OU NOT. FISCAL DE ICMS DEVIDO NA IMPORTA��O E DE MERCADORIA RECEBIDA OU EM ESTOQUE DESACOBERTADA DE NF', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO PAGAMENTO DE DEFESA PR�VIA OU NOT. FISCAL DE ICMS DEVIDO NA IMPORTA��O E DE MERCADORIA RECEBIDA OU EM ESTOQUE DESACOBERTADA DE NF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 30;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 31, 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O COM EMISS�O DE DI - DECLARA��O DE IMPORTA��O', '01/04/2008', '', 1, 5, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O COM EMISS�O DE DI - DECLARA��O DE IMPORTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 31;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 32, 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O COM EMISS�O DE DSI - DECLARA��O SIMPLIFICADA IMPORTA��O', '01/04/2008', '', 1, 6, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O COM EMISS�O DE DSI - DECLARA��O SIMPLIFICADA IMPORTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 32;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 33, 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O ATRAV�S DE RTS - REGIME TRIBUTA��O SIMPLIFICADA', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RECOLHIDO POR OCASI�O DA IMPORTA��O ATRAV�S DE RTS - REGIME TRIBUTA��O SIMPLIFICADA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 33;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 34, 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS ANTECIPADO (C�DIGO DE RECEITA 1759) RELATIVO � SA�DA SUBSEQUENTE � IMPORTA��O', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS ANTECIPADO (C�DIGO DE RECEITA 1759) RELATIVO � SA�DA SUBSEQUENTE � IMPORTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 34;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 35, 'CR�DITO DO IMPOSTO DEVIDO NA IMPORTA��O COMPENSADO COM SALDO CREDOR ACUMULADO DECORRENTE DE IMPORTA��O', '01/04/2008', '', 1, 2, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO DEVIDO NA IMPORTA��O COMPENSADO COM SALDO CREDOR ACUMULADO DECORRENTE DE IMPORTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 35;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 36, 'CR�DITO DO IMPOSTO RELATIVO � AQUISI��O DE ATACADISTAS DE OUTRAS UNIDADES DA FEDERA��O', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RELATIVO � AQUISI��O DE ATACADISTAS DE OUTRAS UNIDADES DA FEDERA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 36;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 37, 'CR�DITO DO IMPOSTO DEVIDO POR RESPONSABILIDADE TRIBUT�RIA', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO DEVIDO POR RESPONSABILIDADE TRIBUT�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 37;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 38, 'CR�DITO DE IMPOSTO RELATIVO � OUTROS PAGAMENTOS DEVIDOS POR OCASI�O DO FATO GERADOR', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DE IMPOSTO RELATIVO � OUTROS PAGAMENTOS DEVIDOS POR OCASI�O DO FATO GERADOR'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 38;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 39, 'CR�DITO DO IMPOSTO RECOLHIDO NA IMPORTA��O POR MEIO DE ENCOMENDAS A�REAS INTERNACIONAIS TRANSPORTADAS POR "COURIER"', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RECOLHIDO NA IMPORTA��O POR MEIO DE ENCOMENDAS A�REAS INTERNACIONAIS TRANSPORTADAS POR "COURIER"'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 39;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 40, 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO EM SUBSTITUI��O AOS DEMAIS CR�DITOS PELA ENTRADA', '01/04/2008', '', 0, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO EM SUBSTITUI��O AOS DEMAIS CR�DITOS PELA ENTRADA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 40;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 41, 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO O FABRICANTE DO SETOR T�XTIL DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO DO AN2, ART. 21, IX - RICMS', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO O FABRICANTE DO SETOR T�XTIL DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO DO AN2, ART. 21, IX - RICMS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 41;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 42, 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO O INDUSTRIAL FABRICANTE DE VINHO DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO DO AN2, ART. 21, X - RICMS', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO SOBRE ESTOQUE QUANDO O INDUSTRIAL FABRICANTE DE VINHO DEIXAR DE UTILIZAR O CR�DITO PRESUMIDO DO AN2, ART. 21, X - RICMS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 42;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 43, 'CR�DITO PROPORCIONAL � SA�DA INTERESTADUAL TRIBUTADA DE MERCADORIA RECEBIDA COM A LIMITA��O PREVISTA NO ART. 35-A E 35-B', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL � SA�DA INTERESTADUAL TRIBUTADA DE MERCADORIA RECEBIDA COM A LIMITA��O PREVISTA NO ART. 35-A E 35-B'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 43;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 44, 'CR�DITO DO IMPOSTO DESTACADO PROPORCIONAL � MERCADORIA DEVOLVIDA RECEBIDA COM RETEN��O DA SUBSTITUI��O TRIBUT�RIA', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO DESTACADO PROPORCIONAL � MERCADORIA DEVOLVIDA RECEBIDA COM RETEN��O DA SUBSTITUI��O TRIBUT�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 44;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 45, 'CR�DITO DO ICMS ST PR�PRIO E RETIDO DECORRENTE DAS SA�DAS DESTINADAS � DETENTORES DE PR�-EMPREGO', '01/04/2008', '', null, null, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO ICMS ST PR�PRIO E RETIDO DECORRENTE DAS SA�DAS DESTINADAS � DETENTORES DE PR�-EMPREGO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 45;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 46, 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS ANTECIPADO DE PER�ODOS ANTERIORES INFORMADOS NA DDE (C�DIGO DE RECEITA 1953)', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS ANTECIPADO DE PER�ODOS ANTERIORES INFORMADOS NA DDE (C�DIGO DE RECEITA 1953)'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 46;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 47, 'CR�DITO ICMS DA ENTRADA DE G�S NATURAL DECORRENTE DE AQUISI��O POR EMPRESA CONCESSION�RIA', '01/04/2008', '', null, null, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO ICMS DA ENTRADA DE G�S NATURAL DECORRENTE DE AQUISI��O POR EMPRESA CONCESSION�RIA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 47;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 48, 'CR�DITO DO IMPOSTO RETIDO ST NOS CASOS DE FURTO, ROUBO, EXTRAVIO OU DETERIORA��O DE MERCADORIAS - AN3, ART. 22, � 2�', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RETIDO ST NOS CASOS DE FURTO, ROUBO, EXTRAVIO OU DETERIORA��O DE MERCADORIAS - AN3, ART. 22, � 2�'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 48;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 49, 'CR�DITO RELATIVO AO ICMS DEVIDO PELA IMPORTA��O COM EMISS�O DE DI E RECOLHIDO PELO REVIGORAR III (C�DIGO DE RECEITA 6319 E 6335) - LEI 15.510/11, ART. 1�', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO AO ICMS DEVIDO PELA IMPORTA��O COM EMISS�O DE DI E RECOLHIDO PELO REVIGORAR III (C�DIGO DE RECEITA 6319 E 6335) - LEI 15.510/11, ART. 1�'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 49;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 50, 'CR�DITO RELATIVO AO ICMS DEVIDO POR OCASI�O DA ENTRADA NO ESTADO E RECOLHIDO PELO REVIGORAR III, (C�DIGO DE RECEITA 6327) - LEI 15.510/11, ART. 24', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO AO ICMS DEVIDO POR OCASI�O DA ENTRADA NO ESTADO E RECOLHIDO PELO REVIGORAR III, (C�DIGO DE RECEITA 6327) - LEI 15.510/11, ART. 24'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 50;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 51, 'APROPRIA��O DA RESTITUI��O EM FORMA DE CR�DITO PARA LAN�AMENTO EM CONTA GR�FICA CONFORME PROTOCOLO DE RECONHECIMENTO DE CR�DITO - PRC', '01/04/2008', '', 1, 10, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APROPRIA��O DA RESTITUI��O EM FORMA DE CR�DITO PARA LAN�AMENTO EM CONTA GR�FICA CONFORME PROTOCOLO DE RECONHECIMENTO DE CR�DITO - PRC'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 51;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 52, 'CR�DITO PROPORC � SA�DA TRIB DE MERCAD INICIALMENTE PREVISTA PARA OCORRER COM CR�D PRESUMIDO EM SUBSTITUI��O AO DA ENTRADA', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORC � SA�DA TRIB DE MERCAD INICIALMENTE PREVISTA PARA OCORRER COM CR�D PRESUMIDO EM SUBSTITUI��O AO DA ENTRADA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 52;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 53, 'CR�DITO PELO REMETENTE DA MERCADORIA, RESPONS�VEL PELO ICMS ST RETIDO NA PRESTA��O DE SERVI�O DE TRANSPORTE REALIZADO COM CL�USULA CIF', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO REMETENTE DA MERCADORIA, RESPONS�VEL PELO ICMS ST RETIDO NA PRESTA��O DE SERVI�O DE TRANSPORTE REALIZADO COM CL�USULA CIF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 53;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 54, 'CR�DITO CONTRIBUI��O FUNDOS VINCULADOS A TTDS ESPEC�FICOS, NO DESFAZIMENTO VENDAS E DEVOLU��O DE MERCADORIAS', '01/04/2008', '', 0, 1, '384, 409, 410, 411, 422, 425 e 460');
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO CONTRIBUI��O FUNDOS VINCULADOS A TTDS ESPEC�FICOS, NO DESFAZIMENTO VENDAS E DEVOLU��O DE MERCADORIAS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 54;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 55, 'CR�DITO DA DIFA RECOLHIDA NA ENTRADA DE MERCADORIA DE OUTRA UF PARA COMERC. OU INDUSTR. (COD. RECEITA 2518)', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DA DIFA RECOLHIDA NA ENTRADA DE MERCADORIA DE OUTRA UF PARA COMERC. OU INDUSTR. (COD. RECEITA 2518)'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 55;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 56, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO TRIBUT�RIO QUE PROMOVER NOVA RETEN��O PARA OUTRA UF NAS SA�DAS J� SUBMETIDAS AO REGIME', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO TRIBUT�RIO QUE PROMOVER NOVA RETEN��O PARA OUTRA UF NAS SA�DAS J� SUBMETIDAS AO REGIME'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 56;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 57, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 CASO PROMOVA NOVA RETEN��O PARA OUTRA UF', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 CASO PROMOVA NOVA RETEN��O PARA OUTRA UF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 57;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 58, 'CR�DITO IMPOSTO RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 NA DEVOLU��O OU DESFAZIMENTO DO NEG�CIO', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 NA DEVOLU��O OU DESFAZIMENTO DO NEG�CIO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 58;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 59, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO QUE EFETUAR NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O ESTEJA SUJEITA A ST', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO QUE EFETUAR NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O ESTEJA SUJEITA A ST'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 59;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 60, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN 3 E EFETUOU NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O SUJEITA A ST', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN 3 E EFETUOU NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O SUJEITA A ST'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 60;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 61, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO DESTINAT�RIO QUE REALIZE VENDA A CONSUMIDOR DE FORMA N�O PRESENCIAL, QUANDO MERCADORIA J� SUBMETIDA A ST-AN. 3,ART.12', '01/04/2008', '', 0, 1, 353);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO DESTINAT�RIO QUE REALIZE VENDA A CONSUMIDOR DE FORMA N�O PRESENCIAL, QUANDO MERCADORIA J� SUBMETIDA A ST-AN. 3,ART.12'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 61;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 62, 'CR�DITO PELO SUBSTITU�DO QUE RECEBER MERCADORIAS COM IMPOSTO RETIDO INTEGRAL E PROMOVER SA�DA COM DESTINO A SIMPLES NACIONAL', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO SUBSTITU�DO QUE RECEBER MERCADORIAS COM IMPOSTO RETIDO INTEGRAL E PROMOVER SA�DA COM DESTINO A SIMPLES NACIONAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 62;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 63, 'CR�DITO PELO SUBSTITUTO DO IMPOSTO RETIDO CONSIGNADO EM NOTA FISCAL DE DEVOLU��O DE MERCADORIAS', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO SUBSTITUTO DO IMPOSTO RETIDO CONSIGNADO EM NOTA FISCAL DE DEVOLU��O DE MERCADORIAS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 63;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 64, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO QUE EFETUOU OPERA��O DESTINADA A DETENTOR DE PR�-EMPREGO (DIFERIMENTO OPERA��O INTERNA)', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO SUBSTITU�DO QUE EFETUOU OPERA��O DESTINADA A DETENTOR DE PR�-EMPREGO (DIFERIMENTO OPERA��O INTERNA)'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 64;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 65, 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO PR�PRIO BENEFICI�RIO DO DISPOSTO NO CAP. V, SE�. XV DO ANEXO 2 NO CASO DA MERCADORIA J� TER SIDO SUBMETIDA A SUBSTITUI��O TRIBUT�RIA - AN. 3, ART. 12-A - TTD BENEF�CIO: 353', '01/04/2008', '', 0, 1, 353);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO DESTACADO E RETIDO PELO PR�PRIO BENEFICI�RIO DO DISPOSTO NO CAP. V, SE�. XV DO ANEXO 2 NO CASO DA MERCADORIA J� TER SIDO SUBMETIDA A SUBSTITUI��O TRIBUT�RIA - AN. 3, ART. 12-A - TTD BENEF�CIO: 353'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 65;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 66, 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS APURADO POR OPERA��O E RECOLHIDO A CADA SA�DA EXIGIDO EM ATO DECLARAT�RIO', '01/04/2008', '', 0, 1, 72);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO AO PAGAMENTO DO ICMS APURADO POR OPERA��O E RECOLHIDO A CADA SA�DA EXIGIDO EM ATO DECLARAT�RIO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 66;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 67, 'CR�DITO PELO FORNECEDOR INDICADO DE RESSARCIMENTO EFETUADO POR DETENTOR DO TTD DO BENEF�CIO 96', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO FORNECEDOR INDICADO DE RESSARCIMENTO EFETUADO POR DETENTOR DO TTD DO BENEF�CIO 96'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 67;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 68, 'CR�DITO PELO DESTINAT�RIO DO SALDO DO IMPOSTO RETIDO NAS OPERA��ES DESTINADAS A EMPRESAS INTERDEPENDENTES PARA APURA��O COMPARTILHADA', '01/04/2008', '', 0, 1, 480);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO DESTINAT�RIO DO SALDO DO IMPOSTO RETIDO NAS OPERA��ES DESTINADAS A EMPRESAS INTERDEPENDENTES PARA APURA��O COMPARTILHADA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 68;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 69, 'CR�DITO DO ICMS RECOLHIDO EM DAS, NA EXCLUS�O DO SIMPLES NACIONAL', '01/04/2008', '', 1, 3, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO ICMS RECOLHIDO EM DAS, NA EXCLUS�O DO SIMPLES NACIONAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 69;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '040'), 70, 'CR�DITO PROPORCIONAL � MERCADORIA DEVOLVIDA, QUANDO O CR�DITO PELA ENTRADA FOI ESTORNADO CONFORME DISPOSTO NO AN. 2, ART. 23, III', '01/04/2008', '', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PROPORCIONAL � MERCADORIA DEVOLVIDA, QUANDO O CR�DITO PELA ENTRADA FOI ESTORNADO CONFORME DISPOSTO NO AN. 2, ART. 23, III'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '040')
         and codigo          = 70;
  end;
  
  
  
  -- Insert table - Registro 60 - Table Gen�rica - DCIP 3
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 1, 'IND�STRIA VIN�COLA E PRODUTOR DE DERIVADOS DE UVA E VINHO - AN2, ART 15, I', '01/04/2008', '01/09/2012', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'IND�STRIA VIN�COLA E PRODUTOR DE DERIVADOS DE UVA E VINHO - AN2, ART 15, I'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 1;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 2, 'FAB. A��CAR, CAF�; MANTEIGA; �LEO DE SOJA E MILHO; MARGARINA; CREME VEGETAL; VINAGRE; SAL - An2, Art 15, II', '1/04/2008', '01/06/2010', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FAB. A��CAR, CAF�; MANTEIGA; �LEO DE SOJA E MILHO; MARGARINA; CREME VEGETAL; VINAGRE; SAL - An2, Art 15, II'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 2;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 3, 'SA�DA DE OBRA DE ARTE RECEBIDA COM A ISEN��O - An2, Art 15, III', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE OBRA DE ARTE RECEBIDA COM A ISEN��O - An2, Art 15, III'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 3;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 4, 'FABRICANTE DE BOLACHAS E BISCOITOS - An2, Art 15, IV', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE DE BOLACHAS E BISCOITOS - An2, Art 15, IV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 4;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 5, 'SA�DA DE FARINHA DE TRIGO An2, Art 15, V', '01/04/2008', '01/11/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE FARINHA DE TRIGO An2, Art 15, V'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 5;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 6, 'SA�DA DE ADESIVO HIDROXILADO RESULTANTE DE GARRAFA PET - An2, Art 15, VI', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE ADESIVO HIDROXILADO RESULTANTE DE GARRAFA PET - An2, Art 15, VI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 6;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 7, 'SA�DA DE PNEUS NOVOS IMPORTADOS - EXIGIDO REGIME ESPECIAL - An2, Art 15, VII', '01/04/2008', null, 0 , 1 , 70);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE PNEUS NOVOS IMPORTADOS - EXIGIDO REGIME ESPECIAL - An2, Art 15, VII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 7;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 8, 'PRODUTOS DA IND�STRIA DE AUTOMA��O, INFORM�TICA E TELECOMUNICA��ES - EXIGE COMUNICA��O - AN2, ART 15, VIII', '01/04/2008', '01/10/2017', 0 , 1 , 158);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'PRODUTOS DA IND�STRIA DE AUTOMA��O, INFORM�TICA E TELECOMUNICA��ES - EXIGE COMUNICA��O - AN2, ART 15, VIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 8;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 9, 'SA�DA DE MERCADORIAS IMPORTADAS DO EXTERIOR DO PA�S - EXIGIDO REGIME ESPECIAL - AN2, ART 15, IX', '01/04/2008', '01/10/2017' , 0 , 1 , 69);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE MERCADORIAS IMPORTADAS DO EXTERIOR DO PA�S - EXIGIDO REGIME ESPECIAL - AN2, ART 15, IX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 9;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 10, 'SA�DA TRIBUTADA DO FABRICANTE DE PRODUTOS DERIVADOS DE LEITE - An2, Art 15, X', '01/04/2008', null, 0 , 1 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA TRIBUTADA DO FABRICANTE DE PRODUTOS DERIVADOS DE LEITE - An2, Art 15, X'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 10;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 11, 'SA�DA DE CEVADA, MALTE, L�PULO E COBRE, IMPORTADOS DO EXTERIOR DO PA�S - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XI', '01/04/2008', '01/10/2017', 0 , 1 , 68);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE CEVADA, MALTE, L�PULO E COBRE, IMPORTADOS DO EXTERIOR DO PA�S - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 11;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 12, 'FABR .DE �LEO VEGETAL, MARGARINA,CREME E, GORDURA VEG., FAR. DE SOJA - EXIGIDO REG ESPECIAL - AN2, ART 15, XII', '01/04/2008', '01/12/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABR .DE �LEO VEGETAL, MARGARINA,CREME E, GORDURA VEG., FAR. DE SOJA - EXIGIDO REG ESPECIAL - AN2, ART 15, XII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 12;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 13, 'FABRICANTE NA SA�DA PARA SP DE FARINHA DE TRIGO E MISTURA PARA A PREPARA��O DE P�ES - An2, Art 15, XIII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA PARA SP DE FARINHA DE TRIGO E MISTURA PARA A PREPARA��O DE P�ES - An2, Art 15, XIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 13;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 14, 'FABRICANTE NA SA�DA DE LEITE E DERIVADOS - AN2, ART 15, XIV', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA DE LEITE E DERIVADOS - AN2, ART 15, XIV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 14;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 15, 'EXCLUSIVO DA CELESC - AN2, ART 15, XV', '01/04/2008', '01/02/2015', 0 , 1 , 609);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'EXCLUSIVO DA CELESC - AN2, ART 15, XV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 15;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 16, 'FAB. OU DISTR. AUTOMOBIL�STICO, FARMAC�UTICO E FORNEC. DE EN. EL�TRICA E SERV. DE COMUNICA��O An2, Art 15, XVI', '01/04/2008', '01/11/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FAB. OU DISTR. AUTOMOBIL�STICO, FARMAC�UTICO E FORNEC. DE EN. EL�TRICA E SERV. DE COMUNICA��O An2, Art 15, XVI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 16;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 17, 'FABRICANTE DE LEITE EM P� SUJEITAS � AL�QUOTA DE 12% - AN2, ART 15, XVII', '01/04/2008', '01/01/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE DE LEITE EM P� SUJEITAS � AL�QUOTA DE 12% - AN2, ART 15, XVII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 17;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 18, 'EMPRESAS NA EXECU��O DO PROGRAMA LUZ PARA TODOS An2, Art 15, XVIII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'EMPRESAS NA EXECU��O DO PROGRAMA LUZ PARA TODOS An2, Art 15, XVIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 18;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 19, 'FABRICANTE NAS SA�DAS CAF� TORRADO EM GR�O OU MO�DO, VINHO, A��CAR - An2, Art 15, XIX', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS CAF� TORRADO EM GR�O OU MO�DO, VINHO, A��CAR - An2, Art 15, XIX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 19;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 20, 'BENEFICIADOR NA SA�DA DE ARROZ COM BENEFICIAMENTO PR�PRIO - An2, Art 15, XX', '01/04/2008', '01/01/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'BENEFICIADOR NA SA�DA DE ARROZ COM BENEFICIAMENTO PR�PRIO - An2, Art 15, XX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 20;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 21, 'FABRICANTE NAS SA�DAS, DE ARTIGOS DE CRISTAL DE CHUMBO - An2, Art 15, XXI', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS, DE ARTIGOS DE CRISTAL DE CHUMBO - An2, Art 15, XXI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 21;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 22, 'FABRICANTE NAS OPERA��ES PR�PRIAS COM SACOS DE PAPEL - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XXII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS OPERA��ES PR�PRIAS COM SACOS DE PAPEL - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XXII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 22;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 23, 'LIQUID. DE D�BITOS DE SERV. DE TELECOMUNIC. TOMADOS PELO ESTADO - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XXII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = ''
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 23;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 24, 'FABR. NAS SA�DAS DE PROD. DERIV DE AVES DOM�STICAS - EXIGIDO REGIME ESPECIAL - PR� EMPREGO - AN2, ART 15, XXIV', '01/04/2008', null, 0 , 1 , 21 );
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABR. NAS SA�DAS DE PROD. DERIV DE AVES DOM�STICAS - EXIGIDO REGIME ESPECIAL - PR� EMPREGO - AN2, ART 15, XXIV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 24;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 25, 'ATAC. DE MEDICAMENTOS NA ENTR. DE PRODUTOS FARMAC�UTICOS - EXIGE COMUNICA��O - AN2, ART 15, XXV', '01/04/2008', null, 0 , 1 , 112 );
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ATAC. DE MEDICAMENTOS NA ENTR. DE PRODUTOS FARMAC�UTICOS - EXIGE COMUNICA��O - AN2, ART 15, XXV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 25;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 26, 'ESTABELECIMENTO ABATEDOR NA SA�DA DE PRODUTOS RESULTANTES DE GADO BOVINO - AN2, ART. 16', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO ABATEDOR NA SA�DA DE PRODUTOS RESULTANTES DE GADO BOVINO - AN2, ART. 16'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 26;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 27, 'FABR. NAS SA�DAS INTEREST. DE PROD. DO ABATE DE AVES DOM�STICAS - EXIGIDO REGIME ESPECIAL - AN2, ART. 17', '01/04/2008', null, 0 , 1 , 331 );
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABR. NAS SA�DAS INTEREST. DE PROD. DO ABATE DE AVES DOM�STICAS - EXIGIDO REGIME ESPECIAL - AN2, ART. 17'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 27;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 28, 'FABR. NAS SA�DAS INTEREST. DE PROD. DO ABATE DE SU�NOS - EXIGIDO REGIME ESPECIAL - AN2, ART. 17', '01/04/2008', null, 0 , 1 , 331);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABR. NAS SA�DAS INTEREST. DE PROD. DO ABATE DE SU�NOS - EXIGIDO REGIME ESPECIAL - AN2, ART. 17'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 28;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 29, 'ESTAB. INDUSTRIAL NA ENTRADA DE CHAPAS FINAS A FRIO, ZINCADAS E A�O INOX - An2, Art. 18', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTAB. INDUSTRIAL NA ENTRADA DE CHAPAS FINAS A FRIO, ZINCADAS E A�O INOX - An2, Art. 18'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 29;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 30, 'EMPRESAS PRODUTORAS DE DISCOS FONOGR�FICOS - An2, Art. 19', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'EMPRESAS PRODUTORAS DE DISCOS FONOGR�FICOS - An2, Art. 19'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 30;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 31, 'ESTABELECIMENTO QUE EFETUAR A PRIMEIRA OPERA��O TRIBUT�VEL COM MA�� - An2, Art. 20', '01/04/2008', '01/12/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO QUE EFETUAR A PRIMEIRA OPERA��O TRIBUT�VEL COM MA�� - An2, Art. 20'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 31;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 32, 'INDUSTRIALIZADOR NAS SA�DAS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DA MANDIOCA - An2, Art. 21, I', '01/04/2008', '01/12/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'INDUSTRIALIZADOR NAS SA�DAS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DA MANDIOCA - An2, Art. 21, I'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 32;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 33, 'SA�DA DE LEITE PASTEURIZADO OU ESTERILIZADO COM DESTINO A OUTRO ESTADO - An2, Art. 21, III', '01/04/2008', '01/11/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE LEITE PASTEURIZADO OU ESTERILIZADO COM DESTINO A OUTRO ESTADO - An2, Art. 21, III'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 33;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 34, 'BARES, RESTAURANTES E ESTABELECIMENTOS SIMILARES- An2, Art. 21, IV', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'BARES, RESTAURANTES E ESTABELECIMENTOS SIMILARES- An2, Art. 21, IV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 34;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 35, 'DISTRIBUIDORAS DE FILMES, NAS SA�DAS DE FILMES GRAVADOS - An2, Art. 21, V', '01/04/2008', '01/12/2015', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'DISTRIBUIDORAS DE FILMES, NAS SA�DAS DE FILMES GRAVADOS - An2, Art. 21, V'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 35;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 36, 'SA�DAS DE PEIXES, CRUST�CEOS OU MOLUSCOS - EXIGIDO REGIME ESPECIAL- An2, Art. 21, VI', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DAS DE PEIXES, CRUST�CEOS OU MOLUSCOS - EXIGIDO REGIME ESPECIAL- An2, Art. 21, VI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 36;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 37, 'INDUSTRIAL, NAS SA�DAS PARA SP DE MASSAS ALIMENT�CIAS, BISCOITOS E BOLACHAS - An2, Art. 21, VII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'INDUSTRIAL, NAS SA�DAS PARA SP DE MASSAS ALIMENT�CIAS, BISCOITOS E BOLACHAS - An2, Art. 21, VII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 37;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 38, 'SA�DAS DE FEIJ�O - An2, Art. 21, VIII', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DAS DE FEIJ�O - An2, Art. 21, VIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 38;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 39, 'FABRICANTE NAS SA�DAS LOU�A E OUTROS PRODUTOS, DE PORCELANA E COPOS DE CRISTAL DE CHUMBO - An2, Art. 22', '01/04/2008', '01/12/2009', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS LOU�A E OUTROS PRODUTOS, DE PORCELANA E COPOS DE CRISTAL DE CHUMBO - An2, Art. 22'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 39;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 40, 'PRESTADORES DE SERVI�O DE TRANSPORTE - An2, Art. 25', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'PRESTADORES DE SERVI�O DE TRANSPORTE - An2, Art. 25'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 40;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 41, 'PRESTA��O INTERNA DE SERVI�O DE TRANSPORTE A�REO - An2, Art. 52', '01/04/2008', '01/09/2010', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'PRESTA��O INTERNA DE SERVI�O DE TRANSPORTE A�REO - An2, Art. 52'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 41;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 42, 'INCREMENTO NO VALOR DA FOLHA DE PESSOAL - An2, Art. 92', '01/04/2008', '01/11/2012', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'INCREMENTO NO VALOR DA FOLHA DE PESSOAL - An2, Art. 92'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 42;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 43, 'AQUISI��O DE EQUIPAMENTO EMISSOR DE CUPOM FISCAL - ECF - An2, Art. 120', '01/04/2008', '01/09/2010', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'AQUISI��O DE EQUIPAMENTO EMISSOR DE CUPOM FISCAL - ECF - An2, Art. 120'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 43;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 44, 'AQUISI��O DO CONJUNTO DE SOFTWARE E HARDWARE DESTINADO � IMPLANTA��O DE TEF - An2, Art. 120-A', '01/04/2008', '01/09/2010', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'AQUISI��O DO CONJUNTO DE SOFTWARE E HARDWARE DESTINADO � IMPLANTA��O DE TEF - An2, Art. 120-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 44;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 45, 'IND�STRIA PRODUTORA DE BENS E SERVI�OS DE INFORM�TICA - EXIGIDO REGIME ESPECIAL - An2, Art. 142', '01/04/2008', null, 0 , 1 , 65 );
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'IND�STRIA PRODUTORA DE BENS E SERVI�OS DE INFORM�TICA - EXIGIDO REGIME ESPECIAL - An2, Art. 142'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 45;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 46, 'SA�DA DO IMPORTADOR DE BENS E SERVI�OS DE INFORM�TICA - EXIGIDO REGIME ESPECIAL - An2, Art. 148-A', '01/04/2008', '01/01/2012', 0 , 1 , 181);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DO IMPORTADOR DE BENS E SERVI�OS DE INFORM�TICA - EXIGIDO REGIME ESPECIAL - An2, Art. 148-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 46;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 47, 'IND�STRIA F�RMACO-QU�MICA - EXIGIDO REGIME ESPECIAL - An2, Art. 149', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'IND�STRIA F�RMACO-QU�MICA - EXIGIDO REGIME ESPECIAL - An2, Art. 149'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 47;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 48, 'PRESTADORES DE SERVI�O DE TRANSPORTE DE CARGAS (PR�-CARGAS) - An6, Art. 266', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'PRESTADORES DE SERVI�O DE TRANSPORTE DE CARGAS (PR�-CARGAS) - An6, Art. 266'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 48;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 49, 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE C�MARAS FRIGOR�FICAS PARA CAMINH�ES - An6, Art. 269', '01/04/2008', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE C�MARAS FRIGOR�FICAS PARA CAMINH�ES - An6, Art. 269'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 49;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 50, 'EMPRESA QUE PRODUZIR PRODUTO SEM SIMILAR CATARINENSE - EXIGIDO REGIME ESPECIAL- PR�-EMPREGO Art. 15-A', '01/04/2008', null, 0 , 1 , 229);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'EMPRESA QUE PRODUZIR PRODUTO SEM SIMILAR CATARINENSE - EXIGIDO REGIME ESPECIAL- PR�-EMPREGO Art. 15-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 50;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 51, 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO - AN2, ART. 21, IX', '01/11/2008', '01/05/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO - AN2, ART. 21, IX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 51;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 52, 'CELESC - PROGRAMA DE POL�TICA ENERG�TICA DO ESTADO - AN2, ART. 15, XXVII', '01/01/2009', null, 1 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CELESC - PROGRAMA DE POL�TICA ENERG�TICA DO ESTADO - AN2, ART. 15, XXVII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 52;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 53, 'SA�DA DE VINHO, EXCETO COMPOSTO, PROMOVIDA POR ESTABELECIMENTO INDUSTRIAL - EXIGE COMUNICA��O - AN2, ART. 21, X', '01/07/2009', null, 0 , 1 , 105);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE VINHO, EXCETO COMPOSTO, PROMOVIDA POR ESTABELECIMENTO INDUSTRIAL - EXIGE COMUNICA��O - AN2, ART. 21, X'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 53;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 54, 'SA�DAS DE QUEROSENE DE AVIA��O COM DESTINO A EMPRESA A�REA DETENTORA DE REGIME ESPECIAL - AN2, ART. 21, XI', '01/07/2009', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DAS DE QUEROSENE DE AVIA��O COM DESTINO A EMPRESA A�REA DETENTORA DE REGIME ESPECIAL - AN2, ART. 21, XI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 54;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 55, 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE EMBARCA��ES N�UTICAS - EXIGIDO REGIME ESPECIAL - PR�-N�UTICA - AN2, ART. 176', '01/07/2009', null, 0 , 1 , 106);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE EMBARCA��ES N�UTICAS - EXIGIDO REGIME ESPECIAL - PR�-N�UTICA - AN2, ART. 176'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 55;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 56, 'ESTABELECIMENTO ABATEDOR NAS ENTRADAS DE SU�NOS E AVES PRODUZIDOS NO ESTADO - AN2, ART. 17, III', '01/01/2009', null, 0 , 1 , 331);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO ABATEDOR NAS ENTRADAS DE SU�NOS E AVES PRODUZIDOS NO ESTADO - AN2, ART. 17, III'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 56;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 57, 'FABRICANTE NAS SA�DAS INTERESTADUAIS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DE LEITE - EXIGIDO REGIME ESPECIAL - AN2, ART. 15, XXVIII', '01/11/2009', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS INTERESTADUAIS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DE LEITE - EXIGIDO REGIME ESPECIAL - AN2, ART. 15, XXVIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 57;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 58, 'FABRICANTE NAS SA�DAS INTERNAS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DE LEITE - EXIGIDO REGIME ESPECIAL - AN2, ART. 15, XXIX', '01/11/2009', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS INTERNAS DE PRODUTOS RESULTANTES DA INDUSTRIALIZA��O DE LEITE - EXIGIDO REGIME ESPECIAL - AN2, ART. 15, XXIX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 58;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 59, 'ESTABELECIMENTO INDUSTRIAL NA SA�DA DE PRODUTO EM QUE O MATERIAL RECICLADO CORRESPONDE A 75% DO CUSTO - EXIGE COMUNICA��O - AN2, ART. 21, XII', '01/11/2009', null, 0 , 1 , 328);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NA SA�DA DE PRODUTO EM QUE O MATERIAL RECICLADO CORRESPONDE A 75% DO CUSTO - EXIGE COMUNICA��O - AN2, ART. 21, XII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 59;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 60, 'OPERA��ES INTERESTADUAIS DE VENDA DIRETA A CONSUMIDOR REALIZADAS POR MEIO DA INTERNET - EXIGE COMUNICA��O - AN2, ART. 15, XXX', '01/11/2009', '01/12/2015', 0 , 1 , 335);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'OPERA��ES INTERESTADUAIS DE VENDA DIRETA A CONSUMIDOR REALIZADAS POR MEIO DA INTERNET - EXIGE COMUNICA��O - AN2, ART. 15, XXX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 60;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 61, 'FABRICANTE NA SA�DA DE PRODUTOS CLASSIFICADOS NA POSI��O 8517.18.91 DA NCM - EXIGE COMUNICA��O - AN2, ART. 15, XXXI', '01/02/2010', null, 0 , 1 , 336);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA DE PRODUTOS CLASSIFICADOS NA POSI��O 8517.18.91 DA NCM - EXIGE COMUNICA��O - AN2, ART. 15, XXXI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 61;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 62, 'SA�DA INTERNA DE VINHO, EXCETO OS DO SUBTIPO 53, PROMOVIDA POR ESTABELECIMENTO INDUSTRIAL - AN2, ART. 21, XIII', '01/11/2009', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA INTERNA DE VINHO, EXCETO OS DO SUBTIPO 53, PROMOVIDA POR ESTABELECIMENTO INDUSTRIAL - AN2, ART. 21, XIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 62;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 63, 'ESTABELECIMENTO INDUSTRIAL NA SA�DA DE PRODUTOS EM QUE O VIME CORRESPONDA A 75% DO CUSTO - EXIGE COMUNICA��O - AN2, ART. 21, XIV', '01/04/2010', null, 0 , 1 , 350);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NA SA�DA DE PRODUTOS EM QUE O VIME CORRESPONDA A 75% DO CUSTO - EXIGE COMUNICA��O - AN2, ART. 21, XIV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 63;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 64, 'SA�DA DE CERVEJA E CHOPE ARTESANAIS PRODUZIDOS PELA PR�PRIA MICROCERVEJARIA - EXIGE COMUNICA��O - AN2, ART. 15, XXXII', '01/05/2010', null, 0 , 1 , 339);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE CERVEJA E CHOPE ARTESANAIS PRODUZIDOS PELA PR�PRIA MICROCERVEJARIA - EXIGE COMUNICA��O - AN2, ART. 15, XXXII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 64;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 65, 'FABRICANTE NA SA�DA EM OPERA��O PR�PRIA COM CIGARROS, CIGARRILHAS, ETC - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXV', '01/09/2010', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA EM OPERA��O PR�PRIA COM CIGARROS, CIGARRILHAS, ETC - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 65;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 66, 'SA�DA DO IMPORTADOR DE MEDICAMENTOS, SUAS MAT-PRIMAS E EQUIP M�DICO-HOSP - EXIGE REGIME ESPECIAL - AN2, ART. 196', '01/09/2010', null, 0 , 1 , 375);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DO IMPORTADOR DE MEDICAMENTOS, SUAS MAT-PRIMAS E EQUIP M�DICO-HOSP - EXIGE REGIME ESPECIAL - AN2, ART. 196'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 66;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 67, 'SA�DA PROMOVIDA PELO INDUSTRIAL DE �LEO VEGETAL BRUTO DEGOMADO, �LEO VEGETAL REFINADO, MARGARINA, CREME E GORDURA VEGETAL - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXVII', '01/11/2010', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA PROMOVIDA PELO INDUSTRIAL DE �LEO VEGETAL BRUTO DEGOMADO, �LEO VEGETAL REFINADO, MARGARINA, CREME E GORDURA VEGETAL - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXVII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 67;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 68, 'SA�DA PROMOVIDA PELO INDUSTRIAL DE MAIONESE (NCM 21.03.90.11) - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXVIII', '01/11/2010', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA PROMOVIDA PELO INDUSTRIAL DE MAIONESE (NCM 21.03.90.11) - EXIGE REGIME ESPECIAL - AN2, ART. 15, XXXVIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 68;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 69, 'FABRICANTE DE LEITE EM P� SUJEITAS � AL�QUOTA DE 12% - EXIGIDO COMUNICA��O - AN2, ART 15, XVII', '01/04/2008', null, 0 , 1 , 154);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE DE LEITE EM P� SUJEITAS � AL�QUOTA DE 12% - EXIGIDO COMUNICA��O - AN2, ART 15, XVII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 69;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 70, 'BENEFICIADOR NA SA�DA DE ARROZ COM BENEFICIAMENTO PR�PRIO - EXIGIDO COMUNICA��O - An2, Art 15, XX', '01/04/2008', null, 0 , 1 , 136);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'BENEFICIADOR NA SA�DA DE ARROZ COM BENEFICIAMENTO PR�PRIO - EXIGIDO COMUNICA��O - An2, Art 15, XX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 70;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 71, 'INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO, ALTERNATIVO AO SUBTIPO 51 - AN2, ART. 15, XXXIX', '01/02/2011', '01/04/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO, ALTERNATIVO AO SUBTIPO 51 - AN2, ART. 15, XXXIX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 71;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 72, 'FABRICANTE NA SA�DA INTERESTADUAL DE SUPLEMENTOS ALIMENTARES (NCM 2106.90.90) - EXIGE COMUNICA��O - AN2, ART. 15, XL', '01/02/2011', null, 0 , 1 , 369);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA INTERESTADUAL DE SUPLEMENTOS ALIMENTARES (NCM 2106.90.90) - EXIGE COMUNICA��O - AN2, ART. 15, XL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 72;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 73, 'ESTABELECIMENTO COM PREPONDER�NCIA DE DISTRIB DE PROD FARMAC�UTICOS NA SA�DA INTERESTAD DE MEDICAMENTOS - AN2, ART.15, XLI', '01/02/2011', '01/09/2017' , 0 , 1 , 370);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO COM PREPONDER�NCIA DE DISTRIB DE PROD FARMAC�UTICOS NA SA�DA INTERESTAD DE MEDICAMENTOS - AN2, ART.15, XLI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 73;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 74, 'INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO, ALTERNATIVO AO SUBTIPO 51 - EXIGE COMUNICA��O - AN2, ART. 15, XXXIX', '01/05/2011', null, 0 , 1 , 372);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO, ALTERNATIVO AO SUBTIPO 51 - EXIGE COMUNICA��O - AN2, ART. 15, XXXIX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 74;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 75, 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO - EXIGE COMUNICA��O - AN2, ART. 21, IX', '01/06/2011', '01/02/2013', 0 , 1 , 47);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTABELECIMENTO INDUSTRIAL NAS SA�DAS DE ART. T�XTEIS, DE VESTU�RIO E DE ART. DE COURO - EXIGE COMUNICA��O - AN2, ART. 21, IX'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 75;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 76, 'CR�DITO PRESUMIDO CONCEDIDO COM BASE NO ART. 43 DA LEI 10.297/1996 - EXIGE TTD BENEF�CIO 373', '01/07/2011', null, 0 , 1 , 373);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO CONCEDIDO COM BASE NO ART. 43 DA LEI 10.297/1996 - EXIGE TTD BENEF�CIO 373'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 76;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 77, 'SA�DA DE CEVADA, MALTE, L�PULO E COBRE, IMPORTADOS DO EXTERIOR DO PA�S, COM ACR�SCIMO NO PERCENTUAL DE CR�DITO - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XI E � 5�, II', '01/01/2012', null, 0 , 1 , 43);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE CEVADA, MALTE, L�PULO E COBRE, IMPORTADOS DO EXTERIOR DO PA�S, COM ACR�SCIMO NO PERCENTUAL DE CR�DITO - EXIGIDO REGIME ESPECIAL - AN2, ART 15, XI E � 5�, II'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 77;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 78, 'SA�DA DE PRODUTOS ACABADOS DE INFORM�TICA, IMPORTADOS DO EXTERIOR - EXIGIDO REGIME ESPECIAL - AN2, ART. 146', '01/01/2012', null, 0 , 1 , 71);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA DE PRODUTOS ACABADOS DE INFORM�TICA, IMPORTADOS DO EXTERIOR - EXIGIDO REGIME ESPECIAL - AN2, ART. 146'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 78;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 79, 'IND�STRIA PRODUTORA DE BENS E SERVI�OS DE INFORM�TICA QUE N�O ATENDAM � LEI FEDERAL N� 8248/91- EXIGIDO REGIME ESPECIAL - AN2, ART. 145', '01/01/2012', null, 0 , 1 , 194);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'IND�STRIA PRODUTORA DE BENS E SERVI�OS DE INFORM�TICA QUE N�O ATENDAM � LEI FEDERAL N� 8248/91- EXIGIDO REGIME ESPECIAL - AN2, ART. 145'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 79;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 80, 'FABRICANTE NA SA�DA INTERESTADUAL DE ERVA-MATE BENEFICIADA EM EMBALAGEM DE 1KG - AN2, ART. 15, XLII', '01/06/2017' , '01/03/2018', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NA SA�DA INTERESTADUAL DE ERVA-MATE BENEFICIADA EM EMBALAGEM DE 1KG - AN2, ART. 15, XLII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 80;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 81, 'SA�DAS INTERESTADUAIS DE MADEIRA EM BRUTO NCM 4403, OU BENEFICIADA NCM 4407 OU 4409, ORIUNDAS DE REFLORESTAMENTO - AN2, ART. 15, XLIII', '01/04/2017' , '01/03/2018', 0, 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DAS INTERESTADUAIS DE MADEIRA EM BRUTO NCM 4403, OU BENEFICIADA NCM 4407 OU 4409, ORIUNDAS DE REFLORESTAMENTO - AN2, ART. 15, XLIII'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 81;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 82, 'CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/1996, SUBSTITUI CR�DITOS EFETIVOS NAS SA�DAS DE MERCADORIAS PRODU��O PR�PRIA - EXIGE TTD BENEF�CIO 384', '01/03/2012', null, 0, 1 , 384);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/1996, SUBSTITUI CR�DITOS EFETIVOS NAS SA�DAS DE MERCADORIAS PRODU��O PR�PRIA - EXIGE TTD BENEF�CIO 384'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 82;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 83, 'CR�DITO PRESUMIDO NA PRESTA��O DE SERVI�OS DE TELECOMUNICA��ES PROMOVIDA POR PRESTADORES LISTADOS NO ATO COTEPE 10/08, CUJO DOC. FISCAL SEJA EMITIDO EM VIA �NICA - AN2, ART. 25-A', '01/09/2012', null, 0 , 1 , 401);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA PRESTA��O DE SERVI�OS DE TELECOMUNICA��ES PROMOVIDA POR PRESTADORES LISTADOS NO ATO COTEPE 10/08, CUJO DOC. FISCAL SEJA EMITIDO EM VIA �NICA - AN2, ART. 25-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 83;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 86, 'CELESC - CONV�NIO PARA EXECU��O DE OBRAS', '01/03/2011', null, 1 , 1 , 614);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CELESC - CONV�NIO PARA EXECU��O DE OBRAS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 86;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 87, 'CR�DITO PRESUMIDO EM VALOR EQUIVALENTE AO DA OBRA DE INFRAESTRUTURA P�BLICA - EXIGE REGIME ESPECIAL - AN2, ART. 23-A', '01/03/2011', null, 0 , 1 , 403);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO EM VALOR EQUIVALENTE AO DA OBRA DE INFRAESTRUTURA P�BLICA - EXIGE REGIME ESPECIAL - AN2, ART. 23-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 87;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 88, 'FABRICANTE NAS SA�DAS DE BIODIESEL - AN2, ART. 15, XXXVI', '01/06/2011', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FABRICANTE NAS SA�DAS DE BIODIESEL - AN2, ART. 15, XXXVI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 88;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 89, 'CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/1996, PROPORCIONAL � SA�DA DE MERCADORIA - EXIGE TTD BENEF�CIO 422', '01/06/2013', null, 0 , 1 , 422);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/1996, PROPORCIONAL � SA�DA DE MERCADORIA - EXIGE TTD BENEF�CIO 422'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 89;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 91, 'CR�DITO PRESUMIDO NA VENDA DIRETA AO CONSUMIDOR FINAL EM OUTRA UF, REALIZADAS PELA INTERNET - EXIGE TTD DO BENEF�CIO 427', '01/11/2013', null, 0 , 1 , 427);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA VENDA DIRETA AO CONSUMIDOR FINAL EM OUTRA UF, REALIZADAS PELA INTERNET - EXIGE TTD DO BENEF�CIO 427'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 91;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 92, 'CR�DITO PRESUMIDO DE AT� 500.000,00, NOS TERMOS DO CONV. ICMS 15/2010 - EXIGE TTD BENEF�CIO 407', '01/12/2013', null, 0 , 1 , 407);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO DE AT� 500.000,00, NOS TERMOS DO CONV. ICMS 15/2010 - EXIGE TTD BENEF�CIO 407'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 92;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 93, 'CR�DITO PRESUMIDO LIMITADO AO VALOR TOTAL DA OBRA DE INFRAESTRUTURA P�BLICA - EXIGE TTD BENEF�CIO 451', '01/07/2013', null, 0 , 1 , 451);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO LIMITADO AO VALOR TOTAL DA OBRA DE INFRAESTRUTURA P�BLICA - EXIGE TTD BENEF�CIO 451'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 93;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 94, 'CREDITO PRESUMIDO NA SA�DA DE PRODUTO EM QUE O MATERIAL RECICLADO CORRESPONDA A 40% DO CUSTO - EXIGE TTD BENEF�CIO 452', '01/06/2014', null, 0 , 1 , 452);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CREDITO PRESUMIDO NA SA�DA DE PRODUTO EM QUE O MATERIAL RECICLADO CORRESPONDA A 40% DO CUSTO - EXIGE TTD BENEF�CIO 452'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 94;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 95, 'CR�DITO PRESUMIDO COM MERCADORIAS DESTINADAS A REVENDEDOR PARA VENDA PORTA A PORTA - EXIGE TTD BENEF�CIO 450', '01/04/2014', null, 0 , 1 , 450);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO COM MERCADORIAS DESTINADAS A REVENDEDOR PARA VENDA PORTA A PORTA - EXIGE TTD BENEF�CIO 450'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 95;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 96, 'CR�DITO PRESUMIDO CONFORME TTD DE CONDI��ES EXCEPCIONAIS', '01/10/2014', null, 0 , 1 , 454);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO CONFORME TTD DE CONDI��ES EXCEPCIONAIS'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 96;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 97, 'EXCLUSIVO DA CELESC - LUZ PARA TODOS - AN2, ART 15, XV', '01/03/2015', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'EXCLUSIVO DA CELESC - LUZ PARA TODOS - AN2, ART 15, XV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 97;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 98, 'CR�DITO PRESUMIDO NA SA�DA INTERNA DE CARNE BOVINA - EXIGE TTD BENEF�CIO 460', '01/03/2015', null, 0 , 1 , 460);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA SA�DA INTERNA DE CARNE BOVINA - EXIGE TTD BENEF�CIO 460'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 98;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 99, 'CR�DITO PRESUMIDO NA EXCLUS�O DO REGIME DE APURA��O DO SIMPLES NACIONAL - AN4, ART. 14-B', '01/03/2015', null, 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA EXCLUS�O DO REGIME DE APURA��O DO SIMPLES NACIONAL - AN4, ART. 14-B'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 99;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 100, 'FORNECEDOR ENERGIA EL�TRICA E PRESTADOR DE SERVI�OS COMUNICA��O - RICMS-SC, AN 2, ART. 15, XLIV- EXIGE TTD BENEFICIO 429', '01/04/2014', null, 0 , 1 , 429);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'FORNECEDOR ENERGIA EL�TRICA E PRESTADOR DE SERVI�OS COMUNICA��O - RICMS-SC, AN 2, ART. 15, XLIV- EXIGE TTD BENEFICIO 429'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 100;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 101, 'CR�DITO PRESUMIDO NA SA�DA INTERESTADUAL DE MERCADORIA ALCAN�ADA PELO TTD DO BENEF�CIO 466', '01/08/2015', null, 0 , 1 , 466);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA SA�DA INTERESTADUAL DE MERCADORIA ALCAN�ADA PELO TTD DO BENEF�CIO 466'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 101;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 102, 'CR�DITO PRESUMIDO NAS SA�DAS INTERNA E INTERESTADUAL PROMOVIDAS POR CENTRO DE DISTRIBUI��O ALCAN�ADAS PELO TTD DO BENEF�CIO 471', '01/10/2015', null, 0 , 1 , 471);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NAS SA�DAS INTERNA E INTERESTADUAL PROMOVIDAS POR CENTRO DE DISTRIBUI��O ALCAN�ADAS PELO TTD DO BENEF�CIO 471'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 102;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 103, 'OPERA��O INTERESTADUAL DE VENDA DIRETA A CONSUMIDOR REALIZADA POR INTERNET OU TELEMARKETING - EXIGE COMUNICA��O - AN2. ART. 21, XV', '01/01/2016', null, 0 , 1 , 478);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'OPERA��O INTERESTADUAL DE VENDA DIRETA A CONSUMIDOR REALIZADA POR INTERNET OU TELEMARKETING - EXIGE COMUNICA��O - AN2. ART. 21, XV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 103;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 104, 'OPERA��O INTERESTADUAL DE VENDA DIRETA A CONSUMIDOR REALIZADA POR DISTRIBUIDORAS NAS SA�DAS DE FILMES GRAVADOS - EXIGE COMUNICA��O - AN2. ART. 21, XVI', '01/01/2016', null, 0 , 1 , 479);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'OPERA��O INTERESTADUAL DE VENDA DIRETA A CONSUMIDOR REALIZADA POR DISTRIBUIDORAS NAS SA�DAS DE FILMES GRAVADOS - EXIGE COMUNICA��O - AN2. ART. 21, XVI'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 104;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '060'), 105, 'CR�DITO PRESUMIDO NA SA�DA INTERESTADUAL DE MERCADORIAS ALCAN�ADAS PELO TTD DO BENEF�CIO 393', '01/06/2017' , null, 0 , 1 , 393);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO NA SA�DA INTERESTADUAL DE MERCADORIAS ALCAN�ADAS PELO TTD DO BENEF�CIO 393'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '060')
         and codigo          = 105;
  end;
  
  
  
  -- Insert table - Registro 80 - Table Gen�rica - DCIP 4
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 1, 'ESTORNO DE D�BITO POR DECIS�O JUDICIAL', '01/09/2008', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO POR DECIS�O JUDICIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 1;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 2, 'ESTORNO DE D�BITO AUTORIZADO EM PROCESSO ADMINISTRATIVO REGULAR DA SEF', '01/09/2008', null, 1, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO AUTORIZADO EM PROCESSO ADMINISTRATIVO REGULAR DA SEF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 2;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 3, 'CR�DITO AUTORIZADO EM DECIS�O DO CONSELHO ESTADUAL DE CONTRIBUINTES', '01/09/2008', null, 1, 8, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO AUTORIZADO EM DECIS�O DO CONSELHO ESTADUAL DE CONTRIBUINTES'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 3;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 4, 'SA�DA OU IN�CIO DA PRESTA��O EM M�S POSTERIOR AO DA EMISS�O DO DOCUMENTO FISCAL EM OPERA��O OU PRESTA��O', '01/09/2008', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SA�DA OU IN�CIO DA PRESTA��O EM M�S POSTERIOR AO DA EMISS�O DO DOCUMENTO FISCAL EM OPERA��O OU PRESTA��O'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 4;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 5, 'ESTORNO DE D�BITO DECORRENTE DE CANCELAMENTO DE ITEM OU CUPOM FISCAL POSTERIOR A GERA��O DE OUTROS CUPONS OU DOCUMENTOS NO ECF', '01/09/2008', null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO DECORRENTE DE CANCELAMENTO DE ITEM OU CUPOM FISCAL POSTERIOR A GERA��O DE OUTROS CUPONS OU DOCUMENTOS NO ECF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 5;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 6, 'ESTORNO DE D�BITO NA SA�DA DO IMPORTADOR DE BENS E SERVI�OS DE INFORM�TICA COM REGIME ESPECIAL - AN2, ART. 148-A, � 14', '01/11/2008', '01/11/2011', 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO NA SA�DA DO IMPORTADOR DE BENS E SERVI�OS DE INFORM�TICA COM REGIME ESPECIAL - AN2, ART. 148-A, � 14'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 6;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 7, 'ESTORNO DE D�BITO�DE IMPOSTO�RECOLHIDO DECORRENTE DA EMISS�O DE DOCUMENTOS FISCAIS PARA REGULARIZA��O DE PRE�O OU QUANTIDADE', '01/09/2008', null , 1 , 3 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO�DE IMPOSTO�RECOLHIDO DECORRENTE DA EMISS�O DE DOCUMENTOS FISCAIS PARA REGULARIZA��O DE PRE�O OU QUANTIDADE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 7;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 8, 'ESTORNO DE D�BITO�CORRESPONDENTE AO DESCONTO CONCEDIDO NAS SA�DAS DE MERCADORIAS EM OPERA��O FORA DO ESTABELECIMENTO', '01/09/2008', null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO�CORRESPONDENTE AO DESCONTO CONCEDIDO NAS SA�DAS DE MERCADORIAS EM OPERA��O FORA DO ESTABELECIMENTO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 8;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 9, 'ESTORNO DE D�BITO�CORRESPONDENTE �S SA�DAS DE AEH', '01/11/2009' , null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO�CORRESPONDENTE �S SA�DAS DE AEH'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 9;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 10, 'ESTORNO DE D�BITO DECORRENTE DA EMISS�O POR CONCESSION�RIA DE NOTA FISCAL NO M�S SEGUINTE AO DA EFETIVA PERDA DE G�S NATURAL', '01/01/2010', null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO DECORRENTE DA EMISS�O POR CONCESSION�RIA DE NOTA FISCAL NO M�S SEGUINTE AO DA EFETIVA PERDA DE G�S NATURAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 10;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 11, 'ESTORNO DE D�B DE ICMS DESTACADO E LAN�ADO INDEVIDAMENTE QDO A OPER � N�O TRIB OU APLICA��O DE AL�QUOTA SUPERIOR AO DEVIDO', '01/04/2008', null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�B DE ICMS DESTACADO E LAN�ADO INDEVIDAMENTE QDO A OPER � N�O TRIB OU APLICA��O DE AL�QUOTA SUPERIOR AO DEVIDO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 11;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 13, 'ESTORNO DE D�BITO EM DECORR�NCIA DAS CONDI��ES PREVISTAS NO TTD DO BENEF�CIO 471', '01/10/2015' , null , 0 , 1 , '471 E 384');
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO EM DECORR�NCIA DAS CONDI��ES PREVISTAS NO TTD DO BENEF�CIO 471'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 13;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 14, 'ESTORNO DE D�BITO DECORRENTE DE ERRO NA MEDI��O E OU CANCELAMENTO DE NOTA FISCAL FATURA DE ENERGIA EL�TRICA', '01/09/2008', null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO DECORRENTE DE ERRO NA MEDI��O E OU CANCELAMENTO DE NOTA FISCAL FATURA DE ENERGIA EL�TRICA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 14;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '080'), 15, 'ESTORNO DE D�BITO CORRESPONDENTE AO VALOR DO ICMS APURADO EM SEPARADO E DECLARADO EXTEMPORANEAMENTE NO ITEM 050 DO QUADRO 14', '01/07/2017' , null , 0 , 0 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DE D�BITO CORRESPONDENTE AO VALOR DO ICMS APURADO EM SEPARADO E DECLARADO EXTEMPORANEAMENTE NO ITEM 050 DO QUADRO 14'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '080')
         and codigo          = 15;
  end;
  
  
  -- Insert table - Registro 100 - Table Gen�rica - DCIP 5
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 1, 'CONTRIBUI��O AO FUNDOSOCIAL', '01/09/2008', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CONTRIBUI��O AO FUNDOSOCIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 1;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 2, '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL', '01/09/2008', '01/05/2010', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 2;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 3, 'APLICA��ES AO FUNCULTURAL', '01/09/2008', '01/12/2008', 1, 4, 131);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES AO FUNCULTURAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 3;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 4, 'APLICA��ES AO FUNTURISMO', '01/09/2008', '01/12/2008', 1 , 4 , 132);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES AO FUNTURISMO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 4;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 5, 'APLICA��ES AO FUNDESPORTE', '01/09/2008', '01/12/2008', 1, 4, 133);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES AO FUNDESPORTE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 5;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 6, 'APLICA��ES NO SEITEC', '01/01/2009', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES NO SEITEC'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 6;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 7, 'APLICA��ES NO SEITEC - APROPRIA��O DO EXCEDENTE RECOLHIDO', '01/01/2010', null, 0, 9, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES NO SEITEC - APROPRIA��O DO EXCEDENTE RECOLHIDO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 7;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 8, 'CONTRIBUI��O AO FUNDOSOCIAL PELO ESTABELECIMENTO CONSOLIDADOR - EXIGE TTD - ART. 56-A', '01/10/2013', null, 0, 1, 428);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CONTRIBUI��O AO FUNDOSOCIAL PELO ESTABELECIMENTO CONSOLIDADOR - EXIGE TTD - ART. 56-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 8;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 9, 'APLICA��ES NO SEITEC PELO ESTABELECIMENTO CONSOLIDADOR - EXIGE TTD - ART. 56-A (2)', '01/10/2013', null, 0, 1, 428);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES NO SEITEC PELO ESTABELECIMENTO CONSOLIDADOR - EXIGE TTD - ART. 56-A (2)'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 9;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 10, '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL - LEI 16.940/16', '01/05/2016', '01/12/2017', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL - LEI 16.940/16'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 10;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '100'), 11, 'SOMAT�RIO DOS 10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL N�O LAN�ADOS DESDE MAIO/2016 CONFORME LEI 16.940/16', '01/10/2016', '01/12/2017', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SOMAT�RIO DOS 10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL N�O LAN�ADOS DESDE MAIO/2016 CONFORME LEI 16.940/16'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '100')
         and codigo          = 11;
  end;
  
  
  -- Insert table - Registro 140 - Table Gen�rica - DCIP 6
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 1, 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO PROC ADMINISTR - SUBSTITU�DO EFETUAR NOVA RETEN��O PARA OUTRA UF - AN.3, ART 24', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO PROC ADMINISTR - SUBSTITU�DO EFETUAR NOVA RETEN��O PARA OUTRA UF - AN.3, ART 24'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 1;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 2, 'RESSARCIMENTO PELO SUBSTITU�DO TRIBUT�RIO QUE PROMOVER NOVA RETEN��O PARA OUTRA UF NAS SA�DAS J� SUBMETIDAS AO REGIME', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITU�DO TRIBUT�RIO QUE PROMOVER NOVA RETEN��O PARA OUTRA UF NAS SA�DAS J� SUBMETIDAS AO REGIME'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 2;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 3, 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO ANEXO 3 CASO PROMOVA NOVA RETEN��O PARA OUTRA UF', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO ANEXO 3 CASO PROMOVA NOVA RETEN��O PARA OUTRA UF'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 3;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 4, 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO EM PROCESSO. ADMINISTRATIVO, NO  DESFAZIMENTO DO NEG�CIO - AN.3, ART 24, � 5�, I', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO EM PROCESSO. ADMINISTRATIVO, NO  DESFAZIMENTO DO NEG�CIO - AN.3, ART 24, � 5�, I'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 4;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 5, 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO ANEXO 3 NA DEVOLU��O OU DESFAZIMENTO DO NEG�CIO', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO ANEXO 3 NA DEVOLU��O OU DESFAZIMENTO DO NEG�CIO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 5;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 6, 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO EM PROC. ADM. - NOVA SA�DA PARA UF ONDE MERCADORIA N�O EST� SUJEITA A ST - AN. 3, ART.24, �5�, II', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITUTO AUTORIZADO EM PROC. ADM. - NOVA SA�DA PARA UF ONDE MERCADORIA N�O EST� SUJEITA A ST - AN. 3, ART.24, �5�, II'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 6;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 7, 'RESSARCIMENTO PELO SUBSTITU�DO QUE EFETUAR NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O ESTEJA SUJEITA A ST', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITU�DO QUE EFETUAR NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O ESTEJA SUJEITA A ST'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 7;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 8, 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 E EFETUOU NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O SUJEITA A ST', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO CONTRIBUINTE QUE RECOLHEU CONFORME ART. 18 E 20 DO AN. 3 E EFETUOU NOVA OPERA��O COM DESTINO UF ONDE MERCADORIA N�O SUJEITA A ST'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 8;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 9, 'RESSARCIMENTO PR�PRIO BENEFICI�RIO DISPOSTO ANEXO 2, CAP. V, SE�. XV, QUANDO MERCADORIA J�  SUBMETIDA A ST-AN. 3,ART.12', '01/08/2013', null, 0, 1 , 353);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PR�PRIO BENEFICI�RIO DISPOSTO ANEXO 2, CAP. V, SE�. XV, QUANDO MERCADORIA J�  SUBMETIDA A ST-AN. 3,ART.12'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 9;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 10, 'RESSARCIMENTO PELO SUBSTITU�DO QUE RECEBER MERCADORIAS COM IMPOSTO RETIDO INTEGRAL E PROMOVER SA�DA COM DESTINO A SIMPLES NACIONAL', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO SUBSTITU�DO QUE RECEBER MERCADORIAS COM IMPOSTO RETIDO INTEGRAL E PROMOVER SA�DA COM DESTINO A SIMPLES NACIONAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 10;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 11, 'RESSARCIMENTO PELA REFIN DE PETR�LEO DO VALOR ISEN��O SA�DAS DE �LEO DIESEL PARA EMBARCA��O PESQUEIRA - AN. 2 , ART. 75', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELA REFIN DE PETR�LEO DO VALOR ISEN��O SA�DAS DE �LEO DIESEL PARA EMBARCA��O PESQUEIRA - AN. 2 , ART. 75'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 11;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 12, 'RESTITUI��O DE IMPOSTO RETIDO AUTORIZADO POR MEIO DE PROCESSO ADMINISTRATIVO DA SEF - AN. 3, ART. 26', '01/08/2013', '01/02/2015', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESTITUI��O DE IMPOSTO RETIDO AUTORIZADO POR MEIO DE PROCESSO ADMINISTRATIVO DA SEF - AN. 3, ART. 26'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 12;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 13, 'CR�DITO PELO SUBSTITUTO DO IMPOSTO RETIDO CONSIGNADO EM NOTA FISCAL DE DEVOLU��O DE MERCADORIAS - AN. 3, ART. 23', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO SUBSTITUTO DO IMPOSTO RETIDO CONSIGNADO EM NOTA FISCAL DE DEVOLU��O DE MERCADORIAS - AN. 3, ART. 23'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 13;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 14, 'CR�DITO PREVISTO NO ANEXO 2 CAP. V, SE�. XV, SA�DAS DESTINADAS SIMPLES NACIONAL (VOLUME MENOR 60%) - AN 2, ART.15, XXXIV', '01/08/2013', null, 0, 1 , 348);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PREVISTO NO ANEXO 2 CAP. V, SE�. XV, SA�DAS DESTINADAS SIMPLES NACIONAL (VOLUME MENOR 60%) - AN 2, ART.15, XXXIV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 14;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 15, 'CR�DITO DO IMPOSTO RETIDO DE MERCADORIAS EM ESTOQUE, NA MUDAN�A DA SITUA��O DE SUBSTITU�DO PARA SUBSTITUTO - AN. 3, ART. 35-A', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO IMPOSTO RETIDO DE MERCADORIAS EM ESTOQUE, NA MUDAN�A DA SITUA��O DE SUBSTITU�DO PARA SUBSTITUTO - AN. 3, ART. 35-A'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 15;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 16, 'CR�DITO CONTRIBUI��O AO FUNDOSOCIAL PELAS REFINARIAS E SUAS BASES - DEC. 877/07', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO CONTRIBUI��O AO FUNDOSOCIAL PELAS REFINARIAS E SUAS BASES - DEC. 877/07'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 16;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 17, 'CR�DITO IMPOSTO RETIDO PAGO INDEVIDAMENTE POR ERRO NA ESCRITURA��O DOS LIVROS OU PREENCHIMENTO OU DARE - ART. 33', '01/08/2013', null, 1 , 3 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO IMPOSTO RETIDO PAGO INDEVIDAMENTE POR ERRO NA ESCRITURA��O DOS LIVROS OU PREENCHIMENTO OU DARE - ART. 33'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 17;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 18, 'CR�DITO EXTEMPOR�NEO DE IMPOSTO RETIDO DECORRENTE DO N�O REGISTRO OU DE ERRO NA ESCRITA FISCAL', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO EXTEMPOR�NEO DE IMPOSTO RETIDO DECORRENTE DO N�O REGISTRO OU DE ERRO NA ESCRITA FISCAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 18;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 19, 'CR�DITO DE IMPOSTO RETIDO POR DECIS�O JUDICIAL', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DE IMPOSTO RETIDO POR DECIS�O JUDICIAL'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 19;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 20, 'CR�DITO DE IMPOSTO RETIDO AUTORIZADO EM DECIS�O DO TRIBUNAL ADMINISTRATIVO TRIBUT�RIO', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DE IMPOSTO RETIDO AUTORIZADO EM DECIS�O DO TRIBUNAL ADMINISTRATIVO TRIBUT�RIO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 20;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 21, 'CR�DITO CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 21;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 22, '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO INFORMADO NO SUBTIPO 21', '01/08/2013', '01/10/2015', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO INFORMADO NO SUBTIPO 21'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 22;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 23, 'APLICA��ES NO SEITEC COMPENS�VEL COM IMPOSTO RETIDO', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APLICA��ES NO SEITEC COMPENS�VEL COM IMPOSTO RETIDO'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 23;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 24, 'CR�DITO PREVISTO NO ANEXO 2 CAP. V, SE�. XV, SA�DAS DESTINADAS SIMPLES NACIONAL (VOLUME M�NIMO 60%) - AN 2, ART.15, XXXIV', '01/08/2013', null, 0, 1 , 9);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PREVISTO NO ANEXO 2 CAP. V, SE�. XV, SA�DAS DESTINADAS SIMPLES NACIONAL (VOLUME M�NIMO 60%) - AN 2, ART.15, XXXIV'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 24;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 25, 'CR�DITO DO RETIDO RELATIVO � PAGAMENTOS DEVIDOS POR OCASI�O DO FATO GERADOR NA FORMA ESTABELECIDA EM ATO DECLARAT�RIO/RE', '01/08/2013', null, 1 , 3 , null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO DO RETIDO RELATIVO � PAGAMENTOS DEVIDOS POR OCASI�O DO FATO GERADOR NA FORMA ESTABELECIDA EM ATO DECLARAT�RIO/RE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 25;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 26, 'ESTORNO DO IMPOSTO RETIDO DECORRENTE DE SA�DA EM M�S POSTERIOR AO DA EMISS�O DA NFE', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'ESTORNO DO IMPOSTO RETIDO DECORRENTE DE SA�DA EM M�S POSTERIOR AO DA EMISS�O DA NFE'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 26;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 27, 'CR�DITO PRESUMIDO APLIC�VEL � SUBSTITUI��O TRIBUTARIA - CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/96 - EXIGE TTD BENEF�CIO 384', '01/10/2013', null, 0, 1 , 384);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PRESUMIDO APLIC�VEL � SUBSTITUI��O TRIBUTARIA - CONCEDIDO COM BASE NO ART. 43 DA LEI N� 10.297/96 - EXIGE TTD BENEF�CIO 384'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 27;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 28, 'CR�DITO RELATIVO ENTRADAS DE INSUMOS NA TRANSFER�NCIA PARA FILIAL VAREJISTA DE MERCADORIA SUJEITA A ST - AN. 3, ART.16  � 4�', '01/07/2010' , null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO RELATIVO ENTRADAS DE INSUMOS NA TRANSFER�NCIA PARA FILIAL VAREJISTA DE MERCADORIA SUJEITA A ST - AN. 3, ART.16  � 4�'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 28;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 29, 'APROPRIA��O DA RESTITUI��O EM FORMA DE CR�DITO PARA LAN�AMENTO EM CONTA GR�FICA CONFORME PROTOCOLO DE RECONHECIMENTO DE CR�DITO - PRC', '01/03/2015', null, 1 , 10, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'APROPRIA��O DA RESTITUI��O EM FORMA DE CR�DITO PARA LAN�AMENTO EM CONTA GR�FICA CONFORME PROTOCOLO DE RECONHECIMENTO DE CR�DITO - PRC'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 29;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 30, 'RESSARCIMENTO PELO DESTINAT�RIO QUE REALIZE VENDA A CONSUMIDOR DE FORMA N�O PRESENCIAL NO CASO DA MERCADORIA J� TER SIDO SUBMETIDA A SUBSTITUI��O TRIBUT�RIA - TTD BENEF�CIO 453', '01/08/2013', null, 0, 1 , 453 );
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'RESSARCIMENTO PELO DESTINAT�RIO QUE REALIZE VENDA A CONSUMIDOR DE FORMA N�O PRESENCIAL NO CASO DA MERCADORIA J� TER SIDO SUBMETIDA A SUBSTITUI��O TRIBUT�RIA - TTD BENEF�CIO 453'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 30;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 31, 'CR�DITO PELO FORNECEDOR INDICADO DO RESSARCIMENTO EFETUADO POR DETENTOR DO TTD DO BENEF�CIO 96', '01/08/2013', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO FORNECEDOR INDICADO DO RESSARCIMENTO EFETUADO POR DETENTOR DO TTD DO BENEF�CIO 96'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 31;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 32, 'CR�DITO PELO DESTINAT�RIO DO IMPOSTO RETIDO NAS OPERA��ES DESTINADAS A EMPRESAS INTERDEPENDENTES COM APURA��O COMPARTILHADA', '01/04/2016' , null, 0, 1 , 480);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO PELO DESTINAT�RIO DO IMPOSTO RETIDO NAS OPERA��ES DESTINADAS A EMPRESAS INTERDEPENDENTES COM APURA��O COMPARTILHADA'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 32;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 33, '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO INFORMADO NO SUBTIPO 21 - LEI 16.940/16', '01/05/2016' , '01/12/2017' , 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = '10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL COMPENS�VEL COM IMPOSTO RETIDO INFORMADO NO SUBTIPO 21 - LEI 16.940/16'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 33;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 34, 'SOMAT�RIO DOS 10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL N�O LAN�ADOS DESDE MAIO/2016 CONFORME LEI 16.940/16', '01/10/2016', '01/12/2017', 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'SOMAT�RIO DOS 10% SOBRE O VALOR DA CONTRIBUI��O AO FUNDOSOCIAL N�O LAN�ADOS DESDE MAIO/2016 CONFORME LEI 16.940/16'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 34;
  end;
  
  begin
    insert into csf_own.generica_dcip (id, registrodcip_id, codigo, descricao, dt_ini, dt_fim, permite_dup, util_sat, num_benef) values (csf_own.genericadcip_seq.nextval, (select r.id from csf_own.registro_dcip r where r.codigo = '140'), 35, 'CR�DITO CORRESPONDENTE AO ICMS REPASSADO PELA REFINARIA �S UFs DE ORIGEM DO AEHC E/OU B100', '01/08/2018', null, 0, 0, null);
  exception
    when others then
      update csf_own.generica_dcip
         set descricao       = 'CR�DITO CORRESPONDENTE AO ICMS REPASSADO PELA REFINARIA �S UFs DE ORIGEM DO AEHC E/OU B100'
       where registrodcip_id = (select r.id from csf_own.registro_dcip r where r.codigo = '140')
         and codigo          = 35;
  end;


commit;

end;

/

-----------------------------------------------------------------------------
Prompt *** INSERT DOMINIO ***
-----------------------------------------------------------------------------
-- APURA_DCIP.DM_NUM_SAT (Registro 9032)
begin

  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr,
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '0',
       'N�o',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'N�o'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '0';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '1',
       'TTD - Tratamento Tribut�rio Diferenciado',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'N�o'
       where d.dominio = 'TTD - Tratamento Tribut�rio Diferenciado'
         and d.vl      = '1';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '2',
       'AUC - Autoriza��o de Utiliza��o de Cr�dito',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'AUC - Autoriza��o de Utiliza��o de Cr�dito'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '2';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '3',
       'DARE - Documento de Arrecada��o de Receitas Estaduais',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'DARE - Documento de Arrecada��o de Receitas Estaduais'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '3';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '4',
       'RE - Regime Especial',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'RE - Regime Especial'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '4';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '5',
       'DI - Declara��o de Importa��o',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'DI - Declara��o de Importa��o'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '5';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '6',
       'DSI - Declara��o Simplificada de Importa��o',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'DSI - Declara��o Simplificada de Importa��o'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '6';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '7',
       'PA - Processo Administrativo SPP e ESEA (*)',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'PA - Processo Administrativo SPP e ESEA (*)'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '7';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '8',
       'PCA - Processo Contencioso Administrativo',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'PCA - Processo Contencioso Administrativo'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '8';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '9',
       'Per�odo de Refer�ncia (**)',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Per�odo de Refer�ncia (**)'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '9';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('APURA_DCIP.DM_NUM_SAT',
       '10',
       'PRC - Protocolo de Reconhecimento de Cr�dito',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'PRC - Protocolo de Reconhecimento de Cr�dito'
       where d.dominio = 'APURA_DCIP.DM_NUM_SAT'
         and d.vl      = '10';
  end;
  
  -- ABERTURA_DCIP.DM_SITUACAO
  begin
    insert into csf_own.dominio
      (dominio, 
       vl, 
       descr, 
       id)
    values
      ('ABERTURA_DCIP.DM_SITUACAO',
       '7',
       'Calculada',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Calculada'
       where d.dominio = 'ABERTURA_DCIP.DM_SITUACAO'
         and d.vl      = '7';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl,
       descr, 
       id)
    values
      ('ABERTURA_DCIP.DM_SITUACAO',
       '8',
       'Erro no c�lculo',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Erro no c�lculo'
       where d.dominio = 'ABERTURA_DCIP.DM_SITUACAO'
         and d.vl      = '8';
  end;

  -- REGISTRO_TOTAL_DCIP.DM_SITUACAO
  begin
    insert into csf_own.dominio
      (dominio, 
       vl,
       descr, 
       id)
    values
      ('REGISTRO_TOTAL_DCIP.DM_SITUACAO',
       '0',
       'Aberto',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Aberto'
       where d.dominio = 'REGISTRO_TOTAL_DCIP.DM_SITUACAO'
         and d.vl      = '0';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl,
       descr, 
       id)
    values
      ('REGISTRO_TOTAL_DCIP.DM_SITUACAO',
       '1',
       'Calculado',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Calculado'
       where d.dominio = 'REGISTRO_TOTAL_DCIP.DM_SITUACAO'
         and d.vl      = '1';
  end;
  
  begin
    insert into csf_own.dominio
      (dominio, 
       vl,
       descr, 
       id)
    values
      ('REGISTRO_TOTAL_DCIP.DM_SITUACAO',
       '2',
       'Erro no c�lculo',
       csf_own.dominio_seq.nextval);
  exception
    when others then
      update csf_own.dominio d
         set d.descr   = 'Erro no c�lculo'
       where d.dominio = 'REGISTRO_TOTAL_DCIP.DM_SITUACAO'
         and d.vl      = '2';
  end;

end;
/

-----------------------------------------------------------------------------
Prompt *** INSERT TIPO_COD_ARQ ***
-----------------------------------------------------------------------------
declare

  vn_max_cod number;
  vn_exist   number := 0;

begin

  -- Verifica se j� existe um registro 
  -- referente a DCIP 
  begin
    select count(*)
      into vn_exist
      from tipo_cod_arq t
     where t.descr = 'DCIP';
  exception
    when others then
      vn_exist := 0;
  end;
  
  -- Caso n�o exista nenhum registro referente 
  -- a DCIP, realiza o cadastro  
  if vn_exist = 0 then
    
    begin
      select max(to_number(t.cd)) 
        into vn_max_cod
        from tipo_cod_arq t;
    exception
      when others then
        vn_max_cod := 0;
    end;
  
    vn_max_cod := vn_max_cod + 1;
  
    if vn_max_cod > 0 then
    
      insert into tipo_cod_arq
        (id, cd, descr)
      values
        (csf_own.tipocodarq_seq.nextval, 
         vn_max_cod, 
         'DCIP');
      commit;
    
    end if;
    
  end if;
  
end;
/

prompt 642a_pk_gera_arq_dcip
@@642a_pk_gera_arq_dcip.pks
show err
prompt 642b_pk_gera_arq_dcip
@@642b_pk_gera_arq_dcip.pkb
show err

grant execute on csf_own.pk_gera_arq_dcip to csf_work
/

commit;

-----------------------------------------------------------------------------
Prompt Fim Redmine #47050 - Geracao DCIP
-----------------------------------------------------------------------------
