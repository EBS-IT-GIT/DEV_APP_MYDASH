-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - NOTA_FISCAL_PED
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.NOTA_FISCAL_PED
(
  ID                 NUMBER not null,
  NOTAFISCAL_ID      NUMBER not null,
  EMPRESA_ID         NUMBER not null,
  PESSOA_ID          NUMBER,
  DM_ST_PROC         NUMBER(2) not null,
  DT_EMISS           DATE not null,
  PEDIDO_COMPRA      VARCHAR2(60),
  DM_IND_EMIT        NUMBER(1) not null,
  DM_IND_OPER        NUMBER(1) not null,
  NRO_NF             NUMBER(9) not null,
  SERIE              VARCHAR2(3) not null,
  DT_SAI_ENT         DATE,
  CNPJ               VARCHAR2(14),
  MODFISCAL_ID       NUMBER,
  NRO_CHAVE_NFE      VARCHAR2(44),
  SITDOCTO_ID        NUMBER,
  VL_TOTAL_ITEM      NUMBER(15,2),
  VL_FRETE           NUMBER(15,2),
  VL_SEGURO          NUMBER(15,2),
  VL_DESCONTO        NUMBER(15,2),
  VL_OUTRA_DESPESAS  NUMBER(15,2),
  VL_TOTAL_NF        NUMBER(15,2),
  VL_IMP_TRIB_PIS    NUMBER(15,2),
  VL_IMP_TRIB_COFINS NUMBER(15,2),
  VL_IMP_TRIB_ISS    NUMBER(15,2),
  VL_TOTAL_SERV      NUMBER(15,2),
  VL_IMP_TRIB_IPI    NUMBER(15,2),
  VL_IMP_TRIB_ICMS   NUMBER(15,2),
  VL_IMP_TRIB_ST     NUMBER(15,2),
  VL_IMP_TRIB_II     NUMBER(15,2),
  DT_RECEB           DATE,
  DM_ST_RET          NUMBER,
  DM_EDICAO          NUMBER default 0,
  VL_TOT_LIQUIDO     NUMBER(15,2) default 0,
  PARAMRECEB_ID      NUMBER
)
/

-- Add comments to the table
comment on table CSF_OWN.NOTA_FISCAL_PED  is 'Tabela de Notas Fiscais para compara��o com a tabela PEDIDO'
/

-- Add comments to the columns
comment on column CSF_OWN.NOTA_FISCAL_PED.NOTAFISCAL_ID  is 'ID que relaciona a Tabela Nota Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.EMPRESA_ID     is 'ID que relaciona a Tabela Empresa'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.PESSOA_ID      is 'ID que relaciona a Tabela Pessoa'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DM_ST_PROC     is 'Situa��o do processo da Nota Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DT_EMISS       is 'Data de emiss�o do Documento Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.PEDIDO_COMPRA  is 'Pedido de compra'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DM_IND_EMIT    is 'Indicador do emitente: 0-Emiss�o Propria / 1-Terceiros'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DM_IND_OPER    is 'Indicador da opera��o: 0-Entrada / 1-Saida'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.NRO_NF         is 'N�mero do Documento Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.SERIE          is 'Serie do Documento Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DT_SAI_ENT     is 'Data de Saida ou da Entrada da Mercadoria/Produto'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.CNPJ           is 'CNPJ do emitente'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.MODFISCAL_ID   is 'ID que relaciona a Tabela Mod_Fiscal - Codigo do Modelo Docto Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.NRO_CHAVE_NFE  is 'Chave de acesso da NF-e'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.SITDOCTO_ID    is 'ID que relaciona a Tabela Sit_Docto'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_TOTAL_ITEM  is 'Valor Total dos produtos e servi�os'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_FRETE       is 'Valor Total do Frete'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_SEGURO      is 'Valor Total do Seguro'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_DESCONTO    is 'Valor Total do Desconto'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_OUTRA_DESPESAS  is 'Valor Outras Despesas acessorias'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_TOTAL_NF    is 'Valor Total da Nota Fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_PIS  is 'Valor do PIS'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_COFINS  is 'Valor do COFINS'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_ISS     is 'Valor Total do ISS'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_TOTAL_SERV       is 'Valor total dos servicos'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_IPI     is 'Valor Total do IPI'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_ICMS    is 'Valor Total do ICMS'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_ST      is 'Valor Total do ICMS ST'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_IMP_TRIB_II      is 'Valor Total do II'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DT_RECEB            is 'Data do Recebimento da nota fiscal'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DM_ST_RET           is 'Situa��o do retorno do ERP do cliente'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.DM_EDICAO           is 'Indicador de edicao do registro por tela: 0-Nao / 1-Sim'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.VL_TOT_LIQUIDO      is 'Valor Total Liquido da Nota Fiscal Ped'
/

comment on column CSF_OWN.NOTA_FISCAL_PED.PARAMRECEB_ID       is 'ID da tabela PARAM_RECEB'
/


-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_PK primary key (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_NOTAFISCALID_UK unique (NOTAFISCAL_ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_EMPRESA_FK foreign key (EMPRESA_ID)  references CSF_OWN.EMPRESA (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_MODFISCAL_FK foreign key (MODFISCAL_ID)  references CSF_OWN.MOD_FISCAL (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_NOTAFISCAL_FK foreign key (NOTAFISCAL_ID)  references CSF_OWN.NOTA_FISCAL (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_PARAMRECEB_FK foreign key (PARAMRECEB_ID)  references CSF_OWN.PARAM_RECEB (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_PESSOA_FK foreign key (PESSOA_ID)         references CSF_OWN.PESSOA (ID)
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_SITDOCTO_FK foreign key (SITDOCTO_ID)     references CSF_OWN.SIT_DOCTO (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMEDICAO_CK  check (DM_EDICAO IN (0, 1))
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMINDEMIT_CK check (DM_IND_EMIT IN (0, 1))
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMINDOPER_CK check (DM_IND_OPER IN (0, 1))
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMSTPROC_CK  check (DM_ST_PROC IN (0, 1, 2, 3, 4, 5, 6, 7))
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMSTRET_CK   check (DM_ST_RET IN (0, 1, 2))
/

-- Create/Recreate indexes
create index CSF_OWN.NOTAFISCALPED_EMPRESA_FK_I on CSF_OWN.NOTA_FISCAL_PED (EMPRESA_ID)
/

create index CSF_OWN.NOTAFISCALPED_IX01 on CSF_OWN.NOTA_FISCAL_PED (DM_ST_PROC)
/

create index CSF_OWN.NOTAFISCALPED_IX02 on CSF_OWN.NOTA_FISCAL_PED (DM_ST_PROC, EMPRESA_ID)
/

create index CSF_OWN.NOTAFISCALPED_MODFISCAL_FK_I on CSF_OWN.NOTA_FISCAL_PED (MODFISCAL_ID)
/

create index CSF_OWN.NOTAFISCALPED_NOTAFISCAL_FK_I on CSF_OWN.NOTA_FISCAL_PED (NOTAFISCAL_ID)
/

create index CSF_OWN.NOTAFISCALPED_PARAMRECEB_FK_I on CSF_OWN.NOTA_FISCAL_PED (PARAMRECEB_ID)
/

create index CSF_OWN.NOTAFISCALPED_SITDOCTO_FK_I on CSF_OWN.NOTA_FISCAL_PED (SITDOCTO_ID)

-- 08 - Cria��o dos Grants
grant select, insert, update, delete on csf_own.NOTA_FISCAL_PED to CSF_WORK
/

-- 09 - Cria��o do Sin�nimo
--create or replace synonym csf_work.NOTA_FISCAL_PED for csf_own.NOTA_FISCAL_PED
--/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.NOTAFISCALPED_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'NOTAFISCALPED_SEQ', 'NOTA_FISCAL_PED')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - NOTA_FISCAL_PED
-------------------------------------------------------------------------------------------------------------------------------