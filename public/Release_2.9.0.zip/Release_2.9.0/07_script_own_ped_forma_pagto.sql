-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine PED_FORMA_PGTO
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.PED_FORMA_PGTO
(
  ID          NUMBER not null,
  PEDIDO_ID   NUMBER not null,
  NRO_PARCELA NUMBER(4),
  DM_TP_PAG   NUMBER(2),
  PRAZO       NUMBER(4),
  VL_PGTO     NUMBER(15,2) not null
)
/

-- Add comments to the table
comment on table CSF_OWN.PED_FORMA_PGTO  is 'Tabela de forma de pagamento do pedido'
/

-- Add comments to the columns
comment on column CSF_OWN.PED_FORMA_PGTO.ID  is '	PK da tabela'
/

comment on column CSF_OWN.PED_FORMA_PGTO.PEDIDO_ID  is '	ID que relaciona a Tabela Pedido'
/

comment on column CSF_OWN.PED_FORMA_PGTO.NRO_PARCELA  is '	N�mero da parcela de pagamento'
/

comment on column CSF_OWN.PED_FORMA_PGTO.DM_TP_PAG    is '	Forma de pagamento: 01=Dinheiro 02=Cheque 03=Cart�o de Cr�dito 04=Cart�o de D�bito 05=Cr�dito Loja 10=Vale Alimenta��o 11=Vale Refei��o 12=Vale Presente 13=Vale Combust�vel 14=Duplicata Mercantil 90=Sem pagamento 99=Outros'
/

comment on column CSF_OWN.PED_FORMA_PGTO.PRAZO        is '	Prazo em dias para pagamento da parcela'
/

comment on column CSF_OWN.PED_FORMA_PGTO.VL_PGTO      is '	Valor do Pagamento'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.PED_FORMA_PGTO   add constraint PED_FORMA_PGTO_PK primary key (ID)
/

alter table CSF_OWN.PED_FORMA_PGTO  add constraint PED_FORMA_PGTO_PEDIDO_FK foreign key (PEDIDO_ID)  references CSF_OWN.PEDIDO (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.PED_FORMA_PGTO  add constraint PED_FORMA_PGTO_DMTPPAG_CK  check (dm_tp_pag in ('01', '02', '03', '04', '05', '10', '11', '12', '13', '14', '15', '90', '99'))
/

-- Create/Recreate indexes
create index CSF_OWN.PEDFORMAPAGTO_PEDIDO_FK_I on CSF_OWN.PED_FORMA_PGTO (PEDIDO_ID)
/

-- Grants
grant select, insert, update, delete on csf_own.PED_FORMA_PGTO to CSF_WORK
/

commit
/

-- Criar sequence
create sequence CSF_OWN.PEDFORMAPGTO_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'PEDFORMAPGTO_SEQ', 'PED_FORMA_PGTO')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine PED_FORMA_PGTO
-------------------------------------------------------------------------------------------------------------------------------

