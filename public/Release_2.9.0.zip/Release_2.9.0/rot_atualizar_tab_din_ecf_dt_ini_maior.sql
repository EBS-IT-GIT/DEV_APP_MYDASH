set serveroutput on;
declare
/*v_count integer;*/
vd_dt_ini csf_own.tab_din_ecf.dt_ini%type;
vv_dt_ini csf_own.tmp_tab_fin_ecf.dt_ini%type;
cursor c_ecf is
select (select cod from csf_own.registro_ecf  where id = de.registroecf_id ) registro_ecf , de.cd , to_char(de.dt_ini,'ddmmrrrr') dt_ini,to_char(de.dt_fin,'ddmmrrrr') dt_fin, de.id
from csf_own.tab_din_ecf de
where de.dt_ini > de.dt_fin 
and de.registroecf_id in (select id from csf_own.registro_ecf where cod in ('M350', 'M300') );

begin
  
for rec_ecf in c_ecf loop
  ---
/*  v_count:=0;*/
  vd_dt_ini:=null;
  vv_dt_ini:=null;
  begin
    select dt_ini  into vv_dt_ini  from csf_own.tmp_tab_fin_ecf
    where registro_ecf = rec_ecf.registro_ecf 
    and cd =  rec_ecf.cd /*and dt_ini = rec_ecf.dt_ini*/;
  exception
    when others then
        vv_dt_ini:=null;
  end;
  ---
  if vv_dt_ini is not null then
     vd_dt_ini:=to_date(vv_dt_ini,'dd/mm/rrrr');
     /*dbms_output.put_line (rec_ecf.registro_ecf ||'-'||rec_ecf.cd ||'-'||rec_ecf.dt_ini||'-'||vv_dt_ini||'-'||vd_dt_ini||'-'||rec_ecf.id);*/
     update csf_own.tab_din_ecf set dt_ini = vd_dt_ini where id = rec_ecf.id;
  end if;
  ---
end loop;
commit;
end;
/
