-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine PEDIDO
-------------------------------------------------------------------------------------------------------------------------------
-- 01 - Cria��o da tabela
create table csf_own.PEDIDO
(
  ID            NUMBER       not null,
  EMPRESA_ID    NUMBER       not null,
  PESSOA_ID     NUMBER       not null,
  NRO_PEDIDO    VARCHAR2(60) not null,
  DT_EMISS      DATE         not null,
  QTD_TOTAL     NUMBER(15,4) not null,
  VLR_TOTAL     NUMBER(15,2) not null,
  DM_ST_PROC    NUMBER(2)    not null,
  DM_MOD_FRETE  NUMBER(2),
  FINALIDADE_ID NUMBER
)
/

-- 02 - Cria��o dos campos para n�o ter problema com tabela j� criada
comment on table CSF_OWN.PEDIDO   is 'Tabela de pedidos'
/

-- Add comments to the columns
comment on column CSF_OWN.PEDIDO.ID  is 'PK da tabela'
/

comment on column CSF_OWN.PEDIDO.EMPRESA_ID  is 'ID que relaciona a Tabela Empresa. Empresa que gerou o pedido'
/

comment on column CSF_OWN.PEDIDO.PESSOA_ID  is 'ID que relaciona a Tabela Pessoa. Fornecedor do pedido'
/

comment on column CSF_OWN.PEDIDO.NRO_PEDIDO  is 'N�mero do pedido'
/

comment on column CSF_OWN.PEDIDO.DT_EMISS    is 'Data emiss�o do pedido'
/

comment on column CSF_OWN.PEDIDO.QTD_TOTAL   is 'Quantidade total de itens pedidos'
/

comment on column CSF_OWN.PEDIDO.VLR_TOTAL   is 'Valor total do pedido'
/

comment on column CSF_OWN.PEDIDO.DM_ST_PROC  is 'Situa��o do processo do Pedido: 0-N�o validado; 1-Validado e aberto; 2-Erro de valida��o; 3-Cancelado; 4-Validado e parcialmente recebido; 5-Validado e totalmente recebido'
/

comment on column CSF_OWN.PEDIDO.DM_MOD_FRETE  is '0- Por conta do emitente; 1- Por conta do destinatario/remetente; 2- Por conta de terceiros; 9- Sem cobranca de frete.'
/

comment on column CSF_OWN.PEDIDO.FINALIDADE_ID  is 'ID que relaciona com a tabela "Finalidade" do pedido (para indicar a finalidade do que est� sendo pedido)'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.PEDIDO  add constraint PEDIDO_PK primary key (ID)
/

alter table CSF_OWN.PEDIDO  add constraint PEDIDO_UK1 unique (EMPRESA_ID, NRO_PEDIDO)
/

alter table CSF_OWN.PEDIDO  add constraint PEDIDO_EMPRESA_FK foreign key (EMPRESA_ID)  references CSF_OWN.EMPRESA (ID)
/

alter table CSF_OWN.PEDIDO  add constraint PEDIDO_FINALIDADE_FK foreign key (FINALIDADE_ID)  references CSF_OWN.FINALIDADE_PED (ID)
/

alter table CSF_OWN.PEDIDO  add constraint PEDIDO_PESSOA_FK foreign key (PESSOA_ID)  references CSF_OWN.PESSOA (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.PEDIDO add constraint PEDIDO_DMMODFRETE_CK  check (DM_MOD_FRETE IN(0, 1, 2, 3, 4, 9))
/

alter table CSF_OWN.PEDIDO add constraint PEDIDO_DMSTPROC_CK  check (DM_ST_PROC IN (0, 1, 2, 3, 4,5))
/

-- Create/Recreate indexes
create index CSF_OWN.PEDIDO_EMPRESA_FK_I on CSF_OWN.PEDIDO (EMPRESA_ID)
/

create index CSF_OWN.PEDIDO_FINALIDADE_FK on CSF_OWN.PEDIDO (FINALIDADE_ID)
/

create index CSF_OWN.PEDIDO_PESSOA_FK_I on CSF_OWN.PEDIDO (PESSOA_ID)
/

-- 08 - Cria��o dos Grants
grant select, insert, update, delete on csf_own.PEDIDO to CSF_WORK
/

commit
/

-- 09 - Cria��o do Sin�nimo
--create or replace synonym csf_work.PEDIDO for csf_own.PEDIDO
--/


-- 10 - Cria��o da Sequence
create sequence CSF_OWN.PEDIDO_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'PEDIDO_SEQ', 'PEDIDO')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine  PEDIDO
-------------------------------------------------------------------------------------------------------------------------------

