set serveroutput on;
declare
   --
   vn_fase           number;
   vt_tab_din_ecf    tab_din_ecf%rowtype;
   vn_count_ant      number := 0;
   vn_count_up       number := 0;
   vn_count_ins      number := 0;
   vn_count_encerram number := 0;
   vv_registro_ecf   varchar2(5);
   --
   cursor c_tmp is
   select *
     from CSF_OWN.tmp_tab_fin_ecf
    order by registro_ecf
        , cod_ent_ref
        , ordem;
   --
begin
   --
   vn_fase := 1;
   --
   begin
      --
      select count(1)
        into vn_count_ant
        from CSF_OWN.tab_din_ecf;
      --
   end;
   --
   vn_count_up  := null;
   vn_count_ins := null;
   --
   for rec in c_tmp loop
    exit when c_tmp%notfound or (c_tmp%notfound) is null;
      --
      vn_fase := 2;
      vt_tab_din_ecf := null;
      vv_registro_ecf := rec.registro_ecf;
      --
      if trim(rec.cod_ent_ref) is not null
       and trim(rec.cod_ent_ref) <> '0' then
         --
         vn_fase := 2.1;
         --
         begin
            --
            select id
              into vt_tab_din_ecf.codentref_id
              from CSF_OWN.cod_ent_ref
             where cod_ent_ref = rec.cod_ent_ref;
            --
         exception
          when no_data_found then
             vt_tab_din_ecf.codentref_id := null;
         end;
         --
      end if;
      --
      vn_fase := 3;
      --
      begin
         --
         select id
           into vt_tab_din_ecf.registroecf_id
           from CSF_OWN.registro_ecf 
          where trim(cod) = trim(rec.REGISTRO_ECF);
         --
      exception
        when no_data_found then
           dbms_output.put_line('Registro ECF n�o Identificado ou n�o cadastrado na base Compliance:'|| trim(rec.registro_ecf));
      end;
      --
      vn_fase := 3.1;
      --
      if trim(rec.cd) is null then
         dbms_output.put_line('C�digo da tabela dinamica do ECF tem que ser informado:'|| trim(rec.cd));
      else
         vt_tab_din_ecf.cd := trim(rec.cd);
      end if;
      --
      vn_fase := 3.2;
      --
      vt_tab_din_ecf.id := pk_csf_secf.fkg_tabdinecf_id ( en_codentref_id    => vt_tab_din_ecf.codentref_id
                                                        , en_registroecf_id  => vt_tab_din_ecf.registroecf_id
                                                        , ev_tabdinecf_cd    => vt_tab_din_ecf.cd
                                                        );
      --
      vn_fase := 3.3;
      --
      vt_tab_din_ecf.descr         := trim(rec.descr);
      vt_tab_din_ecf.ordem         := trim(rec.ordem);
      vt_tab_din_ecf.dm_tipo       := trim(rec.dm_tipo);
      vt_tab_din_ecf.dt_ini        := to_date(rec.dt_ini,'dd/mm/yyyy');
      --
      vn_fase := 3.4;
      --
      if trim(rec.dt_fin) <> '0' then
         vt_tab_din_ecf.dt_fin        := trim(rec.dt_fin);
      end if;
      --
      if trim(rec.dt_fin) <> '0' then
         vt_tab_din_ecf.dm_tipo       := trim(rec.dm_tipo);
      end if;
      --
      if trim(rec.dm_formato) <> '0' then
      vt_tab_din_ecf.dm_formato    := trim(rec.dm_formato);
      end if;
      --
      if trim(rec.formula) <> '0' then
      vt_tab_din_ecf.formula       := trim(rec.formula);
      end if;
      --
      if trim(rec.dm_tipo_lanc) <> '0' then
         vt_tab_din_ecf.dm_tipo_lanc  := trim(rec.dm_tipo_lanc);
      end if;
      --
      if nvl(vt_tab_din_ecf.id,0) > 0 then
         --
         vn_fase := 4;
         --
         update CSF_OWN.tab_din_ecf set registroecf_id    = vt_tab_din_ecf.registroecf_id
                                      , cd                = vt_tab_din_ecf.cd
                                      , descr             = vt_tab_din_ecf.descr
                                      , dt_fin            = to_date(vt_tab_din_ecf.dt_fin,'dd/mm/yyyy')
                                      , ordem             = vt_tab_din_ecf.ordem
                                      , dm_tipo           = vt_tab_din_ecf.dm_tipo
                                      , dm_formato        = vt_tab_din_ecf.dm_formato
                                      , formula           = vt_tab_din_ecf.formula
                                      , dm_tipo_lanc      = vt_tab_din_ecf.dm_tipo_lanc
                                      , codentref_id      = vt_tab_din_ecf.codentref_id
                                  where id                = vt_tab_din_ecf.id;
         --
         vn_count_up := nvl(vn_count_up,0) + 1;
         --
      else
         --
         vn_fase := 5;
         --
         select CSF_OWN.tabdinecf_seq.nextval
           into vt_tab_din_ecf.id
           from dual;
         --
         insert into CSF_OWN.tab_din_ecf ( id
                                         , registroecf_id
                                         , cd
                                         , descr
                                         , dt_ini
                                         , dt_fin
                                         , ordem
                                         , dm_tipo
                                         , dm_formato
                                         , formula
                                         , dm_tipo_lanc
                                         , codentref_id )
                                   values( vt_tab_din_ecf.id
                                         , vt_tab_din_ecf.registroecf_id
                                         , vt_tab_din_ecf.cd
                                         , vt_tab_din_ecf.descr
                                         , to_date(vt_tab_din_ecf.dt_ini,'dd/mm/yyyy')
                                         , to_date(vt_tab_din_ecf.dt_fin,'dd/mm/yyyy')
                                         , vt_tab_din_ecf.ordem
                                         , vt_tab_din_ecf.dm_tipo
                                         , vt_tab_din_ecf.dm_formato
                                         , vt_tab_din_ecf.formula
                                         , vt_tab_din_ecf.dm_tipo_lanc
                                         , vt_tab_din_ecf.codentref_id
                                         );
         --
         vn_count_ins := nvl(vn_count_ins,0) + 1;
         --
      end if;
      --
   end loop;
   --
   -- Inativa os registros que n�o est�o no pacote
   update CSF_OWN.tab_din_ecf tde set
     tde.dt_fin = to_date('31/12/2016','dd/mm/yyyy')
   where tde.dt_fin is null
     and not exists(select 1 
                      from CSF_OWN.tmp_tab_fin_ecf tfe
                         , CSF_OWN.registro_ecf     re
                         , CSF_OWN.cod_ent_ref     cer
                    where trim(re.cod)       = trim(tfe.registro_ecf)
                      and cer.cod_ent_ref    = tfe.cod_ent_ref 
                      and tde.registroecf_id = re.id
                      and tde.cd             = trim(tfe.cd)
                      and tde.dt_ini         = to_date(tfe.dt_ini,'ddmmyyyy')
                      and tde.codentref_id   = cer.id
                    );
   --
   vn_count_encerram := sql%rowcount;
   --
   dbms_output.put_line('Quantidade que ja existia anteriormente: '|| vn_count_ant ||chr(10)||
                        'Quantidade alterado: '                    || vn_count_up  ||chr(10)||
                        'Quantidade inserido: '                    || vn_count_ins ||chr(10)||
                        'Quantidade encerrados: '                  || vn_count_encerram);
   --
   commit;
   --
   dbms_output.put_line('>>>>> rot_integr_tab_din_ecf.sql executada sem erros');
   --
exception
 when others then
    --
    rollback;
    --
    raise_application_error(-20101,'Problema na Rotina de Integra��o de tabelas dinamicas do ECF('||vn_fase||') Registro ECF: '||vv_registro_ecf ||
                                   ' C�d.: '|| vt_tab_din_ecf.cd ||' Registro: '|| pk_csf_secf.fkg_cod_registroecf_id ( vt_tab_din_ecf.registroecf_id)|| ' Erro:'|| sqlerrm);
end;
/
