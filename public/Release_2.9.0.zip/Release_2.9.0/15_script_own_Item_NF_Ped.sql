-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - ITEM_NF_PED
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.ITEM_NF_PED
(
  ID               NUMBER not null,
  NOTAFISCALPED_ID NUMBER not null,
  ITEMPEDIDO_ID    NUMBER,
  ITEMNF_ID        NUMBER not null,
  ITEM_ID          NUMBER,
  DM_ST_PROC       NUMBER(2),
  QTDE_COMERC      NUMBER(15,4) not null,
  VL_ITEM_BRUTO    NUMBER(15,2) not null,
  VL_DESC          NUMBER(15,2),
  VL_FRETE         NUMBER(15,2),
  VL_SEGURO        NUMBER(15,2),
  VL_OUTRO         NUMBER(15,2),
  COD_ITEM         VARCHAR2(60) not null,
  DESCR_ITEM       VARCHAR2(2000) not null,
  UNID_COM         VARCHAR2(6),
  DT_ULT_CONFRONTO DATE,
  NRO_ITEM         NUMBER(3) not null,
  VL_UNIT_COMERC   NUMBER(22,10),
  VL_UNIT_CONVERT  NUMBER(22,10),
  QTDE_CONVERT     NUMBER(15,4),
  VL_LIQUIDO       NUMBER(15,2)
)
/

-- Add comments to the table
comment on table CSF_OWN.ITEM_NF_PED  is 'Tabela de Detalhamento de Produtos e Servicos da Nota Fiscal dos Pedidos';

-- Add comments to the columns
comment on column CSF_OWN.ITEM_NF_PED.NOTAFISCALPED_ID  is 'ID relacionado a tabela NOTA_FISCAL_PED'
/

comment on column CSF_OWN.ITEM_NF_PED.ITEMPEDIDO_ID     is 'ID relacionado a tabela ITEM_PEDIDO'
/
comment on column CSF_OWN.ITEM_NF_PED.ITEMNF_ID         is 'ID que relaciona a Tabela Item_Nota_Fiscal'
/

comment on column CSF_OWN.ITEM_NF_PED.ITEM_ID           is 'ID que relaciona a Tabela Item'
/

comment on column CSF_OWN.ITEM_NF_PED.DM_ST_PROC        is 'Situa��o do processo do Item da Nota Fiscal Pedido'
/

comment on column CSF_OWN.ITEM_NF_PED.QTDE_COMERC       is 'Quantidade de comercializa��o do produto'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_ITEM_BRUTO     is 'Valor Total Bruto dos Produtos ou Servicos'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_DESC           is 'Valor do Desconto'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_FRETE          is 'Valor Total do Frete'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_SEGURO         is 'Valor Total do Seguro'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_OUTRO          is 'Outras despesas acessorias'
/

comment on column CSF_OWN.ITEM_NF_PED.COD_ITEM          is 'Codigo do produto ou servico'
/

comment on column CSF_OWN.ITEM_NF_PED.DESCR_ITEM        is 'Descricao do produto ou servico'
/

comment on column CSF_OWN.ITEM_NF_PED.UNID_COM          is 'Unidade de comercializacao do produto'
/

comment on column CSF_OWN.ITEM_NF_PED.DT_ULT_CONFRONTO  is 'Data do �ltimo confronto entre a nota fiscal e o pediddo'
/

comment on column CSF_OWN.ITEM_NF_PED.NRO_ITEM          is 'Numero do item do pedido'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_UNIT_COMERC    is 'Valor Unitario de comercializacao'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_UNIT_CONVERT   is 'Valor Unitario de comercializacao convertido para a unidade do fornecedor'
/

comment on column CSF_OWN.ITEM_NF_PED.QTDE_CONVERT      is 'Quantidade de comercializa��o do produto'
/

comment on column CSF_OWN.ITEM_NF_PED.VL_LIQUIDO        is 'Valor Liquido deduzindo valores dos impostos parametrizado '
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_PK primary key (ID)
/

alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_UK unique (NOTAFISCALPED_ID, NRO_ITEM, ITEMPEDIDO_ID)
/

alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_ITEMNF_FK foreign key (ITEMNF_ID)  references CSF_OWN.ITEM_NOTA_FISCAL (ID)
/

alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_ITEMPEDIDO_FK foreign key (ITEMPEDIDO_ID)  references CSF_OWN.ITEM_PEDIDO (ID)
/

alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_NOTAFISCALPED_FK foreign key (NOTAFISCALPED_ID)  references CSF_OWN.NOTA_FISCAL_PED (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.ITEM_NF_PED  add constraint ITEMNFPED_DMSTPROC_CK  check (DM_ST_PROC IN (0, 1, 2, 3, 4, 5, 6, 7))
/

-- Create/Recreate indexes
create index CSF_OWN.ITEMNFPED_IX01 on CSF_OWN.ITEM_NF_PED (ITEMPEDIDO_ID)
/

create index CSF_OWN.ITEMNFPED_IX02 on CSF_OWN.ITEM_NF_PED (NOTAFISCALPED_ID, ITEMPEDIDO_ID)
/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.ITEMNFPED_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'ITEMNFPED_SEQ', 'ITEM_NF_PED')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 52677 - Valida��o de Pedido de Compra x XML de NFe - ITEM_NF_PED
-------------------------------------------------------------------------------------------------------------------------------
