-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine 53517  - NT 2018.005 - Atualiza��es NF-e - Desenvolver integra��o
-------------------------------------------------------------------------------------------------------------------------------
-- CSF_OWN.NFE_NF_LOCAL
create table CSF_OWN.NFE_NF_LOCAL
(
  ID_NF               NUMBER       not null,
  ID_EMPRESA          NUMBER(4),
  DM_RETIRADA_ENTREGA NUMBER(1)    not null,
  NR_CNPJ             VARCHAR2(14) not null,
  NM_LOGRADOURO       VARCHAR2(60) not null,
  NR_LOGRADOURO       VARCHAR2(60) not null,
  DS_COMPL            VARCHAR2(60),
  DS_BAIRRO           VARCHAR2(60) not null,
  NR_IBGE_MUN         VARCHAR2(7)  not null,
  DS_MUN              VARCHAR2(60) not null,
  DS_UF               VARCHAR2(2)  not null,
  NR_CPF              VARCHAR2(14),
  IE                  VARCHAR2(15),
  NOME                VARCHAR2(60),
  CEP                 NUMBER(8),
  COD_PAIS            NUMBER(4),
  DESC_PAIS           VARCHAR2(60),
  FONE                NUMBER(14),
  EMAIL               VARCHAR2(60)
)
/

alter table CSF_OWN.NFE_NF_LOCAL add IE VARCHAR2(15)
/

alter table CSF_OWN.NFE_NF_LOCAL add NOME VARCHAR2(60)
/

alter table CSF_OWN.NFE_NF_LOCAL add CEP NUMBER(8)
/

alter table CSF_OWN.NFE_NF_LOCAL add COD_PAIS NUMBER(4)
/

alter table CSF_OWN.NFE_NF_LOCAL add DESC_PAIS VARCHAR2(60)
/

alter table CSF_OWN.NFE_NF_LOCAL add FONE NUMBER(14)
/

alter table CSF_OWN.NFE_NF_LOCAL add EMAIL VARCHAR2(60)
/

--  
comment on column CSF_OWN.NFE_NF_LOCAL.IE        is 'Inscri��o Estadual do contribuinte'
/

comment on column CSF_OWN.NFE_NF_LOCAL.NOME      is 'Raz�o Social ou Nome do Expedidor/Recebidor'
/

comment on column CSF_OWN.NFE_NF_LOCAL.CEP       is 'C�digo do CEP do Expedidor/Recebidor'
/

comment on column CSF_OWN.NFE_NF_LOCAL.COD_PAIS  is 'C�digo do Pa�s do Expedidor/Recebidor - Utilizar a Tabela do BACEN'
/

comment on column CSF_OWN.NFE_NF_LOCAL.DESC_PAIS is 'Nome do Pa�s do Expedidor/Recebidor'
/

comment on column CSF_OWN.NFE_NF_LOCAL.FONE      is 'Telefone do Expedidor/Recebidor'
/

comment on column CSF_OWN.NFE_NF_LOCAL.EMAIL     is 'Endere�o de e-mail do Expedidor/Recebidor'
/

commit
/

-- NFE_NF 
create table CSF_OWN.NFE_NF
(
  ID_EMPRESA                 NUMBER(4),
  ID_NF                      NUMBER not null,
  DM_ST_PROC                 NUMBER(2) not null,
  DT_ST_PROC                 DATE,
  DM_DANFE_IMPRESSA          NUMBER default 0 not null,
  NR_DIGITO_VERIFICADOR      NUMBER(1),
  DS_ARQUIVO_XML             BLOB,
  NR_IBGE_UF                 VARCHAR2(2) not null,
  NR_CHAVE_ACESSO            VARCHAR2(44),
  DS_NATUREZA_OPERACAO       VARCHAR2(60) not null,
  DM_FORMA_PAGAMENTO         NUMBER(1) not null,
  NR_MODELO_DOCUMENTO_FISCAL NUMBER(2) not null,
  NR_SERIE                   NUMBER(3) not null,
  NR_DOCUMENTO_FISCAL        NUMBER(9) not null,
  DT_EMISSAO                 DATE not null,
  DT_ENTRADA_SAIDA           DATE,
  DM_ENTRADA_SAIDA           NUMBER(1) not null,
  NR_IBGE_MUN_FG             VARCHAR2(7) not null,
  NR_CNPJ                    VARCHAR2(14) not null,
  NM_RAZAO_SOCIAL            VARCHAR2(60) not null,
  NM_FANTASIA                VARCHAR2(60),
  NM_LOGRADOURO              VARCHAR2(60) not null,
  NR_LOGRADOURO              VARCHAR2(60) not null,
  DS_CPL_LOGRADOURO          VARCHAR2(60),
  DS_BAIRRO                  VARCHAR2(60) not null,
  NR_IBGE_MUN                VARCHAR2(7) not null,
  DS_MUN                     VARCHAR2(60) not null,
  DS_UF                      VARCHAR2(2) not null,
  NR_CEP                     VARCHAR2(8),
  NR_PAIS                    VARCHAR2(4),
  DS_PAIS                    VARCHAR2(60),
  NR_TELEFONE                VARCHAR2(14),
  NR_IE                      VARCHAR2(14) not null,
  NR_IE_ST                   VARCHAR2(14),
  NR_IM                      VARCHAR2(15),
  VL_BC_ICMS                 NUMBER(15,2) not null,
  VL_ICMS                    NUMBER(15,2) not null,
  VL_BC_ICMS_ST              NUMBER(15,2) not null,
  VL_ICMS_ST                 NUMBER(15,2) not null,
  VL_PROD                    NUMBER(15,2) not null,
  VL_FRETE                   NUMBER(15,2) not null,
  VL_SEGURO                  NUMBER(15,2) not null,
  VL_DESCONTO                NUMBER(15,2) not null,
  VL_IPI                     NUMBER(15,2) not null,
  VL_PIS                     NUMBER(15,2) not null,
  VL_COFINS                  NUMBER(15,2) not null,
  VL_OUTROS                  NUMBER(15,2) not null,
  VL_NF                      NUMBER(15,2) not null,
  VL_SERV                    NUMBER(15,2),
  VL_BC_ISS                  NUMBER(15,2),
  VL_ISS                     NUMBER(15,2),
  VL_PIS_ISS                 NUMBER(15,2),
  VL_COFINS_ISS              NUMBER(15,2),
  VL_RET_PIS                 NUMBER(15,2),
  VL_RET_COFINS              NUMBER(15,2),
  VL_RET_CSLL                NUMBER(15,2),
  VL_BC_IRRF                 NUMBER(15,2),
  VL_IRRF                    NUMBER(15,2),
  VL_BC_RET_PREV             NUMBER(15,2),
  VL_RET_PREV                NUMBER(15,2),
  DS_INFO_CONTRIB            VARCHAR2(4000),
  NR_CNPJ_CPF_DESTINO        VARCHAR2(14),
  NM_DESTINO                 VARCHAR2(60) not null,
  NM_LOGRADOURO_DESTINO      VARCHAR2(60) not null,
  NR_LOGRADOURO_DESTINO      VARCHAR2(60) not null,
  DS_CPL_DESTINO             VARCHAR2(60),
  DS_BAIRRO_DESTINO          VARCHAR2(60) not null,
  NR_IBGE_MUN_DESTINO        VARCHAR2(7) not null,
  DS_MUNICIPIO_DESTINO       VARCHAR2(60) not null,
  DS_UF_DESTINO              VARCHAR2(2) not null,
  NR_CEP_DESTINO             VARCHAR2(8),
  NR_PAIS_DESTINO            VARCHAR2(4),
  DS_PAIS_DESTINO            VARCHAR2(60),
  NR_TELEFONE_DESTINO        VARCHAR2(14),
  NR_IE_DESTINO              VARCHAR2(14),
  NR_SUFRAMA_DESTINO         VARCHAR2(9),
  DS_EMAIL                   VARCHAR2(4000),
  CD_CNAE                    VARCHAR2(7),
  DS_UF_EMBARQUE             VARCHAR2(2),
  DS_LOCAL_EMBARQUE          VARCHAR2(60),
  DS_NF_EMPENHO              VARCHAR2(17),
  DS_PEDIDO                  VARCHAR2(60),
  DS_CONTRATO                VARCHAR2(60),
  ID_LOTE                    NUMBER,
  DM_AMB_SIS                 NUMBER(1),
  NR_VRS_APP                 VARCHAR2(20),
  VL_TOTAL_II                NUMBER(15,2),
  DT_CANCELAMENTO            DATE,
  DM_NF_CANC                 NUMBER default 0 not null,
  DM_OPER                    NUMBER not null,
  DM_FIN_EM                  NUMBER not null,
  DM_PROC_NF                 NUMBER not null,
  DM_FMT_DANFE               VARCHAR2(1),
  ID_USUARIO                 NUMBER,
  DS_JUSTIF_CANC             VARCHAR2(255),
  NR_MSG_C                   NUMBER,
  NR_MSG_E                   NUMBER,
  NR_PROT_ENV                NUMBER,
  NR_VRS_XML                 VARCHAR2(20),
  DM_EMIT_CONT               NUMBER(1) default 0,
  DT_EMIT_CONT               DATE,
  ID_USU_CONT                NUMBER,
  DS_XML_CANCELAMENTO        BLOB,
  DM_NF_AUT                  NUMBER(1) default 0 not null,
  DT_NF_AUT                  DATE,
  ID_USUARIO_CANCELAMENTO    NUMBER,
  DS_XML_PROT_ENV            BLOB,
  DS_NR_ALEATORIO            VARCHAR2(9),
  DS_REF_DOC                 VARCHAR2(44),
  DS_REF_SIS                 VARCHAR2(20),
  DS_MOTIVO_CONT             VARCHAR2(256),
  NR_ORDEM_EMBARQUE          VARCHAR2(50),
  DS_MOTIVO_IMP_ERRO         VARCHAR2(256),
  ID_USU_PRINT_ERRO          NUMBER,
  DT_IMPRESSAO_ERRO          DATE,
  ID_MOTIVO_CONTINGENCIA     NUMBER,
  ENV_POOL_IMPRESSAO         NUMBER,
  DT_ENTRADA_SISTEMA         DATE default TO_DATE('2000-01-01 01:00:00','yyyy-mm-dd hh:mi:ss') not null,
  NR_PROT_CANC               VARCHAR2(15),
  NR_SEQ_ORDEM_EMBARQUE      NUMBER,
  CD_IMPRESSORA              NUMBER,
  DS_XML_PROT_CANCELAMENTO   BLOB,
  NR_DADOS_NFE               VARCHAR2(36),
  DM_FORMA_EMISSAO           NUMBER(1),
  ID_CLIENTE                 NUMBER,
  ID_LOTE_DPEC               NUMBER(19),
  DT_CONTING                 DATE,
  DS_JUSTIF_CONT             VARCHAR2(255),
  CRT                        NUMBER,
  DS_EMAIL_DESTINATARIO      VARCHAR2(60),
  DS_INFO_FISCO              CLOB,
  ID_VERSAO_SCHEMA           NUMBER(10),
  ID_VERSAO_SCHEMA_CANC      NUMBER,
  ID_NF_PARAM                NUMBER,
  USUARIO_CANCELAMENTO       VARCHAR2(50),
  USUARIO_ENVIO              VARCHAR2(50),
  NR_TENT_ENV                NUMBER(4),
  NR_TENT_RET                NUMBER(4),
  DM_ID_DEST                 NUMBER(1),
  DM_IND_FINAL               NUMBER(1),
  DM_IND_PRES                NUMBER(1),
  LOCAL_DESPACHO             VARCHAR2(60),
  IM_DESTINO                 VARCHAR2(15),
  ID_ESTRANGEIRO_DESTINO     VARCHAR2(20),
  DM_IND_IE_DESTINO          NUMBER(1),
  VL_ICMS_DESON              NUMBER(15,2),
  VL_DEDUCAO                 NUMBER(15,2),
  VL_OUTRAS_RET              NUMBER(15,2),
  VL_DESC_INCOND             NUMBER(15,2),
  VL_DESC_COND               NUMBER(15,2),
  DM_IND_ISS                 NUMBER(1),
  DM_REG_TRIB                NUMBER(2),
  VL_ICMS_UF_DEST            NUMBER(15,2),
  VL_ICMS_UF_REMET           NUMBER(15,2),
  VL_COMB_POBR_UF_DEST       NUMBER(15,2),
  VL_FCP                     NUMBER(15,2),
  VL_FCP_ST                  NUMBER(15,2),
  VL_FCP_ST_RET              NUMBER(15,2),
  VL_IPI_DEVOL               NUMBER(15,2),
  URL_CHAVE                  VARCHAR2(85),
  COD_MENSAGEM               NUMBER,
  MSG_SEFAZ                  VARCHAR2(200)
)
/

alter table CSF_OWN.NFE_NF add COD_MENSAGEM NUMBER
/

alter table CSF_OWN.NFE_NF add MSG_SEFAZ VARCHAR2(200)
/

--  
comment on column CSF_OWN.NFE_NF.COD_MENSAGEM is 'C�digo da Mensagem. - Tag (cMsg)'
/

comment on column CSF_OWN.NFE_NF.MSG_SEFAZ  is 'Mensagem da SEFAZ para o emissor. - Tag (xMsg)'
/

commit
/

-- CSF_OWN.NFE_ITEM_MEDICAMENTO 
create table CSF_OWN.NFE_ITEM_MEDICAMENTO
(
  ID_EMPRESA      NUMBER(4),
  ID_NF           NUMBER       not null,
  ID_ITEM         NUMBER       not null,
  NR_LOTE         VARCHAR2(20) not null,
  DT_VALIDADE     DATE         not null,
  VL_PRECO_MAX    NUMBER(15,2) not null,
  DT_FABR         DATE         not null,
  VL_QTD_LOTE     NUMBER(11,3) not null,
  COD_ANVISA      VARCHAR2(13),
  DM_TP_PROD      NUMBER(1)    not null,
  DM_IND_MED      NUMBER(1)    not null,
  MOT_ISEN_ANVISA VARCHAR2(255)
)
/

alter table CSF_OWN.NFE_ITEM_MEDICAMENTO add MOT_ISEN_ANVISA VARCHAR2(255)
/

comment on column CSF_OWN.NFE_ITEM_MEDICAMENTO.MOT_ISEN_ANVISA is 'Motivo da isen��o da ANVISA - Tag (xMotivoIsencao)'
/

commit
/

--
-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine 53517  - NT 2018.005 - Atualiza��es NF-e - Desenvolver integra��o
-------------------------------------------------------------------------------------------------------------------------------
