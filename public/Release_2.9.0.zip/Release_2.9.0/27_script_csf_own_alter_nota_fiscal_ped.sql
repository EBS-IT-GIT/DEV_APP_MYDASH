-- ======================================================================================================================= --
Prompt INI - Redmine 55188 - Criar tabela de Parametro de Recebimento - ALTERACAO NA NOTA_FISCAL_PED
-- ======================================================================================================================= --
alter table csf_own.NOTA_FISCAL_PED add PARAMRECEB_ID number
/

comment on column csf_own.NOTA_FISCAL_PED.PARAMRECEB_ID  is 'ID da tabela PARAM_RECEB'
/

alter table csf_own.NOTA_FISCAL_PED add constraint NOTAFISCALPED_PARAMRECEB_FK foreign key (PARAMRECEB_ID) references csf_own.param_receb (ID)
/

create index NOTAFISCALPED_PARAMRECEB_FK_I on csf_own.NOTA_FISCAL_PED (paramreceb_id)
/

alter table CSF_OWN.NOTA_FISCAL_PED drop constraint NOTAFISCALPED_DMSTPROC_CK
/

alter table CSF_OWN.NOTA_FISCAL_PED  add constraint NOTAFISCALPED_DMSTPROC_CK  check (DM_ST_PROC IN (0, 1, 2, 3, 4, 5, 6))
/

commit
/

-- ======================================================================================================================= --
Prompt FIM - Redmine 55188 - Criar tabela de Parametro de Recebimento - ALTERACAO NA NOTA_FISCAL_PED
-- ======================================================================================================================= --
