prompt -----------------------------------------------------------------------------------

prompt Catalogar Types

prompt -----------------------------------------------------------------------------------

prompt 01_tp_pedido
@@01_tp_pedido.tps
show err

prompt 02_tp_item_pedido
@@02_tp_item_pedido.tps
show err

prompt 03_tp_nota_fiscal_ped
@@03_tp_nota_fiscal_ped.tps
show err

prompt 04_tp_item_nf_ped
@@04_tp_item_nf_ped.tps
show err

prompt 05_tp_imp_itemnf_ped
@@05_tp_imp_itemnf_ped.tps
show err


Prompt Catalogar Objetos Invalidos
@@rec_obj_invalid.sql
