-------------------------------------------------------------------------------------------------------------------------------
Prompt INI - Redmine ITEM_PEDIDO
-------------------------------------------------------------------------------------------------------------------------------
-- Create table
create table CSF_OWN.ITEM_PEDIDO
(
  ID                  NUMBER not null,
  PEDIDO_ID           NUMBER not null,
  NRO_ITEMPED         NUMBER(6) not null,
  ITEM_ID             NUMBER not null,
  UNIDADE_ID          NUMBER not null,
  NCM_ID              NUMBER,
  CFOP_ID             NUMBER,
  LOCAL_DEPOSITO      VARCHAR2(60),
  QTD_ITEMPED         NUMBER(15,4) not null,
  VLR_UNIT_BRUTO      NUMBER(15,2),
  VLR_DESCONTO        NUMBER(15,2),
  VLR_FRETE           NUMBER(15,2),
  VLR_OUTRAS_DESP     NUMBER(15,2),
  VLR_SEGURO          NUMBER(15,2),
  VLR_TOTAL_LIQ       NUMBER(15,2),
  VLR_TOTAL_BRUTO     NUMBER(15,2),
  DT_MIN_RECEB        DATE,
  DT_MAX_RECEB        DATE,
  UTILIZACAOFISCAL_ID NUMBER,
  DM_IND_MOV          NUMBER(1),
  DM_ST_PROC          NUMBER(2),
  QTD_RECEBIDO        NUMBER(15,2) default 0
)
/

-- Add comments to the table
comment on table CSF_OWN.ITEM_PEDIDO  is 'Tabela de item do pedido'
/

-- Add comments to the columns
comment on column CSF_OWN.ITEM_PEDIDO.ID  is 'PK da tabela'
/

comment on column CSF_OWN.ITEM_PEDIDO.PEDIDO_ID  is 'ID que relaciona a Tabela Pedido'
/

comment on column CSF_OWN.ITEM_PEDIDO.NRO_ITEMPED  is 'N�mero do item no pedido'
/

comment on column CSF_OWN.ITEM_PEDIDO.ITEM_ID      is 'Codigo do produto ou servi�o'
/

comment on column CSF_OWN.ITEM_PEDIDO.UNIDADE_ID   is 'Sigla Unidade de medida'
/

comment on column CSF_OWN.ITEM_PEDIDO.NCM_ID       is 'C�digo NCM'
/

comment on column CSF_OWN.ITEM_PEDIDO.CFOP_ID      is 'C�digo CFOP'
/

comment on column CSF_OWN.ITEM_PEDIDO.LOCAL_DEPOSITO  is 'Local Deposito (codigo que indica onde ser� entregue e armazenada a mercadoria e pode haver v�rios para um mesmo CNPJ)'
/

comment on column CSF_OWN.ITEM_PEDIDO.QTD_ITEMPED     is 'Quantidade do item'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_UNIT_BRUTO  is 'Valor unitario bruto do item'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_DESCONTO    is 'Valor de Desconto'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_FRETE       is 'Valor de frete'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_OUTRAS_DESP  is 'Valor de outras despesas'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_SEGURO       is 'Valor de seguro'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_TOTAL_LIQ    is 'Valor Total Liquido do Item'
/

comment on column CSF_OWN.ITEM_PEDIDO.VLR_TOTAL_BRUTO  is 'Valor total bruto do item (valor unit�rio x quantidade)'
/

comment on column CSF_OWN.ITEM_PEDIDO.DT_MIN_RECEB     is 'Data minima para recebimento'
/

comment on column CSF_OWN.ITEM_PEDIDO.DT_MAX_RECEB     is 'Data m�xima para recebimento'
/

comment on column CSF_OWN.ITEM_PEDIDO.UTILIZACAOFISCAL_ID  is 'ID que relaciona a Tabela Utilizacao Fiscal do item do pedido'
/

comment on column CSF_OWN.ITEM_PEDIDO.DM_IND_MOV           is 'Movimenta��o f�sica do ITEM/PRODUTO: 0-Sim / 1-N�o (Ficou com esses valores para seguir o padr�o da item_nota_fiscal)'
/

comment on column CSF_OWN.ITEM_PEDIDO.DM_ST_PROC  is 'Situa��o do processo do Item da Nota Fiscal Pedido'
/

comment on column CSF_OWN.ITEM_PEDIDO.QTD_RECEBIDO  is 'Quantidade do �tem que foi recebido (cumulativo)'
/

-- Create/Recreate primary, unique and foreign key constraints
alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_PK primary key (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_UK1 unique (PEDIDO_ID, NRO_ITEMPED)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_CFOP_FK foreign key (CFOP_ID)  references CSF_OWN.CFOP (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_ITEM_FK foreign key (ITEM_ID)  references CSF_OWN.ITEM (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_NCM_FK foreign key (NCM_ID)    references CSF_OWN.NCM (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_PED_FK foreign key (PEDIDO_ID) references CSF_OWN.PEDIDO (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_UNIDADE_FK foreign key (UNIDADE_ID)  references CSF_OWN.UNIDADE (ID)
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEM_PEDIDO_UTILIZFISCAL_FK foreign key (UTILIZACAOFISCAL_ID)  references CSF_OWN.UTILIZACAO_FISCAL (ID)
/

-- Create/Recreate check constraints
alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEMPEDIDO_DMINDMOV_CK  check (DM_IND_MOV IN (0, 1))
/

alter table CSF_OWN.ITEM_PEDIDO  add constraint ITEMPEDIDO_DMSTPROC_CK  check (DM_ST_PROC IN (0, 1, 2, 3, 4, 5))
/

-- Create/Recreate indexes
create index CSF_OWN.ITEM_PEDIDO_CFOP_FK_I on CSF_OWN.ITEM_PEDIDO (CFOP_ID)
/

create index CSF_OWN.ITEM_PEDIDO_ITEM_FK_I on CSF_OWN.ITEM_PEDIDO (ITEM_ID)
/

create index CSF_OWN.ITEM_PEDIDO_NCM_FK_I on CSF_OWN.ITEM_PEDIDO (NCM_ID)
/

create index CSF_OWN.ITEM_PEDIDO_PED_FK_I on CSF_OWN.ITEM_PEDIDO (PEDIDO_ID)
/

create index CSF_OWN.ITEM_PEDIDO_UNIDADE_FK_I on CSF_OWN.ITEM_PEDIDO (UNIDADE_ID)
/

create index CSF_OWN.ITEM_PEDIDO_UTILIZFISCAL_FK_I on CSF_OWN.ITEM_PEDIDO (UTILIZACAOFISCAL_ID)
/

-- 08 - Cria��o dos Grants
grant select, insert, update, delete on csf_own.ITEM_PEDIDO to CSF_WORK
/

-- 09 - Cria��o do Sin�nimo
--create or replace synonym csf_work.ITEM_PEDIDO for csf_own.ITEM_PEDIDO
--/

-- 10 - Cria��o da Sequence
create sequence CSF_OWN.ITEMPEDIDO_SEQ increment by 1 start with 1 nominvalue nomaxvalue nocycle nocache
/

insert into csf_own.seq_tab ( id, sequence_name, table_name) values ( csf_own.seqtab_seq.nextval, 'ITEMPEDIDO_SEQ', 'ITEM_PEDIDO')
/

commit
/

-------------------------------------------------------------------------------------------------------------------------------
Prompt FIM - Redmine ITEM_PEDIDO
-------------------------------------------------------------------------------------------------------------------------------







